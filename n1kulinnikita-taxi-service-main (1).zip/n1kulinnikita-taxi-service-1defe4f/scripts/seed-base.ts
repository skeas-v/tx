import { ScanCommand } from "@aws-sdk/client-dynamodb";
import { PutCommand } from "@aws-sdk/lib-dynamodb";
import { docClient } from "../lib/db";
import { TableName } from "../lib/schema";
import { ensureDefaultAdmin } from "../lib/models";
import { mockDrivers, mockOrders } from "../lib/mock-data";

async function tableEmpty(tableName: string): Promise<boolean> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: tableName,
      Limit: 1,
      Select: "COUNT",
    })
  );
  return (result.Count ?? 0) === 0;
}

async function seed() {
  console.log("🌱 Проверка базовых данных (seed-base)...");

  try {
    const driversEmpty = await tableEmpty(TableName.DRIVERS);
    if (driversEmpty) {
      for (const driver of mockDrivers) {
        await docClient.send(
          new PutCommand({
            TableName: TableName.DRIVERS,
            Item: driver,
          })
        );
      }
      console.log(
        `  ✓ Добавлены водители по умолчанию (${mockDrivers.length})`
      );
    } else {
      console.log("  ✓ Водители уже существуют");
    }

    const ordersEmpty = await tableEmpty(TableName.ORDERS);
    if (ordersEmpty) {
      for (const order of mockOrders) {
        await docClient.send(
          new PutCommand({
            TableName: TableName.ORDERS,
            Item: order,
          })
        );
      }
      console.log(`  ✓ Добавлены заказы по умолчанию (${mockOrders.length})`);
    } else {
      console.log("  ✓ Заказы уже существуют");
    }

    const admin = await ensureDefaultAdmin();
    console.log(`  ✓ Администратор: ${admin.login}`);

    console.log("🎉 Базовые данные готовы!");
  } catch (e) {
    console.error("❌ Ошибка заполнения базовых данных:", e);
    process.exit(1);
  }
}

seed().then(() => {
  console.log("✅ seed-base завершён");
});
