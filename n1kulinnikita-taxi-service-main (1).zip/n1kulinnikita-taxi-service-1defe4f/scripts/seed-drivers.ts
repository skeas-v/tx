import { PutCommand } from "@aws-sdk/lib-dynamodb";
import { docClient } from "../lib/db";
import { TableName } from "../lib/schema";
import { Driver, Order, OrderStatus } from "../lib/models";
import { hashPassword } from "../lib/password";

const drivers: Omit<Driver, "createdAt" | "updatedAt">[] = [
  {
    id: "+7 900 000-00-10",
    name: "Иван Петров",
    phone: "+7 900 000-00-10",
    vkId: "100001",
    carMake: "Toyota Camry",
    carNumber: "А123ВС77",
    carColor: "Белый",
    isOnLine: false,
    password: hashPassword("123456"),
  },
  {
    id: "+7 900 000-00-11",
    name: "Сергей Козлов",
    phone: "+7 900 000-00-11",
    carMake: "Kia Rio",
    carNumber: "В456КЕ777",
    carColor: "Серый",
    isOnLine: true,
    password: hashPassword("123456"),
  },
  {
    id: "+7 900 000-00-12",
    name: "Анна Соколова",
    phone: "+7 900 000-00-12",
    carMake: "Hyundai Solaris",
    carNumber: "К789МН50",
    carColor: "Красный",
    isOnLine: false,
    password: hashPassword("123456"),
  },
];

const completedOrders: Omit<Order, "createdAt" | "updatedAt">[] = [
  {
    id: "seed-completed-1",
    from: "МГУ",
    to: "Москва Сити",
    clientName: "Ольга",
    clientPhone: "+7 900 000-00-05",
    driverId: "+7 900 000-00-10",
    driverName: "Иван Петров",
    status: OrderStatus.COMPLETED,
  },
  {
    id: "seed-completed-2",
    from: "Садовое кольцо",
    to: "Рижский вокзал",
    clientName: "Дмитрий",
    clientPhone: "+7 900 000-00-03",
    driverId: "+7 900 000-00-10",
    driverName: "Иван Петров",
    status: OrderStatus.COMPLETED,
  },
  {
    id: "seed-completed-3",
    from: "Аэропорт Внуково",
    to: "Павелецкий вокзал",
    clientName: "Мария",
    clientPhone: "+7 900 000-00-04",
    driverId: "+7 900 000-00-11",
    driverName: "Сергей Козлов",
    status: OrderStatus.COMPLETED,
  },
];

async function seed() {
  console.log("🌱 Заполнение демо-данных водителей...");

  const now = new Date().toISOString();

  for (const driver of drivers) {
    await docClient.send(
      new PutCommand({
        TableName: TableName.DRIVERS,
        Item: { ...driver, createdAt: now, updatedAt: now },
      })
    );
    console.log(`  ✓ Водитель: ${driver.name} (${driver.phone})`);
  }

  for (let i = 0; i < completedOrders.length; i++) {
    const order = completedOrders[i];
    const base = new Date();
    base.setUTCHours(base.getUTCHours() - (i + 1) * 2);
    const createdAt = base.toISOString();
    const updatedAt = new Date(base.getTime() + 45 * 60 * 1000).toISOString();

    await docClient.send(
      new PutCommand({
        TableName: TableName.ORDERS,
        Item: { ...order, createdAt, updatedAt },
      })
    );
    console.log(`  ✓ Выполненный заказ: ${order.from} → ${order.to}`);
  }

  console.log("🎉 Демо-данные водителей заполнены!");
}

seed()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("❌ Ошибка заполнения демо-данных:", e);
    process.exit(1);
  });
