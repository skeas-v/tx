import { randomInt } from "node:crypto";

const token = process.env.VK_API_TOKEN;
const groupId = process.env.VK_GROUP_ID;
const api = "https://api.vk.com/method";
const v = "5.199";
const PUBLIC_URL =
  "https://bbavnd39knjf7r7m05oi.containers.yandexcloud.net/api/vk/callback";

async function call(method: string, params: Record<string, string> = {}) {
  const qs = new URLSearchParams({
    access_token: token ?? "",
    group_id: groupId ?? "",
    v,
    ...params,
  });
  const res = await fetch(`${api}/${method}?${qs.toString()}`, {
    method: "GET",
    signal: AbortSignal.timeout(15_000),
  });
  return (await res.json()) as any;
}

function fp(value: string): string {
  const head = value.slice(0, 2);
  const tail = value.slice(-2);
  return `len=${value.length} head=${head} tail=${tail}`;
}

async function main() {
  const codeRes = await call("groups.getCallbackConfirmationCode");
  const vkCode = String(codeRes.response?.code ?? "").trim();
  console.log("VK_EXPECTED_CODE", fp(vkCode));

  const pub = await fetch(PUBLIC_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "confirmation" }),
    signal: AbortSignal.timeout(15_000),
  });
  const pubBody = (await pub.text()).trim();
  console.log("PUBLIC_RESP", pub.status, fp(pubBody), pubBody === "" ? "" : "");

  const local = await fetch("http://localhost:8080/api/vk/callback", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "confirmation" }),
    signal: AbortSignal.timeout(15_000),
  });
  const localBody = (await local.text()).trim();
  console.log("LOCAL_RESP", local.status, fp(localBody));

  console.log("CODE_MATCH_PUBLIC_VS_VK", pubBody === vkCode ? "yes" : "no");
  console.log("CODE_MATCH_LOCAL_VS_VK", localBody === vkCode ? "yes" : "no");

  const servers = await call("groups.getCallbackServers");
  const it = servers.response?.items?.[0];
  console.log(
    "VK_SERVER_SECRET_SET",
    it?.secret_key ? "yes" : "no",
    "status=",
    JSON.stringify(it?.status)
  );

  try {
    const rs = await fetch(PUBLIC_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "message_new",
        secret: "x",
        object: { message: { from_id: 424242, text: "на линии" } },
      }),
      signal: AbortSignal.timeout(15_000),
    });
    console.log("WRONG_SECRET_TEST", rs.status, await rs.text());
  } catch (e) {
    console.log("WRONG_SECRET_EXC", String(e));
  }
  void randomInt;
}

main().then(() => process.exit(0));
