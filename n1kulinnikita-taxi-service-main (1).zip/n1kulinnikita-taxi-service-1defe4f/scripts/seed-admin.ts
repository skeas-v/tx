import { ensureDefaultAdmin, getSingleAdmin } from "../lib/models";

async function seed() {
  console.log("🌱 Проверка администратора по умолчанию...");

  const existing = await getSingleAdmin();
  if (existing) {
    console.log(`  ✓ Администратор уже существует: ${existing.login}`);
  } else {
    console.log("  Создание администратора admin/admin...");
    await ensureDefaultAdmin();
    console.log("  ✓ Администратор создан: admin (admin/admin)");
  }

  console.log("🎉 Администратор готов!");
}

seed()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("❌ Ошибка заполнения данных администратора:", e);
    process.exit(1);
  });
