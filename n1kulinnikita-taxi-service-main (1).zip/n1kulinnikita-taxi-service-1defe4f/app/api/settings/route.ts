import { NextResponse } from "next/server";
import { getAppSettings } from "@/lib/models";

export async function GET() {
  try {
    const settings = await getAppSettings();
    return NextResponse.json({
      siteName: settings.siteName,
      maintenanceMode: settings.maintenanceMode,
    });
  } catch (error) {
    console.error("Ошибка получения настроек:", error);
    return NextResponse.json(
      { error: "Ошибка получения настроек" },
      { status: 500 }
    );
  }
}
