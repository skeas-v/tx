import { NextResponse } from "next/server";

const VK_GET_CONVERSATIONS_URL =
  "https://api.vk.com/method/messages.getConversations";
const VK_API_VERSION = "5.199";
const VK_REQUEST_TIMEOUT_MS = 10_000;

interface VkConversationsResponse {
  error?: {
    error_code?: number;
    error_msg?: string;
  };
  response?: {
    items?: Array<{
      conversation?: {
        peer?: {
          id?: number;
          type?: string;
        };
        chat_settings?: {
          title?: string;
        };
      };
    }>;
    profiles?: Array<{
      id?: number;
      first_name?: string;
      last_name?: string;
    }>;
    groups?: Array<{
      id?: number;
      name?: string;
    }>;
  };
}

export async function GET() {
  const token = process.env.VK_API_TOKEN;

  if (!token) {
    return NextResponse.json(
      { error: "Переменная окружения VK_API_TOKEN не задана" },
      { status: 503 }
    );
  }

  try {
    const params = new URLSearchParams({
      access_token: token,
      v: VK_API_VERSION,
      extended: "1",
    });

    const response = await fetch(
      `${VK_GET_CONVERSATIONS_URL}?${params.toString()}`,
      {
        method: "GET",
        signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
      }
    );

    if (!response.ok) {
      console.warn("VK conversations: request failed:", response.status);
      return NextResponse.json(
        { error: "Не удалось получить беседы сообщества" },
        { status: 502 }
      );
    }

    const json = (await response.json()) as VkConversationsResponse;

    if (json.error) {
      console.warn(
        "VK conversations: API error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return NextResponse.json(
        { error: "Не удалось получить беседы сообщества" },
        { status: 502 }
      );
    }

    const profiles = json.response?.profiles ?? [];
    const groups = json.response?.groups ?? [];

    const conversations = (json.response?.items ?? []).map((item) => {
      const peer = item.conversation?.peer;
      const type = peer?.type ?? "unknown";
      const peerId = peer?.id ?? 0;

      let title = "";
      if (type === "chat") {
        title = item.conversation?.chat_settings?.title ?? "";
      } else if (type === "user") {
        const profile = profiles.find((p) => p.id === peerId);
        title = profile
          ? [profile.first_name, profile.last_name].filter(Boolean).join(" ")
          : "";
      } else if (type === "group") {
        const group = groups.find((g) => g.id === peerId);
        title = group?.name ?? "";
      }

      return { title: title || String(peerId), type, peer_id: peerId };
    });

    return NextResponse.json({ conversations });
  } catch (error) {
    console.warn("VK conversations: skipped:", error);
    return NextResponse.json(
      { error: "Не удалось получить беседы сообщества" },
      { status: 502 }
    );
  }
}
