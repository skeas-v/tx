import { NextRequest, NextResponse } from "next/server";
import {
  OrderStatus,
  findOrderByConversationMessageId,
  getDriverByVkId,
  markDriverWaiting,
  releaseOrder,
  updateDriverAssignedCar,
  updateDriverOnline,
  updateOrderAssignedCar,
  updateOrderStatus,
  type Driver,
  type Order,
} from "@/lib/models";
import {
  answerVkEvent,
  buildOrderMessage,
  editVkOrderMessage,
  getOrderKeyboard,
  notifyDriverStatusChange,
  sendHelpToAdmins,
  sendTextToVkGroup,
} from "@/lib/vk-notify";

// Водитель в беседе ВКонтакте отвечает (reply) на сообщение с заказом и пишет
// текстовую команду. Система по cmid сообщения, на которое дан ответ,
// определяет заказ, а водителя — по VK ID автора сообщения (from_id).
// Команды заказа: «взял», «ожидаю», «увез», «отказ».
// Команды статуса водителя (просто сообщение в беседу, без reply):
// «!НаЛинии», «!Ушел», «!помощь».
type VkCommand =
  "took" | "waiting" | "done" | "release" | "online" | "offline" | "help";

// VK Callback API присылает message_new в двух форматах:
//  - новый: object.message = {...} (поля from_id/text)
//  - старый: object = {...} (поля сообщения лежат прямо в object;
//    в самых старых версиях Callback API это user_id/body)
interface VkMessage {
  from_id?: number | string;
  user_id?: number | string;
  peer_id?: number | string;
  text?: string;
  body?: string;
  reply_message?: {
    conversation_message_id?: number | string;
  };
}

interface VkCallbackBody {
  type?: string;
  secret?: string;
  object?: (VkMessage & { message?: VkMessage }) | null;
}

const VK_COMMANDS: Array<{ raw: string; id: VkCommand }> = [
  { raw: "взял", id: "took" },
  { raw: "ожидаю", id: "waiting" },
  { raw: "увез", id: "done" },
  { raw: "отказ", id: "release" },
  { raw: "!налинии", id: "online" },
  { raw: "налинии", id: "online" },
  { raw: "на линии", id: "online" },
  { raw: "!ушел", id: "offline" },
  { raw: "ушел", id: "offline" },
  { raw: "не на линии", id: "offline" },
  { raw: "!помощь", id: "help" },
  { raw: "помощь", id: "help" },
];

function getConfirmationCode(): string {
  const raw = (process.env.VK_CONFIRMATION_CODE ?? "").trim();
  const match = raw.match(/^[0-9A-Za-z]+/);
  return match ? match[0] : raw;
}

function normalizeCommandText(text: string): string {
  return text
    .replace(/^\uFEFF|\u200B/g, "")
    .trim()
    .toLowerCase()
    .replace(/[\u00A0\s]+$/u, "")
    .replace(/[.,;:!?°]+$/u, "")
    .replace(/[\u00A0\s]+/gu, " ")
    .replace(/!\s+/g, "!")
    .trim();
}

function parseCommand(text: string): VkCommand | null {
  const normalized = normalizeCommandText(text);
  if (!normalized) return null;
  for (const command of VK_COMMANDS) {
    if (
      normalized === command.raw ||
      normalized.startsWith(`${command.raw} `)
    ) {
      return command.id;
    }
  }
  return null;
}

function isSameDriver(order: Order, driver: Driver): boolean {
  return order.driverId === driver.id || order.driverName === driver.name;
}

// Атомарный приём заказа: заказ достаётся водителю, который ответил/нажал
// первым (обновление по статусу waiting). Возвращает true, если заказ получил
// именно этот водитель.
async function takeOrderForDriver(
  order: Order,
  driver: Driver
): Promise<boolean> {
  if (order.status !== OrderStatus.WAITING) return false;
  try {
    await updateOrderStatus(
      order.id,
      {
        status: OrderStatus.ASSIGNED,
        driverId: driver.id,
        driverName: driver.name,
      },
      OrderStatus.WAITING
    );
    return true;
  } catch (error) {
    if (
      (error as { name?: string })?.name !== "ConditionalCheckFailedException"
    ) {
      throw error;
    }
    console.log(
      `VK callback: заказ ${order.id} уже взят другим водителем, водитель ${driver.id} проигнорирован`
    );
    return false;
  }
}

// Команда «!Назначен» (команда статуса водителя): сообщает, какая машина
// назначена на заказ, например «!НазначенШевроле873» или «!Назначен Шевроле 873».
// Распознаёт марку машины и три цифры госномера из текста команды.
function parseAssignedCar(
  text: string
): { make: string; number: string } | null {
  const lower = text.toLowerCase();
  const marker = "!назначен";
  const idx = lower.indexOf(marker);
  if (idx < 0) return null;
  const rest = text.slice(idx + marker.length);
  const digitsMatch = rest.match(/(\d{3})\s*$/);
  if (!digitsMatch) return null;
  const number = digitsMatch[1];
  const make = rest
    .slice(0, rest.length - digitsMatch[0].length)
    .replace(/^[\s\-–—:;,.!?"'()]+/u, "")
    .trim();
  if (!make) return null;
  return { make, number };
}

async function handleAssigned(data: VkCallbackBody): Promise<void> {
  const message = extractMessage(data);
  const fromId = messageFromId(message);
  const text = messageText(message);

  const parsed = parseAssignedCar(text);
  if (!parsed) {
    console.log(
      "VK callback: !Назначен не распознан (нет марки или трёх цифр)"
    );
    return;
  }

  const driver = await getDriverByVkId(fromId);
  console.log(
    `VK callback: !Назначен driver=${driver ? `${driver.name} (${driver.id})` : "NOT_FOUND"}`
  );
  if (!driver) {
    console.log(
      `VK callback: !Назначен, водитель по VK id ${fromId} не найден`
    );
    return;
  }

  try {
    await updateDriverAssignedCar(driver.id, parsed.make, parsed.number);
  } catch (error) {
    console.warn(
      "VK callback: ошибка сохранения назначенной машины водителя:",
      error
    );
  }

  const replyCmid = message?.reply_message?.conversation_message_id;
  if (replyCmid !== undefined && replyCmid !== null) {
    const order = await findOrderByConversationMessageId(replyCmid);
    if (order) {
      try {
        await updateOrderAssignedCar(order.id, parsed.make, parsed.number);
        console.log(
          `VK callback: driver ${driver.id} назначил машину на заказ ${order.id}`
        );
      } catch (error) {
        console.warn(
          "VK callback: ошибка сохранения назначенной машины заказа:",
          error
        );
      }
    }
  }

  await sendTextToVkGroup(
    `Назначена машина: ${parsed.make}, гос.номер ${parsed.number}`
  );
  console.log(
    `VK callback: !Назначен driver=${driver.id} make=${parsed.make} number=${parsed.number}`
  );
}

function extractMessage(data: VkCallbackBody): VkMessage | null | undefined {
  const object = data.object;
  if (!object) return undefined;
  return object.message ?? object;
}

function messageFromId(message: VkMessage | null | undefined): string {
  const fromId = message?.from_id ?? message?.user_id;
  return fromId === undefined || fromId === null ? "" : String(fromId).trim();
}

function messageText(message: VkMessage | null | undefined): string {
  return (message?.text ?? message?.body ?? "").trim();
}

function messagePeerId(message: VkMessage | null | undefined): string {
  const peerId = message?.peer_id;
  return peerId === undefined || peerId === null ? "" : String(peerId).trim();
}

async function handleMessageNew(data: VkCallbackBody): Promise<void> {
  const message = extractMessage(data);
  const fromId = messageFromId(message);
  const text = messageText(message);

  console.log(
    `VK callback: message_new from_id=${JSON.stringify(fromId)} text=${JSON.stringify(text)}`
  );

  if (!fromId) {
    console.log("VK callback: skip, нет from_id в событии");
    return;
  }

  if (!text) {
    console.log("VK callback: skip, пустой текст сообщения");
    return;
  }

  // Команда «!Назначен» распознаётся без требований к пробелам и без reply.
  if (normalizeCommandText(text).startsWith("!назначен")) {
    await handleAssigned(data);
    return;
  }

  const command = parseCommand(text);
  console.log(`VK callback: command=${command ?? "null"}`);
  if (!command) {
    console.log("VK callback: skip, команда не распознана");
    return;
  }

  const driver = await getDriverByVkId(fromId);
  console.log(
    `VK callback: driver=${driver ? `${driver.name} (${driver.id})` : "NOT_FOUND"}`
  );
  if (!driver) {
    console.log(`VK callback: skip, водитель по VK id ${fromId} не найден`);
    return;
  }

  if (command === "online") {
    if (driver.isBlocked) {
      console.log(`VK callback: skip, водитель ${driver.id} заблокирован`);
      return;
    }
    try {
      await updateDriverOnline(driver.id, true);
      console.log(
        `VK callback: статус водителя ${driver.id} изменён на online`
      );
      await notifyDriverStatusChange({
        peerId: messagePeerId(message),
        driverName: driver.name,
        online: true,
      });
    } catch (error) {
      console.warn(
        "VK callback: ошибка сохранения статуса online водителя:",
        error
      );
    }
    return;
  }

  if (command === "offline") {
    try {
      await updateDriverOnline(driver.id, false);
      console.log(
        `VK callback: статус водителя ${driver.id} изменён на offline`
      );
      await notifyDriverStatusChange({
        peerId: messagePeerId(message),
        driverName: driver.name,
        online: false,
      });
    } catch (error) {
      console.warn(
        "VK callback: ошибка сохранения статуса offline водителя:",
        error
      );
    }
    return;
  }

  if (command === "help") {
    await sendHelpToAdmins(driver);
    return;
  }

  const replyCmid = message?.reply_message?.conversation_message_id;
  console.log(`VK callback: replyCmid=${String(replyCmid ?? "none")}`);
  if (replyCmid === undefined || replyCmid === null) {
    console.log("VK callback: skip, нет reply_message для заказной команды");
    return;
  }

  const order = await findOrderByConversationMessageId(replyCmid);
  console.log(`VK callback: order=${order ? order.id : "NOT_FOUND"}`);
  if (!order) {
    console.log("VK callback: skip, заказ по cmid ответа не найден");
    return;
  }

  if (order.status === OrderStatus.CANCELLED) {
    console.log(`VK callback: skip, заказ ${order.id} отменён клиентом`);
    return;
  }

  switch (command) {
    case "took": {
      // Заказ достаётся водителю, который ответил первым: атомарное обновление
      // по статусу waiting, остальные ответы игнорируются.
      const taken = await takeOrderForDriver(order, driver);
      if (!taken) return;
      console.log(`VK callback: driver ${driver.id} took order ${order.id}`);
      const tookCmid = order.conversationMessageId ?? Number(replyCmid);
      if (Number.isFinite(Number(tookCmid)) && Number(tookCmid) > 0) {
        await editVkOrderMessage(Number(tookCmid), {
          message: buildOrderMessage(order, { takenByDriver: driver.name }),
          keyboard: getOrderKeyboard({ status: OrderStatus.ASSIGNED }),
        }).catch(() => {});
      }
      return;
    }
    case "waiting": {
      if (
        !isSameDriver(order, driver) ||
        order.status === OrderStatus.COMPLETED
      ) {
        return;
      }
      await markDriverWaiting(order.id);
      console.log(`VK callback: driver ${driver.id} waiting order ${order.id}`);
      return;
    }
    case "done": {
      if (
        !isSameDriver(order, driver) ||
        order.status === OrderStatus.COMPLETED
      ) {
        return;
      }
      await updateOrderStatus(order.id, { status: OrderStatus.COMPLETED });
      console.log(`VK callback: driver ${driver.id} done order ${order.id}`);
      const doneCmid = order.conversationMessageId ?? Number(replyCmid);
      if (Number.isFinite(Number(doneCmid)) && Number(doneCmid) > 0) {
        await editVkOrderMessage(Number(doneCmid), {
          message: buildOrderMessage(order, { completed: true }),
          keyboard: getOrderKeyboard({ status: OrderStatus.COMPLETED }, "none"),
        }).catch(() => {});
      }
      return;
    }
    case "release": {
      if (
        !isSameDriver(order, driver) ||
        order.status === OrderStatus.WAITING
      ) {
        return;
      }
      await releaseOrder(order.id);
      console.log(
        `VK callback: driver ${driver.id} released order ${order.id}`
      );
      return;
    }
    default:
      return;
  }
}

// Событие message_event приходит, когда пользователь нажимает кнопку
// клавиатуры (callback-кнопка) под сообщением с заказом.
interface VkMessageEventObject {
  user_id?: number | string;
  peer_id?: number | string;
  event_id?: string;
  // VK Callback API присылает payload в разных форматах: JSON-строкой
  // ({"cmd":"took"}), уже объектом, простой строкой ("took") или query-строкой
  // (cmd=took). Разбираем все варианты.
  payload?: unknown;
  conversation_message_id?: number | string;
}

function extractEventObject(data: VkCallbackBody): VkMessageEventObject | null {
  const object = data.object as VkMessageEventObject | null;
  if (!object || typeof object !== "object") return null;
  return object;
}

function parseEventPayload(payload?: unknown): { cmd?: string } | null {
  if (payload == null || payload === "") return null;

  // 1) payload уже объект ({"cmd":"took"} или { cmd: "took" }).
  if (typeof payload === "object") {
    const obj = payload as Record<string, unknown>;
    if (typeof obj.cmd === "string") return { cmd: obj.cmd };
    return null;
  }

  const raw = String(payload).trim();
  if (!raw) return null;

  // 2) payload — JSON-строка ({"cmd":"took"}).
  if (raw.startsWith("{") || raw.startsWith("[")) {
    try {
      const parsed = JSON.parse(raw) as unknown;
      if (parsed && typeof parsed === "object") {
        const obj = parsed as Record<string, unknown>;
        if (typeof obj.cmd === "string") return { cmd: obj.cmd };
      }
    } catch (error) {
      console.warn("VK callback: не удалось разобрать payload кнопки:", error);
    }
    return null;
  }

  // 3) payload — простая строка-команда ("took").
  if (/^[a-z_]+$/i.test(raw)) {
    return { cmd: raw.toLowerCase() };
  }

  // 4) payload — query-строка (cmd=took).
  if (raw.includes("=")) {
    try {
      const params = new URLSearchParams(raw);
      const cmd = params.get("cmd");
      if (typeof cmd === "string" && cmd.trim()) {
        return { cmd: cmd.trim() };
      }
    } catch (error) {
      console.warn("VK callback: не удалось разобрать payload кнопки:", error);
    }
  }

  return null;
}

async function handleMessageEvent(data: VkCallbackBody): Promise<void> {
  const event = extractEventObject(data);
  if (!event) return;

  const eventId = event.event_id;
  const fromId = event.user_id;
  const peerId = event.peer_id;
  const cmid = event.conversation_message_id;

  console.log(
    `VK callback: message_event user_id=${JSON.stringify(fromId)} cmid=${String(cmid ?? "none")}`
  );

  if (
    !eventId ||
    fromId === undefined ||
    peerId === undefined ||
    cmid === undefined
  ) {
    console.log("VK callback: message_event, недостаточно данных в событии");
    return;
  }

  // На нажатие кнопки обязательно нужно ответить (messages.sendMessageEventAnswer),
  // иначе у водителя кнопка будет показывать бесконечную загрузку. Ответ
  // отправляется во всех ветках, включая ошибки обработки.
  const eventRef = { event_id: eventId, user_id: fromId, peer_id: peerId };

  try {
    const payload = parseEventPayload(event.payload);
    const cmd = payload?.cmd;
    if (!cmd || (cmd !== "took" && cmd !== "done")) {
      console.log("VK callback: message_event, неизвестная команда кнопки");
      await answerVkEvent(eventRef, {
        type: "show_snackbar",
        text: "Команда не поддерживается",
      });
      return;
    }

    const driver = await getDriverByVkId(String(fromId));
    console.log(
      `VK callback: message_event driver=${driver ? `${driver.name} (${driver.id})` : "NOT_FOUND"}`
    );
    if (!driver) {
      console.log(
        `VK callback: message_event, водитель по VK id ${fromId} не найден`
      );
      await answerVkEvent(eventRef, {
        type: "show_snackbar",
        text: "Вы не водитель",
      });
      return;
    }

    const order = await findOrderByConversationMessageId(String(cmid));
    console.log(
      `VK callback: message_event order=${order ? order.id : "NOT_FOUND"}`
    );
    if (!order) {
      console.log("VK callback: message_event, заказ по cmid не найден");
      await answerVkEvent(eventRef, {
        type: "show_snackbar",
        text: "Заказ не найден",
      });
      return;
    }

    if (order.status === OrderStatus.CANCELLED) {
      console.log(
        `VK callback: message_event, заказ ${order.id} отменён клиентом`
      );
      await answerVkEvent(eventRef, {
        type: "show_snackbar",
        text: "Заказ отменён клиентом",
      });
      return;
    }

    if (cmd === "took") {
      const taken = await takeOrderForDriver(order, driver);
      await answerVkEvent(eventRef, {
        type: "show_snackbar",
        text: taken ? "Заказ принят" : "Заказ уже взят",
      });
      if (!taken) return;
      console.log(
        `VK callback: message_event driver ${driver.id} took order ${order.id}`
      );
      const takeCmid = order.conversationMessageId ?? Number(cmid);
      if (Number.isFinite(Number(takeCmid)) && Number(takeCmid) > 0) {
        await editVkOrderMessage(Number(takeCmid), {
          message: buildOrderMessage(order, { takenByDriver: driver.name }),
          keyboard: getOrderKeyboard({ status: OrderStatus.ASSIGNED }),
        }).catch(() => {});
      }
      return;
    }

    if (cmd === "done") {
      // Кнопку «Увез» может нажать только водитель, назначенный на заказ.
      // Берём свежий заказ, чтобы проверка по driverId соответствовала
      // текущему назначению (заказ мог быть освобождён и взят заново
      // другим водителем после предыдущего прочтения).
      const freshOrder = await findOrderByConversationMessageId(String(cmid));
      if (
        !freshOrder ||
        freshOrder.status === OrderStatus.COMPLETED ||
        freshOrder.status === OrderStatus.CANCELLED ||
        !isSameDriver(freshOrder, driver)
      ) {
        await answerVkEvent(eventRef, {
          type: "show_snackbar",
          text: "Действие недоступно",
        });
        return;
      }
      await updateOrderStatus(freshOrder.id, {
        status: OrderStatus.COMPLETED,
      });
      await answerVkEvent(eventRef, {
        type: "show_snackbar",
        text: "Поездка выполнена",
      });
      console.log(
        `VK callback: message_event driver ${driver.id} done order ${freshOrder.id}`
      );
      const doneCmid = freshOrder.conversationMessageId ?? Number(cmid);
      if (Number.isFinite(Number(doneCmid)) && Number(doneCmid) > 0) {
        await editVkOrderMessage(Number(doneCmid), {
          message: buildOrderMessage(freshOrder, { completed: true }),
          keyboard: getOrderKeyboard({ status: OrderStatus.COMPLETED }, "none"),
        }).catch(() => {});
      }
      return;
    }
  } catch (error) {
    console.warn(
      "VK callback: message_event, ошибка обработки нажатия кнопки:",
      error
    );
    await answerVkEvent(eventRef, {
      type: "show_snackbar",
      text: "Не удалось обработать запрос",
    });
  }
}

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    console.log("VK callback: POST с некорректным JSON, отвечаю ok");
    return new NextResponse("ok");
  }

  const data = body as VkCallbackBody;
  const eventType = data.type ?? "unknown";
  console.log(`VK callback: POST received, type=${eventType}`);

  if (data.type === "confirmation") {
    return new NextResponse(getConfirmationCode());
  }

  const secret = (process.env.VK_SECRET ?? "").trim();
  if (secret) {
    const secretMatches = data.secret === secret;
    console.log(
      `VK callback: секрет проверен, совпадает=${secretMatches ? "yes" : "no"}`
    );
    if (!secretMatches) {
      console.log("VK callback: secret mismatch, событие проигнорировано");
      return new NextResponse("ok");
    }
  } else {
    console.log("VK callback: VK_SECRET не задан, проверка секрета пропущена");
  }

  if (data.type === "message_new") {
    try {
      await handleMessageNew(data);
    } catch (error) {
      console.warn("VK callback: ошибка обработки сообщения:", error);
    }
  } else if (data.type === "message_event") {
    try {
      await handleMessageEvent(data);
    } catch (error) {
      console.warn("VK callback: ошибка обработки нажатия кнопки:", error);
    }
  } else {
    console.log(
      `VK callback: обработка события типа ${eventType} не предусмотрена`
    );
  }

  return new NextResponse("ok");
}
