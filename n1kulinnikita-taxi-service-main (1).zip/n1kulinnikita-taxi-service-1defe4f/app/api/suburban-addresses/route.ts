import { NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAllSuburbanAddresses } from "@/lib/models";
import { mockSuburbanAddresses } from "@/lib/mock-data";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockSuburbanAddresses);
  }

  try {
    return NextResponse.json(await getAllSuburbanAddresses());
  } catch (error) {
    console.error("Ошибка получения пригородных адресов:", error);
    return NextResponse.json(
      { error: "Ошибка получения пригородных адресов" },
      { status: 500 }
    );
  }
}
