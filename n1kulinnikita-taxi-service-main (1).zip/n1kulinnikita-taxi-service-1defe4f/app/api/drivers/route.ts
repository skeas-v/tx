import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { authenticateDriver, getAllDrivers, publicDriver } from "@/lib/models";
import { mockDrivers } from "@/lib/mock-data";
import { driverAuthSchema } from "@/lib/validation/drivers";
import { verifyPassword } from "@/lib/password";
import {
  DRIVER_BLOCKED,
  DRIVER_NOT_FOUND,
  DRIVER_WRONG_PASSWORD,
} from "@/lib/models";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockDrivers);
  }

  try {
    const drivers = await getAllDrivers();
    return NextResponse.json(drivers.map(publicDriver));
  } catch (error) {
    console.error("Ошибка получения водителей:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = driverAuthSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { phone, password } = parsed.data;

  if (!(await isDatabaseAvailable())) {
    const mock = mockDrivers.find((d) => d.phone === phone);
    if (!mock) {
      return NextResponse.json(
        { error: "Водитель не найден. Обратитесь к администратору." },
        { status: 404 }
      );
    }
    if (!mock.password || !verifyPassword(password, mock.password)) {
      return NextResponse.json({ error: "Неверный пароль" }, { status: 401 });
    }
    return NextResponse.json({ driver: publicDriver(mock) });
  }

  try {
    const driver = await authenticateDriver(phone, password);
    return NextResponse.json({ driver: publicDriver(driver) });
  } catch (error) {
    if (error instanceof Error && error.message === DRIVER_NOT_FOUND) {
      return NextResponse.json(
        { error: "Водитель не найден. Обратитесь к администратору." },
        { status: 404 }
      );
    }
    if (error instanceof Error && error.message === DRIVER_WRONG_PASSWORD) {
      return NextResponse.json({ error: "Неверный пароль" }, { status: 401 });
    }
    if (error instanceof Error && error.message === DRIVER_BLOCKED) {
      return NextResponse.json(
        { error: "Водитель заблокирован. Обратитесь к администратору." },
        { status: 403 }
      );
    }
    console.error("Ошибка авторизации водителя:", error);
    return NextResponse.json(
      { error: "Ошибка авторизации водителя" },
      { status: 500 }
    );
  }
}
