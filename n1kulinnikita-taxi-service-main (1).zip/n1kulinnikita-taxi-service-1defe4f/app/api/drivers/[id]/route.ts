import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getDriverById, updateDriverOnline } from "@/lib/models";
import { updateDriverOnlineSchema } from "@/lib/validation/drivers";

type Params = { id: string };

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = updateDriverOnlineSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { id } = await params;

  try {
    const existing = await getDriverById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }
    if (existing.isBlocked) {
      return NextResponse.json(
        { error: "Водитель заблокирован и не может выйти на линию" },
        { status: 403 }
      );
    }
    const driver = await updateDriverOnline(id, parsed.data.isOnLine);
    return NextResponse.json(driver);
  } catch (error) {
    console.error("Ошибка обновления статуса водителя:", error);
    return NextResponse.json(
      { error: "Ошибка обновления статуса водителя" },
      { status: 500 }
    );
  }
}
