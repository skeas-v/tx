import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getDriverById, publicDriver, updateDriver } from "@/lib/models";
import { verifyPassword } from "@/lib/password";
import { updateDriverProfileSchema } from "@/lib/validation/drivers";

type Params = { id: string };

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = updateDriverProfileSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { id } = await params;
  const {
    currentPassword,
    name,
    phone,
    vkId,
    carMake,
    carNumber,
    carColor,
    password,
  } = parsed.data;

  try {
    const existing = await getDriverById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }

    if (
      !existing.password ||
      !verifyPassword(currentPassword, existing.password)
    ) {
      return NextResponse.json(
        { error: "Неверный текущий пароль" },
        { status: 401 }
      );
    }

    const updated = await updateDriver(id, {
      name,
      phone,
      vkId,
      carMake,
      carNumber,
      carColor,
      password,
    });

    return NextResponse.json(publicDriver(updated));
  } catch (error) {
    console.error("Ошибка обновления данных водителя:", error);
    if (error instanceof Error && error.message === "DRIVER_PHONE_CONFLICT") {
      return NextResponse.json(
        { error: "Водитель с таким номером телефона уже существует" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка обновления данных водителя" },
      { status: 500 }
    );
  }
}
