import { NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { findAvailableDriver } from "@/lib/models";
import { mockDrivers, mockOrders } from "@/lib/mock-data";
import { OrderStatus } from "@/lib/models";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    const activeOrders = mockOrders.filter(
      (order) =>
        order.driverName &&
        order.status !== OrderStatus.COMPLETED &&
        order.status !== OrderStatus.CANCELLED &&
        !order.confirmResult
    );
    const driver = mockDrivers.find(
      (d) =>
        d.isOnLine &&
        !d.isBlocked &&
        !!d.phone?.trim() &&
        !activeOrders.some(
          (o) => o.driverName === d.name || o.driverName === d.id
        )
    );
    return NextResponse.json({ driver: driver ?? null });
  }

  try {
    const driver = await findAvailableDriver();
    return NextResponse.json({ driver: driver ?? null });
  } catch (error) {
    console.error("Ошибка поиска свободного водителя:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}
