import { NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAllPopularPlaces } from "@/lib/models";
import { mockPopularPlaces } from "@/lib/mock-data";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockPopularPlaces);
  }

  try {
    return NextResponse.json(await getAllPopularPlaces());
  } catch (error) {
    console.error("Ошибка получения популярных мест:", error);
    return NextResponse.json(
      { error: "Ошибка получения популярных мест" },
      { status: 500 }
    );
  }
}
