import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  deletePushSubscription,
  getAllPushSubscriptions,
  savePushSubscription,
} from "@/lib/models";
import { mockPushSubscriptions } from "@/lib/mock-data";
import { savePushSubscriptionSchema } from "@/lib/validation/push";

export async function GET() {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(mockPushSubscriptions);
  }
  try {
    const subscriptions = await getAllPushSubscriptions();
    return NextResponse.json(subscriptions);
  } catch (error) {
    console.error("Ошибка получения подписок:", error);
    return NextResponse.json(
      { error: "Ошибка получения подписок" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = savePushSubscriptionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const subscription = await savePushSubscription({
      endpoint: parsed.data.endpoint,
      keys: {
        p256dh: parsed.data.keys.p256dh,
        auth: parsed.data.keys.auth,
      },
      userAgent: parsed.data.userAgent,
    });
    return NextResponse.json(subscription, { status: 201 });
  } catch (error) {
    console.error("Ошибка сохранения подписки:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения подписки" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { searchParams } = new URL(request.url);
  const endpoint = searchParams.get("endpoint");
  if (!endpoint) {
    return NextResponse.json(
      { error: "Не указан endpoint подписки" },
      { status: 400 }
    );
  }

  try {
    await deletePushSubscription(endpoint);
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Ошибка удаления подписки:", error);
    return NextResponse.json(
      { error: "Ошибка удаления подписки" },
      { status: 500 }
    );
  }
}
