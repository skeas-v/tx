import { NextResponse } from "next/server";
import { isVapidConfiguredFromEnv, resolveVapidKeys } from "@/lib/vapid";

export async function GET() {
  try {
    const keys = await resolveVapidKeys();
    return NextResponse.json({
      publicKey: keys.publicKey,
      configured: true,
      source: isVapidConfiguredFromEnv() ? "env" : "generated",
    });
  } catch (error) {
    console.error("Ошибка получения VAPID-конфигурации:", error);
    return NextResponse.json(
      { publicKey: null, configured: false, source: "none" },
      { status: 200 }
    );
  }
}
