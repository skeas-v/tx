import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAllPushMessages } from "@/lib/models";
import { mockPushMessages } from "@/lib/mock-data";
import { sendPushToAll } from "@/lib/push";
import { sendPushSchema } from "@/lib/validation/push";

export async function GET() {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(mockPushMessages);
  }
  try {
    const messages = await getAllPushMessages();
    return NextResponse.json(messages);
  } catch (error) {
    console.error("Ошибка получения истории отправок:", error);
    return NextResponse.json(
      { error: "Ошибка получения истории отправок" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = sendPushSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const result = await sendPushToAll({
      title: parsed.data.title,
      body: parsed.data.body,
    });

    if (result.total === 0) {
      return NextResponse.json({
        ok: true,
        sent: 0,
        message: "Нет подписанных устройств. Уведомление не отправлено.",
      });
    }

    return NextResponse.json({
      ok: true,
      ...result,
      message: `Отправлено: ${result.sent}, ошибок: ${result.failed}`,
    });
  } catch (error) {
    console.error("Ошибка отправки push-уведомления:", error);
    const message =
      error instanceof Error && error.message.includes("VAPID")
        ? "Push-уведомления не настроены (VAPID ключи отсутствуют). Задайте переменные окружения VAPID_PUBLIC_KEY и VAPID_PRIVATE_KEY."
        : "Не удалось отправить push-уведомление";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
