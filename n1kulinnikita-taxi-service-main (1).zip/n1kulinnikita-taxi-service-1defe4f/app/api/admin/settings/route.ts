import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAppSettings, updateAppSettings } from "@/lib/models";
import { mockAppSettings } from "@/lib/mock-data";
import { updateSettingsSchema } from "@/lib/validation/settings";

export async function GET() {
  try {
    const settings = await getAppSettings();
    return NextResponse.json({
      siteName: settings.siteName,
      maintenanceMode: settings.maintenanceMode,
      rulesText: settings.rulesText ?? "",
      privacyText: settings.privacyText ?? "",
      commissionPerOrder: settings.commissionPerOrder ?? 0,
    });
  } catch (error) {
    console.error("Ошибка получения настроек:", error);
    return NextResponse.json(
      { error: "Ошибка получения настроек" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      {
        error: "База данных недоступна в статическом режиме",
        settings: {
          siteName: mockAppSettings.siteName,
          maintenanceMode: mockAppSettings.maintenanceMode,
          rulesText: mockAppSettings.rulesText ?? "",
          privacyText: mockAppSettings.privacyText ?? "",
          commissionPerOrder: mockAppSettings.commissionPerOrder ?? 0,
        },
      },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = updateSettingsSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const updated = await updateAppSettings({
      siteName: parsed.data.siteName,
      maintenanceMode: parsed.data.maintenanceMode,
      rulesText: parsed.data.rulesText,
      privacyText: parsed.data.privacyText,
      commissionPerOrder:
        parsed.data.commissionPerOrder !== undefined
          ? parsed.data.commissionPerOrder
          : undefined,
    });
    return NextResponse.json({
      siteName: updated.siteName,
      maintenanceMode: updated.maintenanceMode,
      rulesText: updated.rulesText ?? "",
      privacyText: updated.privacyText ?? "",
      commissionPerOrder: updated.commissionPerOrder ?? 0,
    });
  } catch (error) {
    console.error("Ошибка сохранения настроек:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения настроек" },
      { status: 500 }
    );
  }
}
