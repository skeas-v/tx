import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  deleteSuburbanAddress,
  getSuburbanAddressById,
  updateSuburbanAddress,
} from "@/lib/models";
import { suburbanAddressSchema } from "@/lib/validation/suburban-addresses";

type Params = { id: string };

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { id } = await params;
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = suburbanAddressSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const existing = await getSuburbanAddressById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Пригородный адрес не найден" },
        { status: 404 }
      );
    }
    const updated = await updateSuburbanAddress(id, parsed.data);
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Ошибка обновления пригородного адреса:", error);
    return NextResponse.json(
      { error: "Ошибка обновления пригородного адреса" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { id } = await params;
  try {
    const existing = await getSuburbanAddressById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Пригородный адрес не найден" },
        { status: 404 }
      );
    }
    await deleteSuburbanAddress(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Ошибка удаления пригородного адреса:", error);
    return NextResponse.json(
      { error: "Ошибка удаления пригородного адреса" },
      { status: 500 }
    );
  }
}
