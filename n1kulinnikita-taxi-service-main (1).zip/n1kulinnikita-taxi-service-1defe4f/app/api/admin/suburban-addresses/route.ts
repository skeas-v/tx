import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { createSuburbanAddress, getAllSuburbanAddresses } from "@/lib/models";
import { mockSuburbanAddresses } from "@/lib/mock-data";
import { suburbanAddressSchema } from "@/lib/validation/suburban-addresses";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockSuburbanAddresses);
  }

  try {
    return NextResponse.json(await getAllSuburbanAddresses());
  } catch (error) {
    console.error("Ошибка получения пригородных адресов:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = suburbanAddressSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const address = await createSuburbanAddress(parsed.data);
    return NextResponse.json(address, { status: 201 });
  } catch (error) {
    console.error("Ошибка создания пригородного адреса:", error);
    return NextResponse.json(
      { error: "Ошибка создания пригородного адреса" },
      { status: 500 }
    );
  }
}
