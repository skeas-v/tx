import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  createDriver,
  getAllDrivers,
  getAdminByLogin,
  getDriverById,
} from "@/lib/models";
import { mockDrivers } from "@/lib/mock-data";
import { adminDriverSchema } from "@/lib/validation/drivers";

const SESSION_HEADER = "x-admin-login";

async function resolveActor(
  request: NextRequest,
  dbAvailable: boolean
): Promise<{ login: string; role: AdminRole } | null> {
  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) return null;
  if (!dbAvailable) return null;
  const admin = await getAdminByLogin(login);
  if (!admin) return null;
  return { login: admin.login, role: admin.role };
}

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockDrivers);
  }

  try {
    return NextResponse.json(await getAllDrivers());
  } catch (error) {
    console.error("Ошибка получения водителей:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const actor = await resolveActor(request, true);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  // Добавлять водителей могут разработчик и администратор; редактор
  // только просматривает, редактирует и блокирует.
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для добавления водителей" },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = adminDriverSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const data = parsed.data;

  try {
    const existing = await getDriverById(data.phone);
    if (existing) {
      return NextResponse.json(
        { error: "Водитель с таким номером телефона уже существует" },
        { status: 409 }
      );
    }

    const driver = await createDriver({
      id: data.phone,
      phone: data.phone,
      name: data.name,
      vkId: data.vkId,
      carMake: data.carMake,
      carNumber: data.carNumber,
      carColor: data.carColor,
      isOnLine: data.isOnLine ?? false,
      password: data.password,
    });

    return NextResponse.json(driver, { status: 201 });
  } catch (error) {
    console.error("Ошибка создания водителя:", error);
    return NextResponse.json(
      { error: "Ошибка создания водителя" },
      { status: 500 }
    );
  }
}
