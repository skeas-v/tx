import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  deleteDriver,
  getAdminByLogin,
  getDriverById,
  updateDriver,
} from "@/lib/models";
import { adminDriverSchema } from "@/lib/validation/drivers";

type Params = { id: string };

const SESSION_HEADER = "x-admin-login";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  // Редактировать водителей могут разработчик, администратор и редактор.
  if (
    actor.role !== AdminRole.DEVELOPER &&
    actor.role !== AdminRole.ADMIN &&
    actor.role !== AdminRole.EDITOR
  ) {
    return NextResponse.json(
      { error: "Недостаточно прав для редактирования водителей" },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = adminDriverSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { id } = await params;
  const data = parsed.data;

  try {
    const existing = await getDriverById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }

    const updated = await updateDriver(id, {
      name: data.name,
      phone: data.phone,
      vkId: data.vkId,
      carMake: data.carMake,
      carNumber: data.carNumber,
      carColor: data.carColor,
      isOnLine: data.isOnLine,
      password: data.password,
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Ошибка обновления водителя:", error);
    if (error instanceof Error && error.message === "DRIVER_PHONE_CONFLICT") {
      return NextResponse.json(
        { error: "Водитель с таким номером телефона уже существует" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка обновления водителя" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  // Удалять водителей могут только разработчик и администратор.
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для удаления водителей" },
      { status: 403 }
    );
  }

  const { id } = await params;

  try {
    const existing = await getDriverById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }

    await deleteDriver(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Ошибка удаления водителя:", error);
    return NextResponse.json(
      { error: "Ошибка удаления водителя" },
      { status: 500 }
    );
  }
}
