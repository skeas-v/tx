import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  DRIVER_NOT_FOUND,
  getAdminByLogin,
  getDriverById,
  updateDriverBlocked,
} from "@/lib/models";
import { blockDriverSchema } from "@/lib/validation/drivers";

type Params = { id: string };

const SESSION_HEADER = "x-admin-login";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  // Блокировать/разблокировать водителей могут разработчик, администратор
  // и редактор.
  if (
    actor.role !== AdminRole.DEVELOPER &&
    actor.role !== AdminRole.ADMIN &&
    actor.role !== AdminRole.EDITOR
  ) {
    return NextResponse.json(
      { error: "Недостаточно прав для блокировки водителей" },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = blockDriverSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { id } = await params;

  try {
    const existing = await getDriverById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }

    const driver = await updateDriverBlocked(id, parsed.data.isBlocked);
    return NextResponse.json(driver);
  } catch (error) {
    console.error("Ошибка изменения блокировки водителя:", error);
    if (error instanceof Error && error.message === DRIVER_NOT_FOUND) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка изменения блокировки водителя" },
      { status: 500 }
    );
  }
}
