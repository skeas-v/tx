import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  DRIVER_NOT_FOUND,
  getAdminByLogin,
  getDriverById,
  updateDriverPremium,
} from "@/lib/models";
import { premiumDriverSchema } from "@/lib/validation/admins";

type Params = { id: string };

const SESSION_HEADER = "x-admin-login";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  // «Премиум аккаунт» водителя видит и включает только разработчик.
  if (actor.role !== AdminRole.DEVELOPER) {
    return NextResponse.json(
      {
        error:
          "Недостаточно прав. Премиум-аккаунт доступен только разработчику",
      },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = premiumDriverSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { id } = await params;

  try {
    const existing = await getDriverById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }

    const driver = await updateDriverPremium(id, parsed.data.isPremium);
    return NextResponse.json(driver);
  } catch (error) {
    console.error("Ошибка изменения премиум-аккаунта водителя:", error);
    if (error instanceof Error && error.message === DRIVER_NOT_FOUND) {
      return NextResponse.json(
        { error: "Водитель не найден" },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка изменения премиум-аккаунта водителя" },
      { status: 500 }
    );
  }
}
