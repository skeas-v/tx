import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  checkAdminLoginRateLimit,
  tooManyRequestsResponse,
} from "@/lib/rate-limit";
import {
  checkLoginGate,
  clearLoginFailures,
  loginBlockMessage,
  registerLoginFailure,
} from "@/lib/security-tracker";
import {
  ADMIN_NOT_FOUND,
  ADMIN_WRONG_PASSWORD,
  authenticateAdmin,
  ensureDefaultAdmin,
  getAdminByLogin,
  publicAdmin,
  updateAdminCredentials,
} from "@/lib/models";
import { mockAdmin } from "@/lib/mock-data";
import { verifyPassword } from "@/lib/password";
import {
  adminAuthSchema,
  updateAdminCredentialsSchema,
} from "@/lib/validation/admins";

// Заголовок с логином текущей админ-сессии. Клиентская админ-панель хранит
// логин в localStorage и передаёт его при запросах к защищённым эндпоинтам.
export const ADMIN_SESSION_HEADER = "x-admin-login";

function sessionLogin(request: NextRequest): string | null {
  const header = request.headers.get(ADMIN_SESSION_HEADER)?.trim();
  return header ? header : null;
}

export async function GET(request: NextRequest) {
  const login = sessionLogin(request);
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    if (login && login !== mockAdmin.login) {
      return NextResponse.json({ error: "Логин не найден" }, { status: 404 });
    }
    return NextResponse.json(publicAdmin(mockAdmin));
  }

  try {
    await ensureDefaultAdmin();
    if (login) {
      const admin = await getAdminByLogin(login);
      if (!admin) {
        return NextResponse.json({ error: "Логин не найден" }, { status: 404 });
      }
      return NextResponse.json(publicAdmin(admin));
    }
    const admin = await ensureDefaultAdmin();
    return NextResponse.json(publicAdmin(admin));
  } catch (error) {
    console.error("Ошибка получения администратора:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = adminAuthSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { login, password } = parsed.data;

  const rateLimit = checkAdminLoginRateLimit(request);
  if (!rateLimit.allowed) {
    return tooManyRequestsResponse("adminLogin", rateLimit.retryAfterSeconds);
  }

  const gate = checkLoginGate(request, login);
  if (!gate.allowed) {
    return NextResponse.json(
      { error: loginBlockMessage(gate.retryAfterSeconds) },
      { status: 429 }
    );
  }

  if (!(await isDatabaseAvailable())) {
    if (login !== mockAdmin.login) {
      registerLoginFailure(request, login);
      return NextResponse.json({ error: "Логин не найден" }, { status: 404 });
    }
    if (!mockAdmin.password || !verifyPassword(password, mockAdmin.password)) {
      registerLoginFailure(request, login);
      return NextResponse.json({ error: "Неверный пароль" }, { status: 401 });
    }
    clearLoginFailures(request, login);
    return NextResponse.json({ admin: publicAdmin(mockAdmin) });
  }

  try {
    await ensureDefaultAdmin();
    const admin = await authenticateAdmin(login, password);
    clearLoginFailures(request, login);
    return NextResponse.json({ admin: publicAdmin(admin) });
  } catch (error) {
    if (error instanceof Error && error.message === ADMIN_NOT_FOUND) {
      registerLoginFailure(request, login);
      return NextResponse.json({ error: "Логин не найден" }, { status: 404 });
    }
    if (error instanceof Error && error.message === ADMIN_WRONG_PASSWORD) {
      registerLoginFailure(request, login);
      return NextResponse.json({ error: "Неверный пароль" }, { status: 401 });
    }
    console.error("Ошибка авторизации администратора:", error);
    return NextResponse.json(
      { error: "Ошибка авторизации администратора" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = updateAdminCredentialsSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { currentPassword, login, password, role } = parsed.data;

  // Текущий пользователь определяется по заголовку сессии.
  const currentLogin = sessionLogin(request);
  if (!currentLogin) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }

  try {
    await ensureDefaultAdmin();
    const updated = await updateAdminCredentials(
      currentLogin,
      currentPassword,
      {
        login,
        password,
        ...(role !== undefined && role !== null ? { role } : {}),
      }
    );
    return NextResponse.json(publicAdmin(updated));
  } catch (error) {
    if (error instanceof Error && error.message === ADMIN_WRONG_PASSWORD) {
      return NextResponse.json(
        { error: "Неверный текущий пароль" },
        { status: 401 }
      );
    }
    if (error instanceof Error && error.message === ADMIN_NOT_FOUND) {
      return NextResponse.json({ error: "Логин не найден" }, { status: 404 });
    }
    if (error instanceof Error && error.message === "ADMIN_LOGIN_CONFLICT") {
      return NextResponse.json(
        { error: "Администратор с таким логином уже существует" },
        { status: 409 }
      );
    }
    console.error("Ошибка обновления данных администратора:", error);
    return NextResponse.json(
      { error: "Ошибка обновления данных администратора" },
      { status: 500 }
    );
  }
}
