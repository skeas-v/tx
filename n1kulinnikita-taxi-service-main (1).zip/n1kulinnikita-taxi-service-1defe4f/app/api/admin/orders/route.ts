import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  deleteOrdersByIds,
  getAllOrders,
  getAdminByLogin,
} from "@/lib/models";
import { clearOrdersSchema } from "@/lib/validation/admin-orders";

const SESSION_HEADER = "x-admin-login";

async function resolveActor(
  request: NextRequest,
  dbAvailable: boolean
): Promise<{ login: string; role: AdminRole } | null> {
  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) return null;
  if (!dbAvailable) return null;
  const admin = await getAdminByLogin(login);
  if (!admin) return null;
  return { login: admin.login, role: admin.role };
}

// POST /api/admin/orders — очистка заказов из админ-панели (только
// разработчик). Без ids удаляются все заказы, с ids — только выбранные.
// Возвращает количество реально удалённых заказов.
export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const actor = await resolveActor(request, true);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  if (actor.role !== AdminRole.DEVELOPER) {
    return NextResponse.json(
      { error: "Очистка заказов доступна только разработчику" },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = clearOrdersSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const { ids } = parsed.data;
    let toDelete: string[];
    if (ids !== undefined && ids.length > 0) {
      toDelete = ids;
    } else {
      const orders = await getAllOrders();
      toDelete = orders.map((o) => o.id);
    }
    const before = toDelete.length;
    await deleteOrdersByIds(toDelete);
    return NextResponse.json({ affected: before });
  } catch (error) {
    console.error("Ошибка очистки заказов:", error);
    return NextResponse.json(
      { error: "Ошибка очистки заказов" },
      { status: 500 }
    );
  }
}
