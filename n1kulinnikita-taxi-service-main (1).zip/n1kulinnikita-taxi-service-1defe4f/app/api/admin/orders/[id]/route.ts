import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  cancelOrder,
  deleteOrder,
  getAdminByLogin,
  getOrderById,
  releaseOrder,
} from "@/lib/models";
import { adminOrderActionSchema } from "@/lib/validation/admin-orders";

type Params = { id: string };

const SESSION_HEADER = "x-admin-login";

// POST /api/admin/orders/[id] — действия над заказом из админ-панели:
// - cancel (отменить, статус cancelled) — разработчик и администратор;
// - release (снять с водителя, заказ возвращается в очередь) — разработчик
//   и администратор;
// - delete (полное удаление из БД) — только разработчик.
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  // Действия над заказами доступны только разработчику и администратору;
  // редактор заказы только просматривает.
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для действий с заказами" },
      { status: 403 }
    );
  }

  const { id } = await params;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = adminOrderActionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { action } = parsed.data;

  // Удаление заказа — только разработчик.
  if (action === "delete" && actor.role !== AdminRole.DEVELOPER) {
    return NextResponse.json(
      { error: "Удаление заказов доступно только разработчику" },
      { status: 403 }
    );
  }

  try {
    const existing = await getOrderById(id);
    if (!existing) {
      return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
    }

    if (action === "cancel") {
      const order = await cancelOrder(id);
      return NextResponse.json(order);
    }

    if (action === "release") {
      const order = await releaseOrder(id);
      return NextResponse.json(order);
    }

    await deleteOrder(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Ошибка выполнения действия над заказом:", error);
    return NextResponse.json(
      { error: "Ошибка выполнения действия над заказом" },
      { status: 500 }
    );
  }
}
