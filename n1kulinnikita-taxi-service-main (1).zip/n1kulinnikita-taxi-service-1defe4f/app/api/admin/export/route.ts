import { NextResponse } from "next/server";
import { saveEncryptedBackup } from "@/lib/export";

export async function POST() {
  try {
    const result = await saveEncryptedBackup();
    return NextResponse.json({ ok: true, ...result });
  } catch (error) {
    console.error("Ошибка экспорта данных:", error);
    return NextResponse.json(
      { error: "Не удалось сохранить зашифрованный файл" },
      { status: 500 }
    );
  }
}
