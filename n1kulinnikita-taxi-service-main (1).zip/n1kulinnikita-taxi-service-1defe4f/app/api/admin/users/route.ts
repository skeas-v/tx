import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  ADMIN_ROLE_LABELS,
  AdminRole,
  createAdmin,
  ensureDefaultAdmin,
  getAllAdmins,
  getAdminByLogin,
  publicAdmin,
} from "@/lib/models";
import { mockAdmin } from "@/lib/mock-data";
import { createAdminSchema } from "@/lib/validation/admins";

const SESSION_HEADER = "x-admin-login";

async function resolveActor(
  request: NextRequest,
  dbAvailable: boolean
): Promise<{ login: string; role: AdminRole } | null> {
  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) return null;
  if (!dbAvailable) {
    if (login !== mockAdmin.login) return null;
    return { login: mockAdmin.login, role: mockAdmin.role };
  }
  const admin = await getAdminByLogin(login);
  if (!admin) return null;
  return { login: admin.login, role: admin.role };
}

export async function GET(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();
  const actor = await resolveActor(request, dbAvailable);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для управления доступом" },
      { status: 403 }
    );
  }

  if (!dbAvailable) {
    // В статическом режиме скрываем аккаунт разработчика от администратора.
    return NextResponse.json(
      actor.role === AdminRole.DEVELOPER ? [publicAdmin(mockAdmin)] : []
    );
  }

  try {
    await ensureDefaultAdmin();
    const admins = await getAllAdmins();
    // Администраторы (и редакторы) не видят аккаунты разработчиков —
    // только обычных администраторов и редакторов. Разработчик видит всех.
    const visible =
      actor.role === AdminRole.DEVELOPER
        ? admins
        : admins.filter((a) => a.role !== AdminRole.DEVELOPER);
    return NextResponse.json(visible.map((a) => publicAdmin(a)));
  } catch (error) {
    console.error("Ошибка получения администраторов:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const actor = await resolveActor(request, true);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для управления доступом" },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = createAdminSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { login, password, role } = parsed.data;
  const targetRole = role ?? AdminRole.ADMIN;

  // Администратор (не разработчик) не может создавать разработчиков.
  if (actor.role === AdminRole.ADMIN && targetRole === AdminRole.DEVELOPER) {
    return NextResponse.json(
      { error: "Администратор не может назначать роль разработчика" },
      { status: 403 }
    );
  }

  try {
    const admin = await createAdmin({ login, password, role: targetRole });
    return NextResponse.json(publicAdmin(admin), { status: 201 });
  } catch (error) {
    console.error("Ошибка создания администратора:", error);
    if (error instanceof Error && error.message === "ADMIN_LOGIN_CONFLICT") {
      return NextResponse.json(
        { error: "Администратор с таким логином уже существует" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка создания администратора" },
      { status: 500 }
    );
  }
}

// Роли, которые может назначать администратор (не разработчик).
// Экспортируется для контроля доступа в управлении пользователями.
export function canManageRole(actorRole: AdminRole, targetRole: AdminRole) {
  if (actorRole === AdminRole.DEVELOPER) return true;
  if (actorRole === AdminRole.ADMIN) {
    return targetRole !== AdminRole.DEVELOPER;
  }
  return false;
}

export const ADMIN_ROLE_OPTIONS = Object.values(AdminRole).map((role) => ({
  value: role,
  label: (ADMIN_ROLE_LABELS as Record<string, string>)[role] ?? role,
}));
