import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  ADMIN_NOT_FOUND,
  AdminRole,
  deleteAdminById,
  ensureDefaultAdmin,
  getAdminByLogin,
  publicAdmin,
  updateAdminById,
} from "@/lib/models";
import { updateAdminSchema } from "@/lib/validation/admins";

type Params = { id: string };

const SESSION_HEADER = "x-admin-login";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для управления доступом" },
      { status: 403 }
    );
  }

  const { id } = await params;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = updateAdminSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { role, password } = parsed.data;

  try {
    await ensureDefaultAdmin();
    const target = await getAdminByLogin(id);
    if (!target) {
      return NextResponse.json(
        { error: "Администратор не найден" },
        { status: 404 }
      );
    }

    // Администратор и редактор не могут изменять аккаунт разработчика:
    // менять роль или сбрасывать пароль (редактирование запрещено).
    if (
      target.role === AdminRole.DEVELOPER &&
      actor.role !== AdminRole.DEVELOPER
    ) {
      return NextResponse.json(
        { error: "Нельзя изменять аккаунт разработчика" },
        { status: 403 }
      );
    }

    if (role !== undefined && role !== null) {
      // Администратор (не разработчик) не может назначать роль разработчика.
      if (actor.role === AdminRole.ADMIN && role === AdminRole.DEVELOPER) {
        return NextResponse.json(
          { error: "Администратор не может назначать роль разработчика" },
          { status: 403 }
        );
      }
    }

    const updated = await updateAdminById(id, {
      ...(role !== undefined && role !== null ? { role } : {}),
      ...(password !== undefined ? { password } : {}),
    });
    return NextResponse.json(publicAdmin(updated));
  } catch (error) {
    console.error("Ошибка обновления администратора:", error);
    if (error instanceof Error && error.message === ADMIN_NOT_FOUND) {
      return NextResponse.json(
        { error: "Администратор не найден" },
        { status: 404 }
      );
    }
    if (error instanceof Error && error.message === "ADMIN_LAST_DEVELOPER") {
      return NextResponse.json(
        { error: "Нельзя изменить роль последнего разработчика" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка обновления администратора" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const actor = await getAdminByLogin(login);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  if (actor.role !== AdminRole.DEVELOPER && actor.role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для управления доступом" },
      { status: 403 }
    );
  }

  const { id } = await params;

  try {
    await ensureDefaultAdmin();
    const target = await getAdminByLogin(id);
    if (!target) {
      return NextResponse.json(
        { error: "Администратор не найден" },
        { status: 404 }
      );
    }
    if (
      target.role === AdminRole.DEVELOPER &&
      actor.role !== AdminRole.DEVELOPER
    ) {
      return NextResponse.json(
        { error: "Администратор не может удалить разработчика" },
        { status: 403 }
      );
    }

    await deleteAdminById(id, actor.login);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Ошибка удаления администратора:", error);
    if (error instanceof Error && error.message === ADMIN_NOT_FOUND) {
      return NextResponse.json(
        { error: "Администратор не найден" },
        { status: 404 }
      );
    }
    if (error instanceof Error && error.message === "ADMIN_LAST_DEVELOPER") {
      return NextResponse.json(
        { error: "Нельзя удалить последнего разработчика" },
        { status: 409 }
      );
    }
    if (error instanceof Error && error.message === "ADMIN_DELETE_SELF") {
      return NextResponse.json(
        { error: "Нельзя удалить собственную учётную запись" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "Ошибка удаления администратора" },
      { status: 500 }
    );
  }
}
