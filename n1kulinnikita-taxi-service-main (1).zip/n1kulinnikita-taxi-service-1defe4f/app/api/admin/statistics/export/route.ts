import { NextRequest, NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  getAllAdmins,
  getAllDrivers,
  getAllOrders,
  getAppSettings,
} from "@/lib/models";
import { mockAdmin } from "@/lib/mock-data";
import {
  statisticsExportSchema,
  type StatisticsExportInput,
} from "@/lib/validation/statistics";
import {
  computeDailyDriverLineStats,
  computeStatistics,
  estimateOrderAmount,
  resolveCustomPeriod,
  resolveStatisticsPeriod,
  type StatisticsPeriod,
} from "@/lib/statistics";
import type { Admin, Order } from "@/lib/models";

const SESSION_HEADER = "x-admin-login";

async function resolveActor(
  request: NextRequest,
  dbAvailable: boolean
): Promise<Admin | null> {
  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) return null;
  if (!dbAvailable) {
    if (login !== mockAdmin.login) return null;
    return mockAdmin;
  }
  const admins = await getAllAdmins();
  return admins.find((a) => a.login === login || a.id === login) ?? null;
}

async function resolveData(dbAvailable: boolean): Promise<{
  orders: Order[];
  drivers: Awaited<ReturnType<typeof getAllDrivers>>;
}> {
  if (dbAvailable) {
    const [orders, drivers] = await Promise.all([
      getAllOrders(),
      getAllDrivers(),
    ]);
    return { orders, drivers };
  }
  const { mockOrders, mockDrivers } = await import("@/lib/mock-data");
  return { orders: mockOrders, drivers: mockDrivers };
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

function buildSheet(
  workbook: ExcelJS.Workbook,
  stats: {
    period: StatisticsPeriod;
    orders: Order[];
    ordersCount: number;
    ordersAmount: number;
    driversTotal: number;
    driversActive: number;
    ordersByStatus: Array<{ status: string; count: number; amount: number }>;
  },
  commissionPerOrder: number
) {
  const sheet = workbook.addWorksheet("Статистика");
  const columns = ["Показатель", "Значение"] as const;
  sheet.columns = [
    { key: "name", width: 42 },
    { key: "value", width: 24 },
  ];

  sheet.addRow(columns).font = { bold: true };
  sheet.addRow(["Период", stats.period.label]);
  sheet.addRow(["Диапазон", stats.period.rangeLabel]);
  sheet.addRow(["Заказов за период", stats.ordersCount]);
  sheet.addRow(["Сумма заказов, ₽", round2(stats.ordersAmount)]);
  sheet.addRow(["Водителей всего", stats.driversTotal]);
  sheet.addRow(["Водителей на линии (активных)", stats.driversActive]);
  sheet.addRow(["Комиссия с одной заявки, ₽", round2(commissionPerOrder)]);
  sheet.addRow([
    "Итоговый заработок (заявки × комиссия), ₽",
    round2(stats.ordersCount * commissionPerOrder),
  ]);

  // Детализация по статусам заказов.
  const statusLabels: Record<string, string> = {
    waiting: "Ожидает водителя",
    assigned: "Взят в работу",
    in_progress: "В пути",
    completed: "Выполнен",
    cancelled: "Отменён",
  };
  for (const s of stats.ordersByStatus) {
    sheet.addRow([`${statusLabels[s.status] ?? s.status}, заказов`, s.count]);
    sheet.addRow([
      `${statusLabels[s.status] ?? s.status}, сумма, ₽`,
      round2(s.amount),
    ]);
  }

  // Второй лист — детальная таблица заказов за период.
  const detail = workbook.addWorksheet("Заказы");
  detail.columns = [
    { key: "id", width: 10 },
    { key: "status", width: 18 },
    { key: "createdAt", width: 20 },
    { key: "from", width: 34 },
    { key: "to", width: 34 },
    { key: "clientName", width: 18 },
    { key: "clientPhone", width: 18 },
    { key: "driverName", width: 22 },
    { key: "amount", width: 12 },
  ];
  detail.addRow([
    "Номер",
    "Статус",
    "Создан",
    "Откуда",
    "Куда",
    "Клиент",
    "Телефон",
    "Водитель",
    "Сумма, ₽",
  ]).font = { bold: true };

  const statusLabelsDetail: Record<string, string> = {
    waiting: "Ожидает водителя",
    assigned: "Взят в работу",
    in_progress: "В пути",
    completed: "Выполнен",
    cancelled: "Отменён",
  };

  const periodOrders = stats.orders.filter((order) => {
    if (!order.createdAt) return false;
    return (
      order.createdAt >= stats.period.from && order.createdAt <= stats.period.to
    );
  });

  for (const order of periodOrders) {
    detail.addRow([
      order.id,
      statusLabelsDetail[order.status] ?? order.status,
      order.createdAt ? new Date(order.createdAt).toLocaleString("ru-RU") : "",
      order.from,
      order.to,
      order.clientName ?? "",
      order.clientPhone ?? "",
      order.driverName ?? "",
      round2(estimateOrderAmount(order)),
    ]);
  }

  // Третий лист — выходы водителей на линию по дням.
  const line = workbook.addWorksheet("Выходы водителей");
  line.columns = [
    { key: "date", width: 14 },
    { key: "onLine", width: 26 },
    { key: "ordersCount", width: 18 },
  ];
  line.addRow(["Дата", "Водитель вышел на линию", "Заказов за день"]).font = {
    bold: true,
  };

  const lineStats = computeDailyDriverLineStats(stats.orders, stats.period);
  for (const row of lineStats) {
    line.addRow([
      row.dateLabel,
      row.driverOnLine ? "✓ да" : "✗ нет",
      row.ordersCount,
    ]);
  }
}

export async function POST(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();
  const actor = await resolveActor(request, dbAvailable);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const role = actor.role ?? AdminRole.ADMIN;
  if (role !== AdminRole.DEVELOPER && role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для выгрузки статистики" },
      { status: 403 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = statisticsExportSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const input = parsed.data as StatisticsExportInput;
  const hasCustom = Boolean(input.fromDate && input.toDate);

  const period = hasCustom
    ? resolveCustomPeriod(input.fromDate as string, input.toDate as string)
    : resolveStatisticsPeriod(input.period ?? "month");

  const { orders, drivers } = await resolveData(dbAvailable);

  const settings = await getAppSettings().catch(() => null);
  const commissionPerOrder =
    input.commissionPerOrder !== undefined
      ? input.commissionPerOrder
      : (settings?.commissionPerOrder ?? 10);

  const stats = computeStatistics(orders, drivers, period);

  try {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = "Ride admin";
    buildSheet(workbook, { ...stats, orders }, commissionPerOrder);

    const buffer = await workbook.xlsx.writeBuffer();
    const stamp = new Date().toISOString().slice(0, 10);
    const filename = `statistics-${stamp}.xlsx`;

    return new NextResponse(new Uint8Array(buffer as ArrayBuffer), {
      status: 200,
      headers: {
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("Ошибка формирования Excel-файла:", error);
    return NextResponse.json(
      { error: "Не удалось сформировать файл Excel" },
      { status: 500 }
    );
  }
}
