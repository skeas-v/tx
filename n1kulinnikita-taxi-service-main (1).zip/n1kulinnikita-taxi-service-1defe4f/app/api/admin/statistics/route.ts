import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  AdminRole,
  getAllAdmins,
  getAllDrivers,
  getAllOrders,
  getAppSettings,
} from "@/lib/models";
import { mockAdmin } from "@/lib/mock-data";
import { statisticsPeriodSchema } from "@/lib/validation/statistics";
import { computeStatistics, resolveStatisticsPeriod } from "@/lib/statistics";
import type { Admin } from "@/lib/models";

const SESSION_HEADER = "x-admin-login";

// Текущий администратор по заголовку сессии (как в других admin-эндпоинтах).
async function resolveActor(
  request: NextRequest,
  dbAvailable: boolean
): Promise<Admin | null> {
  const login = request.headers.get(SESSION_HEADER)?.trim();
  if (!login) return null;
  if (!dbAvailable) {
    if (login !== mockAdmin.login) return null;
    return mockAdmin;
  }
  const admins = await getAllAdmins();
  return admins.find((a) => a.login === login || a.id === login) ?? null;
}

export async function GET(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();
  const actor = await resolveActor(request, dbAvailable);
  if (!actor) {
    return NextResponse.json(
      { error: "Требуется авторизация" },
      { status: 401 }
    );
  }
  const role = actor.role ?? AdminRole.ADMIN;
  if (role !== AdminRole.DEVELOPER && role !== AdminRole.ADMIN) {
    return NextResponse.json(
      { error: "Недостаточно прав для просмотра статистики" },
      { status: 403 }
    );
  }

  const { searchParams } = new URL(request.url);
  const periodParam = searchParams.get("period") ?? "month";
  const parsedPeriod = statisticsPeriodSchema.safeParse(periodParam);

  let orders;
  let drivers;
  try {
    if (dbAvailable) {
      orders = await getAllOrders();
      drivers = await getAllDrivers();
    } else {
      const { mockOrders, mockDrivers } = await import("@/lib/mock-data");
      orders = mockOrders;
      drivers = mockDrivers;
    }
  } catch (error) {
    console.error("Ошибка получения данных статистики:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных статистики" },
      { status: 500 }
    );
  }

  const period = parsedPeriod.success
    ? resolveStatisticsPeriod(parsedPeriod.data)
    : resolveStatisticsPeriod("month");

  const settings = await getAppSettings().catch(() => null);
  const statistics = computeStatistics(orders, drivers, period);

  return NextResponse.json({
    ...statistics,
    defaultCommissionPerOrder: settings?.commissionPerOrder ?? 10,
  });
}
