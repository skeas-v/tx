import { NextResponse } from "next/server";
import { collectSystemData } from "@/lib/export";

export async function GET() {
  try {
    const payload = await collectSystemData();
    const filename = `backup-${payload.exportedAt.replace(/[:.]/g, "-")}.json`;
    return new NextResponse(JSON.stringify(payload, null, 2), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("Ошибка выгрузки бэкапа:", error);
    return NextResponse.json(
      { error: "Не удалось сформировать бэкап данных" },
      { status: 500 }
    );
  }
}
