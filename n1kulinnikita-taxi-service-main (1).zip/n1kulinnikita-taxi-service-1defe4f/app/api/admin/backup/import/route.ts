import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { restoreBackup, type SystemBackupPayload } from "@/lib/export";
import { backupImportSchema } from "@/lib/validation/backup";

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Некорректный файл бэкапа" },
      { status: 400 }
    );
  }

  const parsed = backupImportSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректный файл бэкапа", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const counts = await restoreBackup(
      parsed.data.payload as unknown as SystemBackupPayload
    );
    return NextResponse.json({ ok: true, counts });
  } catch (error) {
    console.error("Ошибка восстановления бэкапа:", error);
    return NextResponse.json(
      { error: "Не удалось восстановить данные из бэкапа" },
      { status: 500 }
    );
  }
}
