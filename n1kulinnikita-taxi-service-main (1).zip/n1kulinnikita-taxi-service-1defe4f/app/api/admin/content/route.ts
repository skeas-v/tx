import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAppSettings, updateAppSettings } from "@/lib/models";
import { mockAppSettings } from "@/lib/mock-data";
import { updateContentSettingsSchema } from "@/lib/validation/content";

export async function GET() {
  try {
    const settings = await getAppSettings();
    return NextResponse.json({
      rulesText: settings.rulesText ?? "",
      privacyText: settings.privacyText ?? "",
    });
  } catch (error) {
    console.error("Ошибка получения текстов правил и политики:", error);
    return NextResponse.json(
      { error: "Ошибка получения текстов правил и политики" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      {
        error: "База данных недоступна в статическом режиме",
        settings: {
          rulesText: mockAppSettings.rulesText ?? "",
          privacyText: mockAppSettings.privacyText ?? "",
        },
      },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = updateContentSettingsSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const updated = await updateAppSettings({
      rulesText: parsed.data.rulesText,
      privacyText: parsed.data.privacyText,
    });
    return NextResponse.json({
      rulesText: updated.rulesText ?? "",
      privacyText: updated.privacyText ?? "",
    });
  } catch (error) {
    console.error("Ошибка сохранения текстов правил и политики:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения текстов правил и политики" },
      { status: 500 }
    );
  }
}
