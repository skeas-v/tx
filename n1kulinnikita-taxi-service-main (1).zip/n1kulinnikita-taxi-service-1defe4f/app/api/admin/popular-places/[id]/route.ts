import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  deletePopularPlace,
  getPopularPlaceById,
  updatePopularPlace,
} from "@/lib/models";
import { popularPlaceSchema } from "@/lib/validation/popular-places";

type Params = { id: string };

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { id } = await params;
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = popularPlaceSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const existing = await getPopularPlaceById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Популярное место не найдено" },
        { status: 404 }
      );
    }
    const updated = await updatePopularPlace(id, parsed.data);
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Ошибка обновления популярного места:", error);
    return NextResponse.json(
      { error: "Ошибка обновления популярного места" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { id } = await params;
  try {
    const existing = await getPopularPlaceById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Популярное место не найдено" },
        { status: 404 }
      );
    }
    await deletePopularPlace(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Ошибка удаления популярного места:", error);
    return NextResponse.json(
      { error: "Ошибка удаления популярного места" },
      { status: 500 }
    );
  }
}
