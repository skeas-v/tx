import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { createPopularPlace, getAllPopularPlaces } from "@/lib/models";
import { mockPopularPlaces } from "@/lib/mock-data";
import { popularPlaceSchema } from "@/lib/validation/popular-places";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockPopularPlaces);
  }

  try {
    return NextResponse.json(await getAllPopularPlaces());
  } catch (error) {
    console.error("Ошибка получения популярных мест:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = popularPlaceSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const place = await createPopularPlace(parsed.data);
    return NextResponse.json(place, { status: 201 });
  } catch (error) {
    console.error("Ошибка создания популярного места:", error);
    return NextResponse.json(
      { error: "Ошибка создания популярного места" },
      { status: 500 }
    );
  }
}
