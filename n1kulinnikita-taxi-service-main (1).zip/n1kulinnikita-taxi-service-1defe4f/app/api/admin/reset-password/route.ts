import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { resetDefaultDeveloperPassword } from "@/lib/models";
import { isResetAdminEnabled, isResetAdminKeyValid } from "@/lib/reset-admin";
import { resetAdminPasswordSchema } from "@/lib/validation/reset-admin";

// Эндпоинт использует Node-модуль crypto (timingSafeEqual) — явно указываем
// Node.js runtime, чтобы не попадать в Edge Runtime.
export const runtime = "nodejs";

// Скрытый эндпоинт сброса пароля администратора/разработчика.
// Доступен только при заданном секрете ADMIN_RESET_SECRET, ключ проверяется
// на сервере (без правильного ключа — 404/403). Запись в БД выполняется
// только при полностью валидном запросе и рабочей базе данных.
export async function POST(request: NextRequest) {
  if (!isResetAdminEnabled()) {
    return NextResponse.json({ error: "Не найдено" }, { status: 404 });
  }

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const parsed = resetAdminPasswordSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { key, password } = parsed.data;

  if (!isResetAdminKeyValid(key)) {
    return NextResponse.json({ error: "Не найдено" }, { status: 404 });
  }

  try {
    const updated = await resetDefaultDeveloperPassword(password);
    return NextResponse.json({ login: updated.login, role: updated.role });
  } catch (error) {
    console.error("Ошибка сброса пароля администратора:", error);
    return NextResponse.json(
      { error: "Ошибка сброса пароля" },
      { status: 500 }
    );
  }
}
