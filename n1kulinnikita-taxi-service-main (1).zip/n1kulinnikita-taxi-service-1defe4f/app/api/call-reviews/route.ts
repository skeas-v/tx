import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { createCallReview, getAllCallReviews } from "@/lib/models";
import { mockCallReviews } from "@/lib/mock-data";
import { createCallReviewSchema } from "@/lib/validation/call-reviews";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockCallReviews);
  }

  try {
    return NextResponse.json(await getAllCallReviews());
  } catch (error) {
    console.error("Ошибка получения отзывов о вызове:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const parsed = createCallReviewSchema.safeParse(
    await request.json().catch(() => null)
  );
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const review = await createCallReview(parsed.data);
    return NextResponse.json(review, { status: 201 });
  } catch (error) {
    console.error("Ошибка сохранения отзыва о вызове:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения отзыва" },
      { status: 500 }
    );
  }
}
