import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { createFeedback, deleteFeedback, getAllFeedback } from "@/lib/models";
import { mockFeedback } from "@/lib/mock-data";
import { createFeedbackSchema } from "@/lib/validation/feedback";
import {
  checkFeedbackRateLimit,
  tooManyRequestsResponse,
} from "@/lib/rate-limit";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(mockFeedback);
  }

  try {
    return NextResponse.json(await getAllFeedback());
  } catch (error) {
    console.error("Ошибка получения запросов обратной связи:", error);
    return NextResponse.json(
      { error: "Ошибка получения запросов обратной связи" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const rateLimit = checkFeedbackRateLimit(request);
  if (!rateLimit.allowed) {
    return tooManyRequestsResponse("feedback", rateLimit.retryAfterSeconds);
  }

  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const parsed = createFeedbackSchema.safeParse(
    await request.json().catch(() => null)
  );
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const item = await createFeedback(parsed.data);
    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error("Ошибка сохранения запроса обратной связи:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения запроса обратной связи" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const id = new URL(request.url).searchParams.get("id");
  if (!id) {
    return NextResponse.json({ error: "id обязателен" }, { status: 400 });
  }

  try {
    await deleteFeedback(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Ошибка удаления запроса обратной связи:", error);
    return NextResponse.json(
      { error: "Ошибка удаления запроса обратной связи" },
      { status: 500 }
    );
  }
}
