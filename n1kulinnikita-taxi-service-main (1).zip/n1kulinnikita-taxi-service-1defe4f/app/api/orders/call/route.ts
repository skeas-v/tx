import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  checkOrdersCallRateLimit,
  tooManyRequestsResponse,
} from "@/lib/rate-limit";
import {
  OrderStatus,
  createOrder,
  findAvailableDriver,
  nextOrderId,
  publicDriver,
} from "@/lib/models";
import { mockDrivers, mockOrders } from "@/lib/mock-data";
import { createCallOrderSchema } from "@/lib/validation/orders";
import { notifyDriverAcceptedCallOrder } from "@/lib/vk-notify";

const PHONE_CALL_PLACEHOLDER_FROM = "По звонку";
const PHONE_CALL_PLACEHOLDER_TO = "По звонку";

export async function POST(request: NextRequest) {
  const rateLimit = checkOrdersCallRateLimit(request);
  if (!rateLimit.allowed) {
    return tooManyRequestsResponse("orders", rateLimit.retryAfterSeconds);
  }

  const dbAvailable = await isDatabaseAvailable();

  const body: unknown = await request.json().catch(() => null);
  const parsed = createCallOrderSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const data = parsed.data;

  let driver;
  if (dbAvailable) {
    try {
      driver = await findAvailableDriver();
    } catch (error) {
      console.error("Ошибка поиска свободного водителя:", error);
      return NextResponse.json(
        { error: "Ошибка получения данных из DynamoDB" },
        { status: 500 }
      );
    }
  } else {
    const activeOrders = mockOrders.filter(
      (order) =>
        order.driverName &&
        order.status !== OrderStatus.COMPLETED &&
        order.status !== OrderStatus.CANCELLED &&
        !order.confirmResult
    );
    driver =
      mockDrivers.find(
        (d) =>
          d.isOnLine &&
          !d.isBlocked &&
          !!d.phone?.trim() &&
          !activeOrders.some(
            (o) => o.driverName === d.name || o.driverName === d.id
          )
      ) ?? null;
  }

  if (!driver) {
    return NextResponse.json({ driver: null });
  }

  if (!dbAvailable) {
    return NextResponse.json({ driver: publicDriver(driver), order: null });
  }

  try {
    const order = await createOrder({
      id: await nextOrderId(),
      from: PHONE_CALL_PLACEHOLDER_FROM,
      to: PHONE_CALL_PLACEHOLDER_TO,
      clientName: data.clientName,
      clientPhone: data.clientPhone,
      driverId: driver.id,
      driverName: driver.name,
      phoneCall: true,
      confirmResult: null,
      status: OrderStatus.WAITING,
    });

    // Заявка по звонку, которую принял водитель без премиум-аккаунта,
    // отправляется в беседу ВКонтакте: «Водитель: (имя, гос. номер) принял
    // заказ с сайта № заказа». Водители с включённым премиум-аккаунтом
    // получают заказы с сайта напрямую и в беседе не публикуются.
    if (!driver.isPremium) {
      await notifyDriverAcceptedCallOrder({
        orderId: order.id,
        driverName: driver.name,
        driverCarNumber: driver.carNumber,
      }).catch(() => {});
    }

    return NextResponse.json(
      { driver: publicDriver(driver), order },
      { status: 201 }
    );
  } catch (error) {
    console.error("Ошибка создания заказа по звонку:", error);
    return NextResponse.json(
      { error: "Ошибка создания заказа по звонку" },
      { status: 500 }
    );
  }
}
