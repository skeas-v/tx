import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  attachDriverInfo,
  getOrderById,
  updateOrderConfirmResult,
  updateOrderStatus,
  withDriverInfo,
} from "@/lib/models";
import { mockDrivers, mockOrders } from "@/lib/mock-data";
import {
  confirmOrderSchema,
  updateOrderStatusSchema,
} from "@/lib/validation/orders";

type Params = { id: string };

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  const { id } = await params;
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    const mock = mockOrders.find((o) => o.id === id);
    if (!mock) {
      return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
    }
    return NextResponse.json(withDriverInfo([mock], mockDrivers)[0]);
  }

  try {
    const order = await getOrderById(id);
    if (!order) {
      return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
    }
    const [enriched] = await attachDriverInfo([order]);
    return NextResponse.json(enriched);
  } catch (error) {
    console.error("Ошибка получения заказа:", error);
    return NextResponse.json(
      { error: "Ошибка получения заказа из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { id } = await params;
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });
  }

  const confirmed = confirmOrderSchema.safeParse(body);
  if (confirmed.success) {
    try {
      const order = await updateOrderConfirmResult(
        id,
        confirmed.data.confirmResult
      );
      if (!order) {
        return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
      }
      const [enriched] = await attachDriverInfo([order]);
      return NextResponse.json(enriched);
    } catch (error) {
      console.error("Ошибка подтверждения заказа:", error);
      return NextResponse.json(
        { error: "Ошибка подтверждения заказа" },
        { status: 500 }
      );
    }
  }

  const parsed = updateOrderStatusSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const order = await updateOrderStatus(id, parsed.data);
    if (!order) {
      return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
    }
    const [enriched] = await attachDriverInfo([order]);
    return NextResponse.json(enriched);
  } catch (error) {
    console.error("Ошибка обновления статуса заказа:", error);
    return NextResponse.json(
      { error: "Ошибка обновления статуса заказа" },
      { status: 500 }
    );
  }
}
