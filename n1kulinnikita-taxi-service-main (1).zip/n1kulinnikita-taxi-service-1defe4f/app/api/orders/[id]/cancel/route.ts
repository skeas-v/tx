import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { cancelOrder, formatOrderNumber, getOrderById } from "@/lib/models";
import { cancelOrderInVkGroup, sendTextToVkGroup } from "@/lib/vk-notify";

type Params = { id: string };

// POST /api/orders/[id]/cancel — отмена заказа клиентом со страницы /track.
// Назначает заказу статус «отменён» и очищает водителя, уведомляет водителя
// в панели и в беседе ВКонтакте, редактирует сообщение с заказом в беседе
// («ОТМЕНЕНО КЛИЕНТОМ», кнопки убираются). Если переменные окружения VK_* не
// заданы или произошла ошибка VK — заказ всё равно отменяется и приложение
// продолжает работать без сбоев.
export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<Params> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { id } = await params;

  try {
    const existing = await getOrderById(id);
    if (!existing) {
      return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
    }

    const order = await cancelOrder(id);

    if (existing.conversationMessageId && !existing.driverName) {
      await sendTextToVkGroup(
        `Заказ №${formatOrderNumber(id)} отменён клиентом`
      ).catch(() => {});
    }
    await cancelOrderInVkGroup(existing).catch(() => {});

    return NextResponse.json(order);
  } catch (error) {
    console.error("Ошибка отмены заказа:", error);
    return NextResponse.json(
      { error: "Ошибка отмены заказа" },
      { status: 500 }
    );
  }
}
