import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { checkOrderRateLimit, tooManyRequestsResponse } from "@/lib/rate-limit";
import {
  OrderStatus,
  attachDriverInfo,
  createOrder,
  findPremiumAvailableDriver,
  getAllOrders,
  getAllSuburbanAddresses,
  getOrdersByDriver,
  getOrdersByStatus,
  nextOrderId,
  updateOrderConversationMessageId,
  updateOrderStatus,
  withDriverInfo,
} from "@/lib/models";
import { mockDrivers, mockOrders } from "@/lib/mock-data";
import { createOrderSchema } from "@/lib/validation/orders";
import { sendOrderToVkGroup } from "@/lib/vk-notify";
import { resolveTripPrice } from "@/lib/suburban";
import { resolvePopularPlacePrice } from "@/lib/popular-place";
import { getAllPopularPlaces } from "@/lib/models";
import type { CreateOrderInput } from "@/lib/validation/orders";

interface SuburbanPriceSnapshot {
  name: string;
  price: number;
  basePrice: number;
  surcharge: number;
  direction: "to" | "from";
  peakEnabled: boolean;
  peakSurcharge: number;
  nightEnabled: boolean;
  nightSurcharge: number;
}

export async function resolvePopularPlacePriceWithDb(
  data: Pick<CreateOrderInput, "from" | "to" | "fromAddress" | "toAddress">
): Promise<{ name: string; price: number } | null> {
  const places = await getAllPopularPlaces();
  return resolvePopularPlacePrice(
    places,
    data.fromAddress || data.from,
    data.toAddress || data.to
  );
}

export async function resolveTripPriceWithDb(
  data: Pick<CreateOrderInput, "from" | "to" | "fromAddress" | "toAddress">
): Promise<SuburbanPriceSnapshot | null> {
  const addresses = await getAllSuburbanAddresses();
  const resolved = resolveTripPrice(
    addresses,
    data.fromAddress || data.from,
    data.toAddress || data.to
  );
  if (!resolved) return null;

  const hit =
    resolved.direction === "from"
      ? addresses.find((a) => a.name === resolved.fromAddress)
      : addresses.find((a) => a.name === resolved.toAddress);

  return {
    name: resolved.matchedName,
    price: resolved.price,
    basePrice: resolved.basePrice,
    surcharge: resolved.surcharge,
    direction: resolved.direction,
    peakEnabled: hit?.peakEnabled ?? false,
    peakSurcharge: hit?.peakSurcharge ?? 0,
    nightEnabled: hit?.nightEnabled ?? false,
    nightSurcharge: hit?.nightSurcharge ?? 0,
  };
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const driver = searchParams.get("driver");
  const all = searchParams.get("all") === "true";
  const phoneCall = searchParams.get("phoneCall") === "true";
  const dbAvailable = await isDatabaseAvailable();

  if (dbAvailable) {
    try {
      if (all) {
        const orders = (await getAllOrders()).sort((a, b) =>
          (b.createdAt ?? "").localeCompare(a.createdAt ?? "")
        );
        return NextResponse.json(await attachDriverInfo(orders));
      }
      if (driver) {
        const driverOrders = await getOrdersByDriver(driver);
        if (status) {
          return NextResponse.json(
            await attachDriverInfo(
              driverOrders.filter((o) => o.status === status)
            )
          );
        }
        if (phoneCall) {
          return NextResponse.json(
            await attachDriverInfo(driverOrders.filter((o) => o.phoneCall))
          );
        }
        return NextResponse.json(
          await attachDriverInfo(
            driverOrders.filter(
              (o) => o.status !== OrderStatus.COMPLETED && !o.phoneCall
            )
          )
        );
      }
      if (status) {
        return NextResponse.json(
          await attachDriverInfo(await getOrdersByStatus(status))
        );
      }
      const orders = (await getOrdersByStatus(OrderStatus.WAITING)).filter(
        (o) => !o.phoneCall
      );
      return NextResponse.json(await attachDriverInfo(orders));
    } catch (error) {
      console.error("Ошибка получения заказов:", error);
      return NextResponse.json(
        { error: "Ошибка получения данных из DynamoDB" },
        { status: 500 }
      );
    }
  }

  if (all) {
    return NextResponse.json(withDriverInfo(mockOrders, mockDrivers));
  }
  if (driver) {
    const driverOrders = mockOrders.filter((o) => o.driverName === driver);
    if (status) {
      return NextResponse.json(
        withDriverInfo(
          driverOrders.filter((o) => o.status === status),
          mockDrivers
        )
      );
    }
    if (phoneCall) {
      return NextResponse.json(
        withDriverInfo(
          driverOrders.filter((o) => o.phoneCall),
          mockDrivers
        )
      );
    }
    return NextResponse.json(
      withDriverInfo(
        driverOrders.filter(
          (o) =>
            o.status !== OrderStatus.COMPLETED &&
            o.status !== OrderStatus.CANCELLED &&
            !o.phoneCall
        ),
        mockDrivers
      )
    );
  }
  const statusFilter = status ?? OrderStatus.WAITING;
  return NextResponse.json(
    withDriverInfo(
      mockOrders.filter((o) => o.status === statusFilter && !o.phoneCall),
      mockDrivers
    )
  );
}

export async function POST(request: NextRequest) {
  const rateLimit = checkOrderRateLimit(request);
  if (!rateLimit.allowed) {
    return tooManyRequestsResponse("orders", rateLimit.retryAfterSeconds);
  }

  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  try {
    const parsed = createOrderSchema.safeParse(await request.json());

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Некорректные данные", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const data = parsed.data;

    // Фиксированная цена популярного места: если один из адресов «откуда»/
    // «куда» совпадает с популярным местом, у которого администратор указал
    // цену, применяется ровно эта цена вместо тарифа по городу. Снапшот цены
    // сохраняется в заказе и показывается в карточках и уведомлении ВК.
    const popularPlacePrice = await resolvePopularPlacePriceWithDb(data);

    // Если цена популярного места совпала с одним из адресов, она имеет
    // приоритет над пригородным тарифом (как в форме заказа).
    const suburbanPrice = popularPlacePrice
      ? null
      : await resolveTripPriceWithDb(data);

    const order = await createOrder({
      id: await nextOrderId(),
      from: data.from,
      to: data.to,
      fromAddress: data.fromAddress,
      toAddress: data.toAddress,
      fromEntrance: data.fromEntrance,
      toEntrance: data.toEntrance,
      fromLat: data.fromLat,
      fromLng: data.fromLng,
      toLat: data.toLat,
      toLng: data.toLng,
      stops: data.stops,
      clientName: data.clientName,
      clientPhone: data.clientPhone,
      comment: data.comment,
      childSeat: data.childSeat,
      delivery: data.delivery,
      trunk: data.trunk,
      paymentMethod: data.paymentMethod,
      cashChangeFrom: data.cashChangeFrom,
      suburbanPrice: suburbanPrice ?? undefined,
      popularPlacePrice: popularPlacePrice ?? undefined,
      status: OrderStatus.WAITING,
    });

    // Премиум-аккаунт: если разработчик включил его водителю, все входящие
    // заказы с сайта достаются этому водителю (если он на линии и не занят).
    // Такой заказ назначается сразу и не публикуется в общей очереди,
    // поэтому остаётся виден только в админ-панели (статистика разработчика).
    const premiumDriver = await findPremiumAvailableDriver();
    if (premiumDriver) {
      try {
        const assigned = await updateOrderStatus(
          order.id,
          {
            status: OrderStatus.ASSIGNED,
            driverId: premiumDriver.id,
            driverName: premiumDriver.name,
          },
          OrderStatus.WAITING
        );
        if (assigned) {
          return NextResponse.json(assigned, { status: 201 });
        }
      } catch (error) {
        console.warn(
          "Премиум-водитель не получил заказ, заказ остаётся в очереди:",
          error
        );
      }
    }

    const notification = await sendOrderToVkGroup(order);
    if (
      notification.sent &&
      notification.conversationMessageId != null &&
      notification.conversationMessageId > 0
    ) {
      try {
        await updateOrderConversationMessageId(
          order.id,
          notification.conversationMessageId
        );
      } catch (error) {
        console.warn("VK: не удалось сохранить cmid заказа:", error);
      }
    }

    return NextResponse.json(order, { status: 201 });
  } catch (error) {
    console.error("Ошибка создания заказа:", error);
    return NextResponse.json(
      { error: "Ошибка создания заказа" },
      { status: 500 }
    );
  }
}
