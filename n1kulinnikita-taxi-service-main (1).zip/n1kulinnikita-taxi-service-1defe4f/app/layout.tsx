import type { Metadata, Viewport } from "next";
import Image from "next/image";
import Link from "next/link";
import "./globals.css";
import { Geist } from "next/font/google";
import { cn } from "@/lib/utils";
import { ClipboardList, Route, ShieldCheck, UserRound } from "lucide-react";
import { BridgeProvider } from "@/components/bridge-provider";
import { AppLoader } from "@/components/app-loader";
import { NotificationPermission } from "@/components/notification-permission";
import { GeolocationPermission } from "@/components/geolocation-permission";
import { PwaRegister } from "@/components/pwa-register";
import { InstallBanner } from "@/components/install-banner";
import { PushSubscribe } from "@/components/push-subscribe";
import { MaintenanceGuard } from "@/components/maintenance-guard";
import { SiteName } from "@/components/site-name";
import { RouteChrome } from "@/components/route-chrome";
import { Toaster } from "@/components/ui/sonner";
import { getAppSettings } from "@/lib/models";

const geist = Geist({ subsets: ["latin"], variable: "--font-sans" });

const appName = "Твоё Новое";

export async function generateMetadata(): Promise<Metadata> {
  let name = appName;
  try {
    const settings = await getAppSettings();
    if (settings.siteName?.trim()) name = settings.siteName.trim();
  } catch {
    // игнорируем: используем значение по умолчанию
  }
  return {
    title: name,
    description: name,
    manifest: "/manifest.webmanifest",
    icons: {
      icon: [
        { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      ],
      apple: [
        {
          url: "/icons/apple-touch-icon.png",
          sizes: "180x180",
          type: "image/png",
        },
      ],
    },
    appleWebApp: {
      capable: true,
      title: name,
      statusBarStyle: "default",
    },
  };
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ed9700",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" className={cn("font-sans", geist.variable)}>
      <link
        rel="apple-touch-startup-image"
        href="/splash/apple-splash-1290x2796.png"
        media="(device-width: 430px) and (device-height: 932px) and (-webkit-device-pixel-ratio: 3)"
      />
      <link
        rel="apple-touch-startup-image"
        href="/splash/apple-splash-1206x2622.png"
        media="(device-width: 402px) and (device-height: 874px) and (-webkit-device-pixel-ratio: 3)"
      />
      <link
        rel="apple-touch-startup-image"
        href="/splash/apple-splash-1179x2556.png"
        media="(device-width: 393px) and (device-height: 852px) and (-webkit-device-pixel-ratio: 3)"
      />
      <link
        rel="apple-touch-startup-image"
        href="/splash/apple-splash-1125x2436.png"
        media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3)"
      />
      <link
        rel="apple-touch-startup-image"
        href="/splash/apple-splash-750x1334.png"
        media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)"
      />
      <body className="antialiased min-h-screen bg-background flex flex-col">
        <AppLoader />
        <BridgeProvider />
        <PwaRegister />
        <NotificationPermission />
        <GeolocationPermission />
        <InstallBanner />
        <PushSubscribe />
        <RouteChrome>
          <header className="sticky top-0 z-50 w-full border-b border-primary/15 bg-background/80 backdrop-blur-md">
            <div className="container mx-auto px-4 h-14 flex items-center">
              <Link
                href="/"
                className="flex items-center gap-2 text-lg font-semibold tracking-tight"
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-lg">
                  <Image
                    src="/assets/logo.png"
                    alt="Логотип"
                    width={1024}
                    height={1024}
                    className="h-full w-full object-cover"
                  />
                </div>
                <SiteName fallback={appName} />
              </Link>
              <nav className="ml-auto flex items-center gap-1">
                <Link
                  href="/track"
                  className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary"
                >
                  <Route className="size-4" />
                  <span className="hidden sm:inline">Отследить заказ</span>
                </Link>
                <Link
                  href="/driver"
                  className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary"
                >
                  <ClipboardList className="size-4" />
                  <span className="hidden sm:inline">Панель водителя</span>
                </Link>
                <Link
                  href="/driver/cabinet"
                  className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary"
                >
                  <UserRound className="size-4" />
                  <span className="hidden sm:inline">Личный кабинет</span>
                </Link>
                <Link
                  href="/admin"
                  className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary"
                >
                  <ShieldCheck className="size-4" />
                  <span className="hidden sm:inline">Админ</span>
                </Link>
              </nav>
            </div>
          </header>
        </RouteChrome>
        <main className="flex-1">
          <MaintenanceGuard>{children}</MaintenanceGuard>
        </main>
        <RouteChrome>
          <footer className="border-t bg-background/80">
            <div className="container mx-auto px-4 py-6">
              <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
                <p className="text-xs text-muted-foreground">
                  © {new Date().getFullYear()} <SiteName fallback={appName} />
                </p>
                <nav className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm">
                  <Link
                    href="/rules"
                    className="text-muted-foreground transition-colors hover:text-primary"
                  >
                    Правила пользования
                  </Link>
                  <Link
                    href="/privacy"
                    className="text-muted-foreground transition-colors hover:text-primary"
                  >
                    Политика конфиденциальности
                  </Link>
                  <Link
                    href="/feedback"
                    className="text-muted-foreground transition-colors hover:text-primary"
                  >
                    Обратная связь
                  </Link>
                </nav>
              </div>
            </div>
          </footer>
        </RouteChrome>
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
