import { Suspense } from "react";
import { FeedbackForm } from "@/components/feedback-form";

export default function FeedbackPage() {
  return (
    <div className="relative overflow-hidden">
      <div className="gradient-hero-vibrant absolute inset-0" />
      <div className="pattern-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_top,black_25%,transparent_70%)]" />
      <div className="relative mx-auto max-w-xl px-4 py-10">
        <Suspense>
          <FeedbackForm />
        </Suspense>
      </div>
    </div>
  );
}
