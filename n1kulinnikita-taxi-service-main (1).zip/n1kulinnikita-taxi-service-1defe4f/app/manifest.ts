import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Твоё Новое Кирово-Чепецк",
    short_name: "Твоё Новое",
    description:
      "Сервис поездок в Кирово-Чепецке: укажите адреса «откуда» и «куда» — свободный водитель рядом уже в пути. Без обязательной регистрации.",
    start_url: "/",
    scope: "/",
    id: "ride-kch",
    display: "standalone",
    orientation: "portrait",
    background_color: "#fff6e3",
    theme_color: "#ed9700",
    lang: "ru",
    icons: [
      {
        src: "/icons/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-maskable-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
    categories: ["transportation", "business"],
  };
}
