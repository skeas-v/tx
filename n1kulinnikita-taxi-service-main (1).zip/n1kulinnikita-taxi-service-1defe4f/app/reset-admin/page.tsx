import { notFound } from "next/navigation";
import { isResetAdminEnabled } from "@/lib/reset-admin";
import { ResetAdminForm } from "@/components/reset-admin-form";

export const metadata = {
  title: "Сброс пароля",
  robots: {
    index: false,
    follow: false,
  },
};

// Страница динамическая: наличие секрета и ключ в URL проверяются на каждый
// запрос на сервере, поэтому она не пререндерится в статическую 404-страницу
// при отсутствии ADMIN_RESET_SECRET.
export const dynamic = "force-dynamic";

export default async function ResetAdminPage({
  searchParams,
}: {
  searchParams: Promise<{ key?: string }>;
}) {
  // Страница существует только при заданном секрете (ADMIN_RESET_SECRET).
  // Без него или с невалидным URL — недоступна (404), без ошибок приложения.
  if (!isResetAdminEnabled()) {
    notFound();
  }

  const { key = "" } = await searchParams;

  return (
    <div className="relative overflow-hidden">
      <div className="gradient-hero-vibrant absolute inset-0" />
      <div className="pattern-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_top,black_25%,transparent_70%)]" />
      <div className="relative mx-auto max-w-md px-4 py-10">
        <ResetAdminForm urlKey={key} />
      </div>
    </div>
  );
}
