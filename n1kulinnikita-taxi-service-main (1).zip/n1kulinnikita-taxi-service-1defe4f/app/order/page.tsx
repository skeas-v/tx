import { Suspense } from "react";
import { OrderPage } from "@/components/order-page";

export const metadata = {
  title: "Заказ поездки",
};

export default function OrderRoutePage() {
  return (
    <Suspense>
      <OrderPage initialAction="order" />
    </Suspense>
  );
}
