import { Suspense } from "react";
import { OrderPage } from "@/components/order-page";

export const metadata = {
  title: "Вызов водителя",
};

export default function OrderCallPage() {
  return (
    <Suspense>
      <OrderPage initialAction="call" />
    </Suspense>
  );
}
