import { Suspense } from "react";
import { OrderTracker } from "@/components/order-tracker";

export default function TrackPage() {
  return (
    <div className="relative overflow-hidden">
      <div className="gradient-hero-vibrant absolute inset-0" />
      <div className="pattern-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_top,black_25%,transparent_70%)]" />
      <div className="relative mx-auto max-w-2xl px-4 py-10">
        <Suspense>
          <OrderTracker />
        </Suspense>
      </div>
    </div>
  );
}
