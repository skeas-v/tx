import { AdminPanel } from "@/components/admin-panel";

export default function AdminPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <AdminPanel />
    </div>
  );
}
