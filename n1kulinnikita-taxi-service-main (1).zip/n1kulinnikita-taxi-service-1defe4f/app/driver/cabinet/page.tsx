import { DriverCabinet } from "@/components/driver-cabinet";

export default function DriverCabinetPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <DriverCabinet />
    </div>
  );
}
