import { DriverPanel } from "@/components/driver-panel";

export default function DriverPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <DriverPanel />
    </div>
  );
}
