import { Suspense } from "react";
import { ContentPage } from "@/components/content-page";
import { getAppSettings } from "@/lib/models";

// Страница всегда читает свежие тексты правил из настроек (DynamoDB),
// чтобы сохранённые администратором изменения сразу отображались.
export const dynamic = "force-dynamic";

export default async function RulesPage() {
  let rulesText = "";
  let siteName = "Твоё Новое";
  try {
    const settings = await getAppSettings();
    rulesText = settings.rulesText ?? "";
    siteName = settings.siteName || siteName;
  } catch {
    // игнорируем: отображаем заголовок по умолчанию
  }

  return (
    <div className="relative overflow-hidden">
      <div className="gradient-hero-vibrant absolute inset-0" />
      <div className="pattern-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_top,black_25%,transparent_70%)]" />
      <Suspense>
        <ContentPage
          title="Правила пользования"
          siteName={siteName}
          text={rulesText}
          emptyText="Правила пользования ещё не опубликованы."
        />
      </Suspense>
    </div>
  );
}
