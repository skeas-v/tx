import { Suspense } from "react";
import { ContentPage } from "@/components/content-page";
import { getAppSettings } from "@/lib/models";

// Страница всегда читает свежий текст политики из настроек (DynamoDB),
// чтобы сохранённые администратором изменения сразу отображались.
export const dynamic = "force-dynamic";

export default async function PrivacyPage() {
  let privacyText = "";
  let siteName = "Твоё Новое";
  try {
    const settings = await getAppSettings();
    privacyText = settings.privacyText ?? "";
    siteName = settings.siteName || siteName;
  } catch {
    // игнорируем: отображаем заголовок по умолчанию
  }

  return (
    <div className="relative overflow-hidden">
      <div className="gradient-hero-vibrant absolute inset-0" />
      <div className="pattern-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_top,black_25%,transparent_70%)]" />
      <Suspense>
        <ContentPage
          title="Политика конфиденциальности"
          siteName={siteName}
          text={privacyText}
          emptyText="Политика конфиденциальности ещё не опубликована."
        />
      </Suspense>
    </div>
  );
}
