// Файл запускается один раз при старте каждого инстанса сервера Next.js
// (Node.js runtime): запускает фоновый механизм автоотмены заказов, которые
// никто не взял в течение 15 минут.
import { startAutoCancelScheduler } from "./lib/auto-cancel";

export function register() {
  startAutoCancelScheduler();
}
