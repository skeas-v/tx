/* Минимальный service worker для PWA.
 * Нужен браузеру, чтобы считать приложение устанавливаемым.
 * Сеть не кэшируем намеренно: приложение работает с живыми данными.
 * Обрабатывает push-события и клики по уведомлениям для браузерных подписок.
 */
self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  event.respondWith(fetch(event.request));
});

self.addEventListener("push", (event) => {
  let title = "Уведомление";
  let body = "";
  let url = "/";
  try {
    if (event.data) {
      const payload = event.data.json();
      title = payload.title || "Уведомление";
      body = payload.body || "";
      url = payload.url || "/";
    }
  } catch {
    try {
      const text = event.data ? event.data.text() : "";
      if (text) body = text;
    } catch {
      /* пустое уведомление */
    }
  }

  event.waitUntil(
    self.registration.showNotification(title, {
      body,
      icon: "/icons/icon-192.png",
      badge: "/icons/icon-192.png",
      data: { url },
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl =
    (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(
    clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((clientList) => {
        for (const client of clientList) {
          if ("focus" in client) {
            return client.navigate(targetUrl).then(() => client.focus());
          }
        }
        return clients.openWindow(targetUrl);
      })
  );
});
