"use client";

import { useCallback, useEffect, useState } from "react";
import {
  BarChart3,
  CalendarDays,
  Download,
  Loader2,
  ReceiptText,
  Users,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  STATISTICS_PERIOD_OPTIONS,
  type StatisticsPeriodType,
} from "@/lib/statistics";
import type { OrderStatus } from "@/lib/models";

interface OrdersByStatus {
  status: OrderStatus;
  count: number;
  amount: number;
}

interface StatisticsData {
  period: {
    period: StatisticsPeriodType;
    from: string;
    to: string;
    label: string;
    rangeLabel: string;
  };
  ordersCount: number;
  ordersAmount: number;
  driversTotal: number;
  driversActive: number;
  ordersByStatus: OrdersByStatus[];
  defaultCommissionPerOrder: number;
}

const statusLabels: Record<string, string> = {
  waiting: "Ожидает водителя",
  assigned: "Взят в работу",
  in_progress: "В пути",
  completed: "Выполнен",
  cancelled: "Отменён",
};

function formatRub(value: number): string {
  return `${Math.round(value).toLocaleString("ru-RU")} ₽`;
}

function todayUtc(): string {
  return new Date().toISOString().split("T")[0];
}

const SESSION_HEADER = "x-admin-login";

export function StatisticsAdmin({ currentLogin }: { currentLogin: string }) {
  const [periodType, setPeriodType] = useState<StatisticsPeriodType>("month");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [data, setData] = useState<StatisticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [commission, setCommission] = useState<string>("10");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ period: periodType });
      const res = await fetch(`/api/admin/statistics?${params.toString()}`, {
        headers: { [SESSION_HEADER]: currentLogin },
      });
      const payload = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(payload?.error ?? "Не удалось загрузить статистику");
        return;
      }
      const parsed = payload as StatisticsData;
      setData(parsed);
      setCommission(String(parsed.defaultCommissionPerOrder ?? 10));
    } catch (error) {
      console.error("Ошибка загрузки статистики:", error);
      toast.error("Не удалось загрузить статистику");
    } finally {
      setLoading(false);
    }
  }, [periodType, currentLogin]);

  useEffect(() => {
    void load();
  }, [load]);

  function periodPayload() {
    const hasCustom = Boolean(fromDate || toDate);
    if (!hasCustom) {
      return { period: periodType, fromDate: "", toDate: "" };
    }
    return {
      period: periodType,
      fromDate: fromDate || todayUtc(),
      toDate: toDate || todayUtc(),
    };
  }

  async function handleExport() {
    const parsedCommission = Number(commission);
    if (!Number.isFinite(parsedCommission) || parsedCommission < 0) {
      toast.error("Укажите корректную комиссию с заявки");
      return;
    }
    setExporting(true);
    const id = toast.loading("Формируем файл Excel...");
    try {
      const res = await fetch("/api/admin/statistics/export", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          [SESSION_HEADER]: currentLogin,
        },
        body: JSON.stringify({
          ...periodPayload(),
          commissionPerOrder: parsedCommission,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast.error(data?.error ?? "Не удалось сформировать файл Excel", {
          id,
        });
        return;
      }
      const blob = await res.blob();
      const disposition = res.headers.get("Content-Disposition") ?? "";
      const match = disposition.match(/filename="?([^"]+)"?/);
      const filename = match?.[1] ?? `statistics-${Date.now()}.xlsx`;

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast.success("Файл Excel скачан", { id });
    } catch (error) {
      console.error("Ошибка выгрузки статистики:", error);
      toast.error("Не удалось скачать файл Excel", { id });
    } finally {
      setExporting(false);
    }
  }

  const commissionNumber = Number(commission);
  const validCommission =
    Number.isFinite(commissionNumber) && commissionNumber >= 0;
  const earnings =
    data && validCommission ? data.ordersCount * commissionNumber : 0;

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <BarChart3 className="size-5" />
        </div>
        <div className="flex-1">
          <h2 className="text-xl font-semibold">
            Статистика и выгрузка в Excel
          </h2>
          <p className="text-xs text-muted-foreground">
            Заказы и водители за период, расчёт заработка по комиссии.
          </p>
        </div>
      </div>

      <Card>
        <CardContent className="space-y-5 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <CalendarDays className="size-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Период выгрузки</h3>
              <p className="text-xs text-muted-foreground">
                Период считается по дате создания заказов.
              </p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>
                <span className="inline-flex items-center gap-1.5">
                  <CalendarDays className="size-4 text-primary" />
                  Период
                </span>
              </Label>
              <Select
                value={periodType}
                onValueChange={(v) => setPeriodType(v as StatisticsPeriodType)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATISTICS_PERIOD_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="stats-from">Дата «от» (необязательно)</Label>
              <Input
                id="stats-from"
                type="date"
                value={fromDate}
                max={toDate || undefined}
                onChange={(e) => setFromDate(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stats-to">Дата «до» (необязательно)</Label>
              <Input
                id="stats-to"
                type="date"
                value={toDate}
                min={fromDate || undefined}
                max={todayUtc()}
                onChange={(e) => setToDate(e.target.value)}
              />
            </div>
            <p className="text-xs text-muted-foreground sm:col-span-2">
              Если указать «от» и «до» — выгрузка будет за произвольный период.
              Если поля пустые — за выбранный выше период.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="stats-commission">
              <span className="inline-flex items-center gap-1.5">
                <Wallet className="size-4 text-primary" />
                Комиссия с одной заявки, ₽
              </span>
            </Label>
            <Input
              id="stats-commission"
              type="number"
              min={0}
              step={0.5}
              value={commission}
              onChange={(e) => setCommission(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Итоговый заработок = количество заявок × комиссия. Значение можно
              сохранить в настройках или указать прямо здесь.
            </p>
          </div>

          <Button className="gap-2" onClick={handleExport} disabled={exporting}>
            {exporting ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Download className="size-4" />
            )}
            {exporting ? "Формируем..." : "Скачать статистику в Excel"}
          </Button>
        </CardContent>
      </Card>

      {loading ? (
        <div className="space-y-3">
          {[0, 1].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      ) : data ? (
        <>
          <Card>
            <CardContent className="space-y-5 p-6">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <ReceiptText className="size-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">
                    За {data.period.label.toLowerCase()}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {data.period.rangeLabel}
                  </p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-xl border bg-muted/30 p-4">
                  <p className="text-xs text-muted-foreground">Заказов</p>
                  <p className="mt-1 text-2xl font-bold">
                    {data.ordersCount.toLocaleString("ru-RU")}
                  </p>
                </div>
                <div className="rounded-xl border bg-muted/30 p-4">
                  <p className="text-xs text-muted-foreground">Сумма заказов</p>
                  <p className="mt-1 text-2xl font-bold">
                    {formatRub(data.ordersAmount)}
                  </p>
                </div>
                <div className="rounded-xl border bg-muted/30 p-4">
                  <p className="text-xs text-muted-foreground">Водителей</p>
                  <p className="mt-1 text-2xl font-bold">
                    {data.driversActive.toLocaleString("ru-RU")}
                    <span className="text-sm font-normal text-muted-foreground">
                      {" "}
                      активных / {data.driversTotal.toLocaleString("ru-RU")}
                    </span>
                  </p>
                </div>
                <div className="rounded-xl border border-amber-200 bg-amber-500/10 p-4">
                  <p className="text-xs text-muted-foreground">
                    Заработок при комиссии {formatRub(commissionNumber)}
                  </p>
                  <p className="mt-1 text-2xl font-bold text-amber-700">
                    {formatRub(earnings)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-4 p-6">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Users className="size-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">По статусам заказов</h3>
                  <p className="text-xs text-muted-foreground">
                    Количество и сумма по каждому статусу за период.
                  </p>
                </div>
              </div>

              <div className="grid gap-3">
                {data.ordersByStatus.map((s) => (
                  <div
                    key={s.status}
                    className="flex items-center justify-between gap-4 rounded-lg border bg-muted/20 px-4 py-3"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">
                        {statusLabels[s.status] ?? s.status}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {s.count.toLocaleString("ru-RU")} шт. ·{" "}
                        {formatRub(s.amount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card>
          <CardContent className="p-6 text-sm text-muted-foreground">
            Статистика недоступна.
          </CardContent>
        </Card>
      )}
    </section>
  );
}
