"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, MapPin } from "lucide-react";
import { toast } from "sonner";
import {
  CITY_CENTER,
  CITY_NAME,
  type ResolvedAddress,
  type YandexMapInstance,
  type YandexMarker,
  type YandexMapsApi,
  geocodeAddress,
  loadYandexMaps,
  reverseGeocodeAddress,
} from "@/lib/yandex-maps";
import {
  getCurrentPosition,
  getSavedPosition,
  savePosition,
} from "@/lib/geolocation";
import { cn } from "@/lib/utils";

export type PickSlot = "from" | "to" | `stop:${number}`;

export interface CarClass {
  id: string;
  name: string;
  basePrice: number;
  pricePerKm: number;
  carsCount: number;
  iconPreset: string;
  description: string;
}

export const CAR_CLASSES: CarClass[] = [
  {
    id: "econom",
    name: "Эконом",
    basePrice: 149,
    pricePerKm: 21,
    carsCount: 8,
    iconPreset: "islands#greenAutoIcon",
    description: "Бюджетные автомобили",
  },
  {
    id: "comfort",
    name: "Комфорт",
    basePrice: 199,
    pricePerKm: 26,
    carsCount: 6,
    iconPreset: "islands#blueAutoIcon",
    description: "Современные авто",
  },
  {
    id: "business",
    name: "Бизнес",
    basePrice: 299,
    pricePerKm: 34,
    carsCount: 4,
    iconPreset: "islands#darkblueAutoIcon",
    description: "Премиальные авто",
  },
  {
    id: "minivan",
    name: "Минивэн",
    basePrice: 349,
    pricePerKm: 40,
    carsCount: 3,
    iconPreset: "islands#orangeAutoIcon",
    description: "Для больших компаний",
  },
];

const DEBOUNCE_MS = 600;
const CAR_MOVE_INTERVAL_MS = 1200;
const CITY_RADIUS = 0.06;

interface SimCar {
  marker: YandexMarker;
  lat: number;
  lng: number;
  heading: number;
  speed: number;
}

interface LiveMapProps {
  from: string;
  to: string;
  stops?: string[];
  carClass: string;
  activeSlot: PickSlot;
  locateSignal?: number;
  fitSignal?: number;
  onSlotChange: (slot: PickSlot) => void;
  onFromResolve?: (res: ResolvedAddress | null) => void;
  onToResolve?: (res: ResolvedAddress | null) => void;
  onFromPick?: (res: ResolvedAddress | null) => void;
  onToPick?: (res: ResolvedAddress | null) => void;
  onStopPick?: (index: number, res: ResolvedAddress | null) => void;
  onLocate?: (res: ResolvedAddress | null) => void;
  className?: string;
}

const fromToPreset = (slot: string): string => {
  if (slot === "from") return "islands#greenCircleDotIcon";
  if (slot === "to") return "islands#redCircleDotIcon";
  return "islands#blueCircleDotIcon";
};

export function LiveMap({
  from,
  to,
  stops = [],
  carClass,
  activeSlot,
  locateSignal = 0,
  fitSignal = 0,
  onSlotChange,
  onFromResolve,
  onToResolve,
  onFromPick,
  onToPick,
  onStopPick,
  onLocate,
  className,
}: LiveMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<YandexMapInstance | null>(null);
  const ymapsRef = useRef<YandexMapsApi | null>(null);
  const markerRefs = useRef<Map<string, YandexMarker>>(new Map());
  const tempMarkerRef = useRef<YandexMarker | null>(null);
  const routeRef = useRef<YandexMarker | null>(null);
  const blueCircleRef = useRef<YandexMarker | null>(null);
  const blueDotRef = useRef<YandexMarker | null>(null);
  const carsRef = useRef<SimCar[]>([]);
  const carsTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const watchRef = useRef<number | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const requestRef = useRef(0);
  const activeSlotRef = useRef<PickSlot>("from");
  const autoLocateDoneRef = useRef(false);
  const slotCoordsRef = useRef<Map<string, number[]>>(new Map());
  const callbacksRef = useRef({
    onFromResolve,
    onToResolve,
    onFromPick,
    onToPick,
    onStopPick,
    onLocate,
    onSlotChange,
  });
  const [mapState, setMapState] = useState<"loading" | "ready" | "error">(
    "loading"
  );
  const [mapVersion, setMapVersion] = useState(0);

  useEffect(() => {
    callbacksRef.current = {
      onFromResolve,
      onToResolve,
      onFromPick,
      onToPick,
      onStopPick,
      onLocate,
      onSlotChange,
    };
  }, [
    onFromResolve,
    onToResolve,
    onFromPick,
    onToPick,
    onStopPick,
    onLocate,
    onSlotChange,
  ]);

  const selectSlot = useCallback((slot: PickSlot) => {
    activeSlotRef.current = slot;
    callbacksRef.current.onSlotChange(slot);
  }, []);

  useEffect(() => {
    activeSlotRef.current = activeSlot;
  }, [activeSlot]);

  const clearMarker = useCallback((slot: string) => {
    const map = mapRef.current;
    const marker = markerRefs.current.get(slot);
    if (map && marker) {
      map.geoObjects.remove(marker);
    }
    markerRefs.current.delete(slot);
    slotCoordsRef.current.delete(slot);
  }, []);

  const placeMarker = useCallback(
    (slot: string, coords: number[], address?: string) => {
      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!map || !ymaps) return;

      const prev = slotCoordsRef.current.get(slot);
      if (prev && prev[0] === coords[0] && prev[1] === coords[1]) return;

      clearMarker(slot);
      const hint =
        slot === "from"
          ? "Откуда"
          : slot === "to"
            ? "Куда"
            : "Промежуточная точка";
      const marker = new ymaps.Placemark(
        [coords[0], coords[1]],
        {
          hintContent: `${hint}${address ? `: ${address}` : ""}`,
          balloonContent: address ?? "",
        },
        {
          preset: fromToPreset(slot),
          balloonCloseButton: true,
        }
      );
      map.geoObjects.add(marker);
      markerRefs.current.set(slot, marker);
      slotCoordsRef.current.set(slot, [coords[0], coords[1]]);
    },
    [clearMarker]
  );

  const clearRoute = useCallback(() => {
    if (routeRef.current && mapRef.current) {
      mapRef.current.geoObjects.remove(routeRef.current);
    }
    routeRef.current = null;
  }, []);

  const updateBlueDot = useCallback(
    (lat: number, lng: number, accuracy?: number) => {
      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!map || !ymaps) return;

      if (blueCircleRef.current) {
        map.geoObjects.remove(blueCircleRef.current);
        blueCircleRef.current = null;
      }
      if (blueDotRef.current) {
        map.geoObjects.remove(blueDotRef.current);
        blueDotRef.current = null;
      }

      const radius = Math.max(30, Math.min(accuracy ?? 50, 400));
      const circle = new ymaps.Circle(
        [[lat, lng], radius],
        { hintContent: "Вы здесь" },
        {
          fillColor: "rgba(37, 122, 255, 0.14)",
          strokeColor: "rgba(37, 122, 255, 0.55)",
          strokeWidth: 1.5,
          zIndex: 150,
        }
      );
      const dot = new ymaps.Placemark(
        [lat, lng],
        { hintContent: "Вы здесь" },
        { preset: "islands#blueCircleDotIcon", zIndex: 200 }
      );
      map.geoObjects.add(circle);
      map.geoObjects.add(dot);
      blueCircleRef.current = circle;
      blueDotRef.current = dot;
    },
    []
  );

  const spawnCars = useCallback(
    (ymaps: YandexMapsApi, map: YandexMapInstance) => {
      for (const car of carsRef.current) {
        map.geoObjects.remove(car.marker);
      }
      carsRef.current = [];

      const cls = CAR_CLASSES.find((c) => c.id === carClass) ?? CAR_CLASSES[0];
      const saved = getSavedPosition();
      const base = saved
        ? [saved.lat, saved.lng]
        : [CITY_CENTER[0], CITY_CENTER[1]];

      for (let i = 0; i < cls.carsCount; i += 1) {
        const lat = base[0] + (Math.random() - 0.5) * 0.05;
        const lng = base[1] + (Math.random() - 0.5) * 0.05;
        const marker = new ymaps.Placemark(
          [lat, lng],
          { hintContent: `${cls.name} • свободно` },
          { preset: cls.iconPreset, zIndex: 100 }
        );
        map.geoObjects.add(marker);
        carsRef.current.push({
          marker,
          lat,
          lng,
          heading: Math.random() * 2 * Math.PI,
          speed: 0.00009 + Math.random() * 0.00018,
        });
      }
    },
    [carClass]
  );

  const moveCars = useCallback(() => {
    const next = carsRef.current.map((car) => {
      let heading = car.heading;
      if (Math.random() < 0.04) {
        heading += (Math.random() - 0.5) * Math.PI;
      }
      const lat = car.lat + Math.sin(heading) * car.speed;
      const lng = car.lng + Math.cos(heading) * car.speed;

      const dx = lat - CITY_CENTER[0];
      const dy = lng - CITY_CENTER[1];
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > CITY_RADIUS) {
        heading += Math.PI + (Math.random() - 0.5) * 0.6;
      }
      car.marker.geometry?.setCoordinates?.([lat, lng]);
      return { marker: car.marker, lat, lng, heading, speed: car.speed };
    });
    carsRef.current = next;
  }, []);

  useEffect(() => {
    if (mapState !== "ready" || mapVersion === 0) return;

    const ymaps = ymapsRef.current;
    const map = mapRef.current;
    if (!ymaps || !map) return;

    spawnCars(ymaps, map);
    if (carsTimerRef.current) clearInterval(carsTimerRef.current);
    carsTimerRef.current = setInterval(moveCars, CAR_MOVE_INTERVAL_MS);

    return () => {
      if (carsTimerRef.current) clearInterval(carsTimerRef.current);
      carsTimerRef.current = null;
    };
  }, [mapState, mapVersion, carClass, spawnCars, moveCars]);

  useEffect(() => {
    if (mapState !== "ready" || mapVersion === 0 || !mapRef.current) return;

    const startWatch = (lat: number, lng: number, accuracy?: number) => {
      updateBlueDot(lat, lng, accuracy);
      if (watchRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchRef.current);
        watchRef.current = null;
      }
      if (navigator.geolocation) {
        watchRef.current = navigator.geolocation.watchPosition(
          (position) => {
            savePosition(position);
            updateBlueDot(
              position.coords.latitude,
              position.coords.longitude,
              position.coords.accuracy
            );
          },
          () => undefined,
          { enableHighAccuracy: true, timeout: 12_000, maximumAge: 5_000 }
        );
      }
    };

    const saved = getSavedPosition();
    if (saved) {
      startWatch(saved.lat, saved.lng, saved.accuracy);
    } else {
      updateBlueDot(CITY_CENTER[0], CITY_CENTER[1], 1200);
      if (navigator.geolocation) {
        watchRef.current = navigator.geolocation.watchPosition(
          (position) => {
            savePosition(position);
            updateBlueDot(
              position.coords.latitude,
              position.coords.longitude,
              position.coords.accuracy
            );
          },
          () => undefined,
          { enableHighAccuracy: true, timeout: 12_000, maximumAge: 5_000 }
        );
      }
    }

    return () => {
      if (watchRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchRef.current);
        watchRef.current = null;
      }
    };
  }, [mapState, mapVersion, updateBlueDot]);

  const handleMapClick = useCallback(
    async (event: unknown) => {
      const evt = event as { get?: (key: string) => unknown };
      const coords = evt.get?.("coords") as number[] | undefined;
      if (!coords || coords.length < 2) return;

      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!map || !ymaps) return;

      const slot = activeSlotRef.current;

      if (tempMarkerRef.current) {
        map.geoObjects.remove(tempMarkerRef.current);
        tempMarkerRef.current = null;
      }
      const temp = new ymaps.Placemark(
        [coords[0], coords[1]],
        { hintContent: "Точка на карте" },
        {
          preset: fromToPreset(slot),
          zIndex: 900,
        }
      );
      map.geoObjects.add(temp);
      tempMarkerRef.current = temp;

      const res = await reverseGeocodeAddress(ymaps, coords[0], coords[1]);

      if (tempMarkerRef.current === temp && mapRef.current) {
        mapRef.current.geoObjects.remove(temp);
        tempMarkerRef.current = null;
      }
      if (!res) return;

      const point: ResolvedAddress = {
        address: res.address,
        lat: coords[0],
        lng: coords[1],
      };
      if (slot === "from") {
        callbacksRef.current.onFromPick?.(point);
      } else if (slot === "to") {
        callbacksRef.current.onToPick?.(point);
      } else {
        const stopIndex = Number(slot.split(":")[1]);
        callbacksRef.current.onStopPick?.(stopIndex, point);
      }
      placeMarker(slot, [coords[0], coords[1]], res.address);
      selectSlot("from");
    },
    [placeMarker, selectSlot]
  );

  const locate = useCallback(
    async (opts?: { silent?: boolean }) => {
      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!ymaps || !map) return null;
      try {
        let lat: number;
        let lng: number;
        try {
          const position = await getCurrentPosition();
          lat = position.coords.latitude;
          lng = position.coords.longitude;
          savePosition(position);
        } catch {
          const saved = getSavedPosition();
          if (!saved) return null;
          lat = saved.lat;
          lng = saved.lng;
        }

        map.setCenter([lat, lng], 16);
        updateBlueDot(lat, lng, 30);
        const res = await reverseGeocodeAddress(ymaps, lat, lng);
        if (res) {
          callbacksRef.current.onLocate?.(res);
          return res;
        }
        if (!opts?.silent) {
          toast.error("Не удалось определить адрес по вашему местоположению");
        }
        return null;
      } catch {
        if (!opts?.silent) {
          toast.error("Не удалось определить ваше местоположение");
        }
        return null;
      }
    },
    [updateBlueDot]
  );

  useEffect(() => {
    if (mapState !== "ready" || autoLocateDoneRef.current) return;
    autoLocateDoneRef.current = true;
    // Автоопределение текущего местоположения при открытии окна: если
    // разрешение на геолокацию уже выдано (или координаты сохранены ранее),
    // сразу заполняем адрес «Откуда» и центрируем карту. При отсутствии
    // разрешения запрос молча пропускается — пользователь может нажать
    // «Найти меня», который запрашивает разрешение в рамках жеста (iOS).
    void locate({ silent: true });
  }, [mapState, locate]);

  useEffect(() => {
    if (!locateSignal || mapState !== "ready") return;
    void locate();
  }, [locateSignal, mapState, locate]);

  const createMap = useCallback(() => {
    const container = containerRef.current;
    const ymaps = ymapsRef.current;
    if (!container || !ymaps) return;
    if (container.clientWidth <= 2 || container.clientHeight <= 2) return;

    // Создаём карту только один раз. Повторное создание карты на том же
    // контейнере после destroy() (без смены узла DOM) приводит к тому, что
    // Яндекс-карта отрисовывается пустой — тайлы не рендерятся, и вместо
    // карты остаётся фон. Поэтому карта живёт всё время существования
    // компонента, а при изменении размера контейнера мы только пересчитываем
    // проекцию через map.container.fitToViewport() (см. refitMap).
    let map: YandexMapInstance;
    try {
      map = new ymaps.Map(container, {
        center: [CITY_CENTER[0], CITY_CENTER[1]],
        zoom: 14,
        type: "yandex#light",
        controls: [],
        // Программный режим прокрутки карты: карта не реагирует на жесты
        // пальцем (это позволяет странице обрабатывать их — в том числе
        // пинч-зум страницы не блокируется). При этом программные смены
        // позиции (markers/setCenter/маршруты) продолжают работать.
        panning: false,
      });
    } catch {
      try {
        map = new ymaps.Map(container, {
          center: [CITY_CENTER[0], CITY_CENTER[1]],
          zoom: 14,
          controls: [],
          // См. выше: карта управляется только программно.
          panning: false,
        });
      } catch (err) {
        console.error("Не удалось создать Яндекс-карту:", err);
        setMapState("error");
        return;
      }
    }
    mapRef.current = map;
    map.events.add("click", handleMapClick);
    // Сразу пересчитываем проекцию на полный контейнер, чтобы тайлы и панели
    // карты занимали весь контейнер даже при изменении видимой области
    // (zoom out), повороте экрана или появлении/скрытии адресной строки.
    try {
      if (typeof map.container.fitToViewport === "function") {
        map.container.fitToViewport();
      }
    } catch {
      // Резерв: проекция дополнительно пересчитается через refitMap.
    }
    setMapVersion((v) => v + 1);
    setMapState("ready");
  }, [handleMapClick]);

  useEffect(() => {
    let disposed = false;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;

    const tryInit = () => {
      if (disposed || !containerRef.current) return;
      if (
        containerRef.current.clientWidth <= 2 ||
        containerRef.current.clientHeight <= 2
      ) {
        // Контейнер ещё не получил видимый размер: ждём появления размера и
        // только потом создаём карту. Карта при этом никогда не
        // пересоздаётся в невидимое состояние — после создания она живёт всё
        // время существования компонента (пересчитывается только проекция).
        retryTimer = setTimeout(tryInit, 120);
        return;
      }
      createMap();
    };

    loadYandexMaps()
      .then((ymaps) => {
        if (disposed || !containerRef.current) return;
        ymapsRef.current = ymaps;
        tryInit();
      })
      .catch(() => {
        if (!disposed) setMapState("error");
      });

    return () => {
      disposed = true;
      if (retryTimer) clearTimeout(retryTimer);
      if (timerRef.current) clearTimeout(timerRef.current);
      if (carsTimerRef.current) clearInterval(carsTimerRef.current);
      if (watchRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchRef.current);
        watchRef.current = null;
      }
      if (mapRef.current) {
        const map = mapRef.current;
        map.events.remove("click", handleMapClick);
        map.destroy();
        mapRef.current = null;
      }
      markerRefs.current.clear();
      tempMarkerRef.current = null;
      routeRef.current = null;
      blueCircleRef.current = null;
      blueDotRef.current = null;
      carsRef.current = [];
    };
  }, [createMap, handleMapClick]);

  const refitMap = useCallback(() => {
    const map = mapRef.current;
    const container = containerRef.current;
    if (!map || !container) return;
    // Яндекс-карта может записать инлайновые размеры на контейнер — снимаем
    // их, чтобы физическим размером контейнера всегда управляла вёрстка
    // (absolute inset-0). Тогда при изменении масштаба страницы (zoom out),
    // повороте или изменении видимой области контейнер растягивается на весь
    // новый размер, а карта пересчитывает проекцию на весь контейнер.
    if (container.style.width) container.style.width = "";
    if (container.style.height) container.style.height = "";
    const width = container.clientWidth;
    const height = container.clientHeight;
    if (width <= 0 || height <= 0) return;

    // Карту не пересоздаём: повторный createMap() на том же контейнере после
    // destroy() рендерит пустую карту (тайлы не отрисовываются) — вместо неё
    // остаётся фон. Поэтому при любом изменении размера только пересчитываем
    // проекцию текущей карты через fitToViewport: она растягивается на весь
    // контейнер и остаётся видимой.
    try {
      const center = map.getCenter();
      const zoom = map.getZoom();
      if (typeof map.container.fitToViewport === "function") {
        map.container.fitToViewport();
      }
      map.setCenter(center, zoom);
    } catch {
      // Если пересчёт проекции недоступен — карта остаётся на месте, а её
      // проекция дополнительно пересчитается при следующем вызове refitMap.
    }
  }, []);

  useEffect(() => {
    if (mapState !== "ready" || mapVersion === 0) return;
    refitMap();
    const settleTimer = setTimeout(() => refitMap(), 450);
    const lateTimer = setTimeout(() => refitMap(), 1200);
    return () => {
      clearTimeout(settleTimer);
      clearTimeout(lateTimer);
    };
  }, [mapState, mapVersion, refitMap]);

  // Проекцию карты пересчитываем только когда реально меняется размер её
  // контейнера (поворот экрана, появление/скрытие адресной строки браузера,
  // изменение 100dvh, изменение размера окна) — через ResizeObserver на
  // контейнере. Слушатели visualViewport/window здесь не нужны: контейнер карты
  // занимает фиксированную область страницы заказа (absolute inset-0 внутри
  // корня высотой 100dvh), и его размер меняется только вместе с реальным
  // размером viewport; во время пинч-зума (масштаба страницы) layout viewport
  // не меняется, поэтому карта не пересчитывается и не «дёргается». Карта
  // создаётся один раз и никогда не пересоздаётся при изменении размера —
  // только пересчитывается проекция через map.container.fitToViewport().
  useEffect(() => {
    if (
      mapState !== "ready" ||
      mapVersion === 0 ||
      !containerRef.current ||
      !mapRef.current
    )
      return;
    const container = containerRef.current;
    let lastWidth = container.clientWidth;
    let lastHeight = container.clientHeight;
    const observer = new ResizeObserver(() => {
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (width === lastWidth && height === lastHeight) return;
      lastWidth = width;
      lastHeight = height;
      refitMap();
    });
    observer.observe(container);
    return () => observer.disconnect();
  }, [mapState, mapVersion, refitMap]);

  useEffect(() => {
    if (
      !fitSignal ||
      mapState !== "ready" ||
      mapVersion === 0 ||
      !mapRef.current
    )
      return;
    refitMap();
    const settleTimer = setTimeout(() => refitMap(), 250);
    return () => clearTimeout(settleTimer);
  }, [fitSignal, mapState, mapVersion, refitMap]);

  useEffect(() => {
    if (mapState !== "ready" || mapVersion === 0) return;

    const requestId = ++requestRef.current;
    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(async () => {
      const ymaps = ymapsRef.current;
      if (!ymaps || !mapRef.current) return;

      const [fromRes, toRes, ...stopRes] = await Promise.all([
        geocodeAddress(ymaps, from),
        geocodeAddress(ymaps, to),
        ...stops.map((s) => geocodeAddress(ymaps, s)),
      ]);

      if (requestRef.current !== requestId || !mapRef.current) return;

      if (fromRes) {
        placeMarker("from", [fromRes.lat, fromRes.lng], fromRes.address);
      } else {
        clearMarker("from");
      }
      if (toRes) {
        placeMarker("to", [toRes.lat, toRes.lng], toRes.address);
      } else {
        clearMarker("to");
      }
      stopRes.forEach((res, i) => {
        const slot = `stop:${i}` as const;
        if (res) {
          placeMarker(slot, [res.lat, res.lng], res.address);
        } else {
          clearMarker(slot);
        }
      });

      clearRoute();
      const referencePoints: (number[] | string)[] = [];
      if (fromRes) referencePoints.push([fromRes.lat, fromRes.lng]);
      stopRes.forEach((res) => {
        if (res) referencePoints.push([res.lat, res.lng]);
      });
      if (toRes) referencePoints.push([toRes.lat, toRes.lng]);

      if (referencePoints.length >= 2) {
        const route = new ymaps.multiRouter.MultiRoute(
          {
            referencePoints,
            params: { routingMode: "auto" },
          },
          {
            boundsAutoApply: true,
            routeActiveStrokeWidth: 9,
            routeActiveStrokeColor: "#e07b00",
            routeActiveStrokeStyle: "solid",
            routeActiveOutlineColor: "#ffffff",
            routeActiveOutlineWidth: 3,
            routeStrokeWidth: 9,
            wayPointStartIconLayout: "default#image#invisible",
            wayPointIconLayout: "default#image#invisible",
            wayPointFinishIconLayout: "default#image#invisible",
          }
        );
        mapRef.current.geoObjects.add(route);
        routeRef.current = route;
      } else {
        const resolvedPoints = [fromRes, ...stopRes, toRes].filter(
          (p): p is ResolvedAddress => Boolean(p)
        );
        if (resolvedPoints.length === 1) {
          mapRef.current.setCenter(
            [resolvedPoints[0].lat, resolvedPoints[0].lng],
            15
          );
        }
      }

      callbacksRef.current.onFromResolve?.(fromRes);
      callbacksRef.current.onToResolve?.(toRes);
    }, DEBOUNCE_MS);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [
    from,
    to,
    stops,
    mapState,
    mapVersion,
    placeMarker,
    clearMarker,
    clearRoute,
  ]);

  return (
    <div className={cn("absolute inset-0 overflow-hidden", className)}>
      <div
        ref={containerRef}
        className={cn(
          "absolute inset-0 h-full w-full touch-manipulation [&_span]:font-semibold",
          // Контейнер остаётся видимым, пока карта создаётся: Яндекс-карта,
          // созданная на `visibility: hidden`-элементе, может отрисоваться
          // пустой (тайлы не рендерятся), и вместо карты виден фон. Всё
          // перекрывает слой загрузки ниже, так что пустой контейнер в
          // процессе инициализации не виден пользователю.
          mapState !== "ready" && "pointer-events-none"
        )}
      />

      {mapState === "loading" && (
        <div className="absolute inset-0 z-10 flex items-center justify-center gap-2 bg-muted text-sm text-muted-foreground">
          <Loader2 className="size-4 animate-spin" />
          Загружаем карту...
        </div>
      )}

      {mapState === "error" && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-muted p-6 text-center text-sm text-muted-foreground">
          <MapPin className="size-5" />
          <p>
            Карта временно недоступна. Рабочая область — г. {CITY_NAME},
            Кировская область.
          </p>
        </div>
      )}
    </div>
  );
}
