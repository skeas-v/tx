"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowUpDown,
  Crosshair,
  Loader2,
  MapPin,
  Navigation,
} from "lucide-react";
import { toast } from "sonner";

import { AddressInput } from "@/components/address-input";
import { Button } from "@/components/ui/button";
import {
  CITY_CENTER,
  CITY_NAME,
  type ResolvedAddress,
  type YandexMapInstance,
  type YandexMarker,
  type YandexMapsApi,
  geocodeAddress,
  loadYandexMaps,
  reverseGeocodeAddress,
} from "@/lib/yandex-maps";
import {
  getCurrentPosition,
  getSavedPosition,
  savePosition,
} from "@/lib/geolocation";
import { cn } from "@/lib/utils";

type PickSlot = "from" | "to";

interface TaxiOrderMainProps {
  className?: string;
}

const DEBOUNCE_MS = 600;

export function TaxiOrderMain({ className }: TaxiOrderMainProps) {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [fromPoint, setFromPoint] = useState<ResolvedAddress | null>(null);
  const [toPoint, setToPoint] = useState<ResolvedAddress | null>(null);
  const [mapState, setMapState] = useState<"loading" | "ready" | "error">(
    "loading"
  );
  const [activeSlot, setActiveSlot] = useState<PickSlot>("from");
  const [locating, setLocating] = useState(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<YandexMapInstance | null>(null);
  const ymapsRef = useRef<YandexMapsApi | null>(null);
  const fromMarkerRef = useRef<YandexMarker | null>(null);
  const toMarkerRef = useRef<YandexMarker | null>(null);
  const tempMarkerRef = useRef<YandexMarker | null>(null);
  const activeSlotRef = useRef<PickSlot>("from");
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const requestRef = useRef(0);
  const locatingRef = useRef(false);
  const autoLocateDoneRef = useRef(false);
  const slotCoordsRef = useRef<{
    from: number[] | null;
    to: number[] | null;
  }>({ from: null, to: null });

  const selectSlot = useCallback((slot: PickSlot) => {
    activeSlotRef.current = slot;
    setActiveSlot(slot);
  }, []);

  const clearMarker = useCallback((slot: PickSlot) => {
    const map = mapRef.current;
    const holder = slot === "from" ? fromMarkerRef : toMarkerRef;
    if (map && holder.current) {
      map.geoObjects.remove(holder.current);
    }
    holder.current = null;
    slotCoordsRef.current[slot] = null;
  }, []);

  const placeMarker = useCallback(
    (slot: PickSlot, coords: number[], address?: string) => {
      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!map || !ymaps) return;

      const prev = slotCoordsRef.current[slot];
      if (prev && prev[0] === coords[0] && prev[1] === coords[1]) return;

      clearMarker(slot);
      const isFrom = slot === "from";
      const marker = new ymaps.Placemark(
        [coords[0], coords[1]],
        {
          hintContent: `${isFrom ? "Откуда" : "Куда"}${
            address ? `: ${address}` : ""
          }`,
          balloonContent: address ?? "",
        },
        {
          preset: isFrom
            ? "islands#greenCircleDotIcon"
            : "islands#redCircleDotIcon",
          balloonCloseButton: true,
        }
      );
      map.geoObjects.add(marker);
      slotCoordsRef.current[slot] = [coords[0], coords[1]];
      if (slot === "from") {
        fromMarkerRef.current = marker;
      } else {
        toMarkerRef.current = marker;
      }
    },
    [clearMarker]
  );

  const handleMapClick = useCallback(
    async (event: unknown) => {
      const evt = event as { get?: (key: string) => unknown };
      const coords = evt.get?.("coords") as number[] | undefined;
      if (!coords || coords.length < 2) return;

      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!map || !ymaps) return;

      const slot = activeSlotRef.current;

      if (tempMarkerRef.current) {
        map.geoObjects.remove(tempMarkerRef.current);
        tempMarkerRef.current = null;
      }
      const temp = new ymaps.Placemark(
        [coords[0], coords[1]],
        { hintContent: slot === "from" ? "Откуда" : "Куда" },
        {
          preset:
            slot === "from"
              ? "islands#greenCircleDotIcon"
              : "islands#redCircleDotIcon",
          zIndex: 900,
        }
      );
      map.geoObjects.add(temp);
      tempMarkerRef.current = temp;

      const res = await reverseGeocodeAddress(ymaps, coords[0], coords[1]);

      if (tempMarkerRef.current === temp && mapRef.current) {
        mapRef.current.geoObjects.remove(temp);
        tempMarkerRef.current = null;
      }
      if (!res) return;

      const point: ResolvedAddress = {
        address: res.address,
        lat: coords[0],
        lng: coords[1],
      };
      if (slot === "from") {
        setFrom(res.address);
        setFromPoint(point);
      } else {
        setTo(res.address);
        setToPoint(point);
      }
      placeMarker(slot, [coords[0], coords[1]], res.address);
      selectSlot(slot === "from" ? "to" : "from");
    },
    [placeMarker, selectSlot]
  );

  useEffect(() => {
    let disposed = false;
    loadYandexMaps()
      .then((ymaps) => {
        if (disposed || !containerRef.current) return;
        ymapsRef.current = ymaps;
        let map: YandexMapInstance;
        try {
          map = new ymaps.Map(containerRef.current, {
            center: [CITY_CENTER[0], CITY_CENTER[1]],
            zoom: 14,
            type: "yandex#light",
            controls: [],
          });
        } catch {
          map = new ymaps.Map(containerRef.current, {
            center: [CITY_CENTER[0], CITY_CENTER[1]],
            zoom: 14,
            controls: [],
          });
        }
        mapRef.current = map;
        map.events.add("click", handleMapClick);
        setMapState("ready");
      })
      .catch(() => {
        if (!disposed) setMapState("error");
      });

    return () => {
      disposed = true;
      if (timerRef.current) clearTimeout(timerRef.current);
      if (mapRef.current) {
        const map = mapRef.current;
        map.events.remove("click", handleMapClick);
        map.destroy();
        mapRef.current = null;
      }
      fromMarkerRef.current = null;
      toMarkerRef.current = null;
      tempMarkerRef.current = null;
    };
  }, [handleMapClick]);

  useEffect(() => {
    if (mapState !== "ready") return;

    const requestId = ++requestRef.current;
    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(async () => {
      const ymaps = ymapsRef.current;
      if (!ymaps) return;

      const [fromRes, toRes] = await Promise.all([
        geocodeAddress(ymaps, from),
        geocodeAddress(ymaps, to),
      ]);

      if (requestRef.current !== requestId || !mapRef.current) return;

      if (fromRes) {
        placeMarker("from", [fromRes.lat, fromRes.lng], fromRes.address);
      } else {
        clearMarker("from");
      }
      if (toRes) {
        placeMarker("to", [toRes.lat, toRes.lng], toRes.address);
      } else {
        clearMarker("to");
      }
      setFromPoint(fromRes);
      setToPoint(toRes);
    }, DEBOUNCE_MS);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [from, to, mapState, placeMarker, clearMarker]);

  useEffect(() => {
    if (mapState !== "ready" || !mapRef.current) return;

    const points = [fromPoint, toPoint].filter((p): p is ResolvedAddress =>
      Boolean(p)
    );
    if (points.length >= 2) {
      mapRef.current.setBounds(
        points.map((p) => [p.lat, p.lng]),
        { checkZoomRange: true, zoomMargin: 48 }
      );
    } else if (points.length === 1) {
      mapRef.current.setCenter([points[0].lat, points[0].lng], 15);
    }
  }, [fromPoint, toPoint, mapState]);

  const handleLocate = useCallback(
    async (opts?: { silent?: boolean }) => {
      const map = mapRef.current;
      const ymaps = ymapsRef.current;
      if (!ymaps || !map || locatingRef.current) return null;
      locatingRef.current = true;
      setLocating(true);
      try {
        let lat: number;
        let lng: number;
        try {
          const position = await getCurrentPosition();
          lat = position.coords.latitude;
          lng = position.coords.longitude;
          savePosition(position);
        } catch {
          const saved = getSavedPosition();
          if (!saved) throw new Error("Нет сохранённых координат");
          lat = saved.lat;
          lng = saved.lng;
        }

        map.setCenter([lat, lng], 16);
        const res = await reverseGeocodeAddress(ymaps, lat, lng);
        if (res) {
          setFrom(res.address);
          setFromPoint({ address: res.address, lat, lng });
          placeMarker("from", [lat, lng], res.address);
          selectSlot("to");
          return res;
        }
        if (!opts?.silent) {
          toast.error("Не удалось определить адрес по вашему местоположению");
        }
        return null;
      } catch {
        if (!opts?.silent) {
          toast.error("Не удалось определить ваше местоположение");
        }
        return null;
      } finally {
        locatingRef.current = false;
        setLocating(false);
      }
    },
    [placeMarker, selectSlot]
  );

  const handleSwap = useCallback(() => {
    setFrom(to);
    setTo(from);
    setFromPoint(toPoint);
    setToPoint(fromPoint);
  }, [from, to, fromPoint, toPoint]);

  useEffect(() => {
    if (mapState !== "ready" || autoLocateDoneRef.current) return;
    autoLocateDoneRef.current = true;
    if (getSavedPosition()) {
      void handleLocate({ silent: true });
    }
  }, [mapState, handleLocate]);

  return (
    <div
      className={cn(
        "relative h-[calc(100dvh-3.5rem)] w-full overflow-hidden bg-muted",
        className
      )}
    >
      {/* Карта на весь экран */}
      <div
        ref={containerRef}
        className={cn(
          "h-full w-full",
          mapState !== "ready" && "pointer-events-none invisible"
        )}
      />

      {mapState === "loading" && (
        <div className="absolute inset-0 z-10 flex items-center justify-center gap-2 bg-muted text-sm text-muted-foreground">
          <Loader2 className="size-4 animate-spin" />
          Загружаем карту...
        </div>
      )}

      {mapState === "error" && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-muted p-6 text-center text-sm text-muted-foreground">
          <MapPin className="size-5" />
          <p>
            Карта временно недоступна. Рабочая область — г. {CITY_NAME},
            Кировская область.
          </p>
        </div>
      )}

      {mapState === "ready" && (
        <>
          {/* Выбор точки на карте: переключатель «откуда»/«куда» */}
          <div className="absolute inset-x-0 bottom-4 z-10 flex flex-col items-center gap-2 px-4">
            <span className="pointer-events-none inline-flex items-center gap-1.5 rounded-full bg-white/95 px-4 py-1.5 text-xs font-medium text-foreground shadow-lg backdrop-blur animate-in fade-in zoom-in-95 duration-200">
              <Crosshair className="size-3.5 text-primary" />
              {activeSlot === "from"
                ? "Кликните по карте: точка отправления"
                : "Кликните по карте: точка назначения"}
            </span>
            <div className="flex items-center gap-1 rounded-full bg-white/95 p-1 shadow-lg ring-1 ring-black/5 backdrop-blur">
              <button
                type="button"
                onClick={() => selectSlot("from")}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors",
                  activeSlot === "from"
                    ? "bg-emerald-600 text-white"
                    : "text-foreground hover:bg-muted"
                )}
              >
                <span className="h-2 w-2 rounded-full bg-current" />
                Откуда
              </button>
              <button
                type="button"
                onClick={() => selectSlot("to")}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors",
                  activeSlot === "to"
                    ? "bg-destructive text-white"
                    : "text-foreground hover:bg-muted"
                )}
              >
                <span className="h-2 w-2 rounded-full bg-current" />
                Куда
              </button>
            </div>
          </div>

          {/* Кнопка «Найти меня» на карте */}
          <button
            type="button"
            onClick={() => void handleLocate()}
            disabled={locating}
            aria-label="Найти меня"
            title="Найти меня"
            className="absolute bottom-4 right-3 z-10 inline-flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-primary shadow-lg ring-1 ring-black/5 backdrop-blur transition-colors hover:bg-white disabled:opacity-60"
          >
            {locating ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Crosshair className="size-4" />
            )}
          </button>
        </>
      )}

      {/* Белая карточка формы поверх карты */}
      <div className="absolute inset-x-0 top-0 z-20 px-3 pt-3 sm:mx-auto sm:w-full sm:max-w-md sm:px-0 sm:pt-4">
        <div className="rounded-2xl bg-white p-4 shadow-xl ring-1 ring-black/5 shadow-black/5 animate-in fade-in slide-in-from-top-6 duration-700 sm:p-5">
          <div className="flex gap-2">
            {/* Разделитель с точками «откуда»/«куда» */}
            <div className="flex flex-col items-center py-0.5">
              <span className="h-3 w-3 rounded-full bg-emerald-500" />
              <span className="my-1.5 w-0.5 flex-1 border-l-2 border-dashed border-muted-foreground/30" />
              <span className="h-3 w-3 rounded-full bg-destructive" />
            </div>

            <div className="min-w-0 flex-1 space-y-2">
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <AddressInput
                    id="taxi-from"
                    label="Откуда"
                    value={from}
                    placeholder="Откуда"
                    onValueChange={(v) => {
                      setFrom(v);
                      setFromPoint(null);
                    }}
                  />
                </div>
                <Button
                  type="button"
                  size="sm"
                  onClick={() => void handleLocate()}
                  disabled={locating}
                  className="shrink-0 gap-1.5 rounded-full px-3.5"
                >
                  {locating ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : (
                    <Crosshair className="size-4" />
                  )}
                  Найти меня
                </Button>
              </div>

              <AddressInput
                id="taxi-to"
                label="Куда"
                value={to}
                placeholder="Куда"
                onValueChange={(v) => {
                  setTo(v);
                  setToPoint(null);
                }}
              />
            </div>

            {/* Поменять местами */}
            <button
              type="button"
              onClick={handleSwap}
              aria-label="Поменять местами"
              title="Поменять местами"
              className="self-center rounded-full bg-muted/70 p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <ArrowUpDown className="size-4" />
            </button>
          </div>

          <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
            <Navigation className="size-3.5 shrink-0 text-primary" />
            Кликайте по карте: первый клик — «откуда», второй — «куда». Адрес
            подставится автоматически, его также можно ввести вручную.
          </p>
        </div>
      </div>
    </div>
  );
}
