"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Crosshair,
  Flag,
  Loader2,
  MapPin,
  MapPinned,
  Navigation,
} from "lucide-react";
import {
  CITY_CENTER,
  CITY_NAME,
  type ResolvedAddress,
  type YandexMapInstance,
  type YandexMarker,
  type YandexMultiRoute,
  type YandexMapsApi,
  buildFallbackRoute,
  geocodeAddress,
  loadYandexMaps,
  reverseGeocodeAddress,
} from "@/lib/yandex-maps";
import {
  getCurrentPosition,
  getSavedPosition,
  savePosition,
} from "@/lib/geolocation";
import { cn } from "@/lib/utils";

interface OrderMapProps {
  from?: string;
  to?: string;
  stops?: string[];
  onFromResolve?: (res: ResolvedAddress | null) => void;
  onToResolve?: (res: ResolvedAddress | null) => void;
  onFromPick?: (res: ResolvedAddress | null) => void;
  onToPick?: (res: ResolvedAddress | null) => void;
  onStopPick?: (index: number, res: ResolvedAddress | null) => void;
  onStopResolve?: (index: number, res: ResolvedAddress | null) => void;
  onLocate?: (res: ResolvedAddress | null) => void;
  onPickModeChange?: (mode: PickMode) => void;
  showLocate?: boolean;
  autoLocate?: boolean;
  autoPick?: boolean;
  locateSignal?: number;
  locatePoint?: { lat: number; lng: number } | null;
  className?: string;
  height?: number;
}

type PickMode = "from" | "to" | number | null;

const DEBOUNCE_MS = 600;

export function OrderMap({
  from = "",
  to = "",
  stops = [],
  onFromResolve,
  onToResolve,
  onFromPick,
  onToPick,
  onStopPick,
  onStopResolve,
  onLocate,
  onPickModeChange,
  showLocate = false,
  autoLocate = false,
  autoPick = false,
  locateSignal = 0,
  locatePoint = null,
  className,
  height = 280,
}: OrderMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<YandexMapInstance | null>(null);
  const ymapsRef = useRef<YandexMapsApi | null>(null);
  const fromMarkerRef = useRef<YandexMarker | null>(null);
  const toMarkerRef = useRef<YandexMarker | null>(null);
  const stopMarkerRefs = useRef<YandexMarker[]>([]);
  const routeRef = useRef<YandexMultiRoute | null>(null);
  const clickHandlerRef = useRef<((event: unknown) => void) | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const requestRef = useRef(0);
  const pickModeRef = useRef<PickMode>(null);
  const locatingRef = useRef(false);
  const autoLocateDoneRef = useRef(false);
  const callbacksRef = useRef({
    onFromResolve,
    onToResolve,
    onFromPick,
    onToPick,
    onStopPick,
    onStopResolve,
    onLocate,
    onPickModeChange,
  });
  const autoRef = useRef({ from: "", to: to, stops: stops, autoPick });
  const [mapState, setMapState] = useState<"loading" | "ready" | "error">(
    "loading"
  );
  const [pickMode, setPickMode] = useState<PickMode>(null);
  const [routeInfo, setRouteInfo] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    callbacksRef.current = {
      onFromResolve,
      onToResolve,
      onFromPick,
      onToPick,
      onStopPick,
      onStopResolve,
      onLocate,
      onPickModeChange,
    };
  }, [
    onFromResolve,
    onToResolve,
    onFromPick,
    onToPick,
    onStopPick,
    onStopResolve,
    onLocate,
    onPickModeChange,
  ]);

  useEffect(() => {
    autoRef.current = { from, to, stops, autoPick };
  }, [from, to, stops, autoPick]);

  useEffect(() => {
    callbacksRef.current.onPickModeChange?.(pickMode);
  }, [pickMode]);

  const clearRoute = useCallback(() => {
    if (routeRef.current && mapRef.current) {
      mapRef.current.geoObjects.remove(routeRef.current);
    }
    routeRef.current = null;
    setRouteInfo(null);
  }, []);

  const resolveAutoSlot = useCallback((): PickMode => {
    const auto = autoRef.current;
    if (!auto.autoPick) return null;
    if (!auto.from.trim()) return "from";
    if (!auto.to.trim()) return "to";
    const idx = auto.stops.findIndex((s) => !s.trim());
    return idx >= 0 ? idx : null;
  }, []);

  const computeNextPick = useCallback(
    (current: NonNullable<PickMode>): PickMode => {
      const auto = autoRef.current;
      if (!auto.autoPick) return current;
      if (current === "from") {
        if (!auto.to.trim()) return "to";
        const idx = auto.stops.findIndex((s) => !s.trim());
        return idx >= 0 ? idx : null;
      }
      if (current === "to") {
        const idx = auto.stops.findIndex((s) => !s.trim());
        return idx >= 0 ? idx : null;
      }
      const idx = auto.stops.findIndex(
        (s, i) => i > (current as number) && !s.trim()
      );
      return idx >= 0 ? idx : null;
    },
    []
  );

  const handleMapClick = useCallback(
    async (event: unknown) => {
      const evt = event as { get?: (key: string) => unknown };
      const coords = evt.get?.("coords") as number[] | undefined;
      if (!coords || coords.length < 2) return;

      const ymaps = ymapsRef.current;
      const map = mapRef.current;
      if (!ymaps || !map) return;

      let slot = pickModeRef.current;
      if (slot === null) {
        slot = resolveAutoSlot();
        if (slot === null) return;
      }

      const isStop = typeof slot === "number";
      if (slot === "from" && fromMarkerRef.current) {
        map.geoObjects.remove(fromMarkerRef.current);
        fromMarkerRef.current = null;
      } else if (slot === "to" && toMarkerRef.current) {
        map.geoObjects.remove(toMarkerRef.current);
        toMarkerRef.current = null;
      } else if (typeof slot === "number") {
        const prevStop = stopMarkerRefs.current[slot];
        if (prevStop) {
          map.geoObjects.remove(prevStop);
          stopMarkerRefs.current[slot] = null as unknown as YandexMarker;
        }
      }

      const marker = new ymaps.Placemark(
        [coords[0], coords[1]],
        {
          hintContent: isStop
            ? `Остановка ${(slot as number) + 1}`
            : slot === "from"
              ? "Откуда"
              : "Куда",
        },
        {
          preset: isStop
            ? "islands#orangeDotIcon"
            : slot === "from"
              ? "islands#greenCircleDotIcon"
              : "islands#redCircleDotIcon",
          zIndex: 900,
        }
      );
      map.geoObjects.add(marker);
      if (slot === "from") {
        fromMarkerRef.current = marker;
      } else if (slot === "to") {
        toMarkerRef.current = marker;
      } else {
        stopMarkerRefs.current[slot as number] = marker;
      }

      const res = await reverseGeocodeAddress(ymaps, coords[0], coords[1]);

      // Если геокодирование не дало адрес (например, нет API-ключа или точка
      // вне населённого пункта) — не удаляем маркер и не оставляем поле
      // пустым: используем координаты в качестве адреса. Клиент при желании
      // вводит адрес вручную.
      const resolved = res ?? {
        address: `${coords[0].toFixed(5)}, ${coords[1].toFixed(5)}`,
        lat: coords[0],
        lng: coords[1],
      };

      if (slot === "from") {
        callbacksRef.current.onFromPick?.(resolved);
      } else if (slot === "to") {
        callbacksRef.current.onToPick?.(resolved);
      } else {
        callbacksRef.current.onStopPick?.(slot as number, resolved);
      }

      const next = computeNextPick(slot);
      pickModeRef.current = next;
      setPickMode(next);
    },
    [resolveAutoSlot, computeNextPick]
  );

  const locate = useCallback(
    async (opts?: {
      force?: boolean;
      quiet?: boolean;
      lat?: number;
      lng?: number;
    }) => {
      const ymaps = ymapsRef.current;
      const map = mapRef.current;
      if (!ymaps || !map || locatingRef.current) return null;
      locatingRef.current = true;
      setLocating(true);
      try {
        let lat: number;
        let lng: number;
        if (typeof opts?.lat === "number" && typeof opts?.lng === "number") {
          lat = opts.lat;
          lng = opts.lng;
        } else {
          try {
            const position = await getCurrentPosition();
            lat = position.coords.latitude;
            lng = position.coords.longitude;
            savePosition(position);
          } catch {
            const saved = getSavedPosition();
            if (!saved) return null;
            lat = saved.lat;
            lng = saved.lng;
          }
        }
        map.setCenter([lat, lng], 16);
        const res = await reverseGeocodeAddress(ymaps, lat, lng);
        if (res && !opts?.quiet && (opts?.force || !from.trim())) {
          callbacksRef.current.onLocate?.(res);
        }
        return res;
      } catch {
        return null;
      } finally {
        locatingRef.current = false;
        setLocating(false);
      }
    },
    [from]
  );

  useEffect(() => {
    if (mapState !== "ready" || !autoLocate || autoLocateDoneRef.current)
      return;
    autoLocateDoneRef.current = true;
    void locate();
  }, [mapState, autoLocate, locate]);

  useEffect(() => {
    if (mapState !== "ready" || !locateSignal) return;
    void locate({ force: true, quiet: true });
  }, [mapState, locateSignal, locate]);

  const lastLocatePointRef = useRef<{ lat: number; lng: number } | null>(null);
  useEffect(() => {
    if (mapState !== "ready" || !locatePoint) return;
    if (lastLocatePointRef.current === locatePoint) return;
    lastLocatePointRef.current = locatePoint;
    void locate({
      force: true,
      quiet: true,
      lat: locatePoint.lat,
      lng: locatePoint.lng,
    });
  }, [mapState, locatePoint, locate]);

  useEffect(() => {
    let disposed = false;
    loadYandexMaps()
      .then((ymaps) => {
        if (disposed || !containerRef.current) return;
        ymapsRef.current = ymaps;
        const map = new ymaps.Map(containerRef.current, {
          center: [CITY_CENTER[0], CITY_CENTER[1]],
          zoom: 13,
          controls: ["zoomControl", "fullscreenControl"],
        });
        mapRef.current = map;
        const clickHandler = (event: unknown) => handleMapClick(event);
        clickHandlerRef.current = clickHandler;
        map.events.add("click", clickHandler);
        setMapState("ready");
      })
      .catch(() => {
        if (!disposed) setMapState("error");
      });

    return () => {
      disposed = true;
      if (timerRef.current) clearTimeout(timerRef.current);
      if (mapRef.current) {
        if (clickHandlerRef.current) {
          mapRef.current.events.remove("click", clickHandlerRef.current);
          clickHandlerRef.current = null;
        }
        if (routeRef.current) {
          mapRef.current.geoObjects.remove(routeRef.current);
          routeRef.current = null;
        }
        mapRef.current.destroy();
        mapRef.current = null;
      }
      fromMarkerRef.current = null;
      toMarkerRef.current = null;
      stopMarkerRefs.current = [];
    };
  }, [handleMapClick]);

  useEffect(() => {
    if (mapState !== "ready") return;

    const requestId = ++requestRef.current;
    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(async () => {
      const ymaps = ymapsRef.current;
      if (!ymaps || !mapRef.current) return;

      const [fromRes, toRes, ...stopReses] = await Promise.all([
        geocodeAddress(ymaps, from),
        geocodeAddress(ymaps, to),
        ...stops.map((stop) => geocodeAddress(ymaps, stop)),
      ]);

      if (requestRef.current !== requestId || !mapRef.current) return;

      const map = mapRef.current;

      const applyMarker = (
        slot: "from" | "to",
        res: ResolvedAddress | null
      ) => {
        const holder = slot === "from" ? fromMarkerRef : toMarkerRef;
        if (holder.current) {
          map.geoObjects.remove(holder.current);
          holder.current = null;
        }
        if (!res) return null;
        const preset =
          slot === "from" ? "islands#greenDotIcon" : "islands#redDotIcon";
        const hint = slot === "from" ? "Откуда" : "Куда";
        const marker = new ymaps.Placemark(
          [res.lat, res.lng],
          {
            hintContent: `${hint}: ${res.address}`,
            balloonContent: res.address,
          },
          { preset, balloonCloseButton: true }
        );
        map.geoObjects.add(marker);
        holder.current = marker;
        return marker;
      };

      const applyStopMarkers = (resList: (ResolvedAddress | null)[]) => {
        for (const marker of stopMarkerRefs.current) {
          map.geoObjects.remove(marker);
        }
        stopMarkerRefs.current = [];
        resList.forEach((res, i) => {
          if (!res) return;
          const marker = new ymaps.Placemark(
            [res.lat, res.lng],
            {
              hintContent: `Остановка ${i + 1}: ${res.address}`,
              balloonContent: res.address,
            },
            { preset: "islands#orangeDotIcon", balloonCloseButton: true }
          );
          map.geoObjects.add(marker);
          stopMarkerRefs.current.push(marker);
        });
      };

      applyMarker("from", fromRes);
      applyMarker("to", toRes);
      applyStopMarkers(stopReses as (ResolvedAddress | null)[]);

      clearRoute();

      if (fromRes && toRes) {
        const referencePoints = [
          fromRes,
          ...(stopReses as (ResolvedAddress | null)[]),
          toRes,
        ]
          .filter((r): r is ResolvedAddress => Boolean(r))
          .map((r) => [r.lat, r.lng]);

        // Маршрут строится, но карта НЕ приближается автоматически: зум и
        // центр сохраняются такими, какими их оставил пользователь.
        if (referencePoints.length >= 2) {
          let routeDrawn = false;
          if (ymaps.multiRouter?.MultiRoute) {
            try {
              const route = new ymaps.multiRouter.MultiRoute(
                {
                  referencePoints,
                  params: { routingMode: "auto" },
                },
                {
                  // Не применяем авто-приближение маршрута: карта должна
                  // сохранять текущий масштаб при отметке адресов.
                  routeActiveStrokeWidth: 6,
                  routeActiveStrokeColor: "#e8930c",
                  routeActiveStrokeStyle: "solid",
                  routeActiveOutlineColor: "#ffffff",
                  routeActiveOutlineWidth: 2,
                  wayPointStartIconLayout: "default#image#invisible",
                  wayPointIconLayout: "default#image#invisible",
                  wayPointFinishIconLayout: "default#image#invisible",
                }
              );
              const updateRouteInfo = () => {
                const active = route.getActiveRoute?.();
                if (!active || routeRef.current !== route) {
                  setRouteInfo(null);
                  return;
                }
                const parts = [active.getHumanJamsLength?.()].filter(Boolean);
                setRouteInfo(parts.length > 0 ? parts.join(" · ") : null);
              };
              route.events.add("update", updateRouteInfo);
              map.geoObjects.add(route);
              routeRef.current = route;
              routeDrawn = true;
            } catch {
              routeDrawn = false;
            }
          }

          // Если маршрутизация Яндекса недоступна (например, нет API-ключа,
          // сервис отвечает 401) — строим маршрут через публичный роутер
          // OSRM (OpenStreetMap), который работает без ключа.
          if (!routeDrawn) {
            const osrmRes = await buildFallbackRoute(
              referencePoints.map(([lat, lng]) => ({ lat, lng }))
            );
            if (osrmRes && osrmRes.coordinates.length >= 2) {
              const polyline = new ymaps.Polyline(
                osrmRes.coordinates,
                {},
                {
                  strokeColor: "#e8930c",
                  strokeWidth: 6,
                  strokeStyle: "solid",
                  outlineColor: "#ffffff",
                  outlineWidth: 2,
                }
              );
              map.geoObjects.add(polyline);
              routeRef.current = polyline;
              routeDrawn = true;
            }
          }
        }
      }

      callbacksRef.current.onFromResolve?.(fromRes);
      callbacksRef.current.onToResolve?.(toRes);
      (stopReses as (ResolvedAddress | null)[]).forEach((res, i) => {
        callbacksRef.current.onStopResolve?.(i, res);
      });
    }, DEBOUNCE_MS);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [from, to, stops, mapState, clearRoute]);

  function handlePickButton(slot: Exclude<PickMode, null>) {
    const next = pickMode === slot ? null : slot;
    pickModeRef.current = next;
    setPickMode(next);
  }

  function handleAutoPickButton() {
    if (pickMode !== null) {
      pickModeRef.current = null;
      setPickMode(null);
      return;
    }
    const auto = autoRef.current;
    if (!auto.from.trim()) {
      pickModeRef.current = "from";
      setPickMode("from");
      return;
    }
    if (!auto.to.trim()) {
      pickModeRef.current = "to";
      setPickMode("to");
      return;
    }
    const idx = auto.stops.findIndex((s) => !s.trim());
    if (idx >= 0) {
      pickModeRef.current = idx;
      setPickMode(idx);
      return;
    }
    pickModeRef.current = null;
    setPickMode(null);
  }

  const pickLabel = (mode: NonNullable<PickMode>): string => {
    if (mode === "from") return "откуда";
    if (mode === "to") return "куда";
    return `остановку ${(mode as number) + 1}`;
  };

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border",
        pickMode !== null && "cursor-crosshair",
        className
      )}
      style={{ height }}
    >
      <div
        ref={containerRef}
        className={cn(
          "h-full w-full",
          pickMode !== null && "cursor-crosshair",
          mapState !== "ready" && "pointer-events-none invisible"
        )}
      />

      {mapState === "loading" && (
        <div className="absolute inset-0 flex items-center justify-center gap-2 bg-muted/40 text-sm text-muted-foreground">
          <Loader2 className="size-4 animate-spin" />
          Загружаем карту...
        </div>
      )}

      {mapState === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-muted/40 p-6 text-center text-sm text-muted-foreground">
          <MapPin className="size-5" />
          <p>
            Карта временно недоступна. Рабочая область — г. {CITY_NAME},
            Кировская область.
          </p>
        </div>
      )}

      {mapState === "ready" && (
        <div className="pointer-events-none absolute left-3 top-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium text-muted-foreground shadow-sm backdrop-blur">
          г. {CITY_NAME}
        </div>
      )}

      {mapState === "ready" && !autoPick && (
        <div className="absolute right-3 top-3 z-10 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => handlePickButton("from")}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium shadow-sm backdrop-blur transition-colors",
              pickMode === "from"
                ? "bg-emerald-600 text-white"
                : "bg-background/90 text-foreground hover:bg-background"
            )}
          >
            <MapPin className="size-3.5" />
            Откуда
          </button>
          <button
            type="button"
            onClick={() => handlePickButton("to")}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium shadow-sm backdrop-blur transition-colors",
              pickMode === "to"
                ? "bg-destructive text-white"
                : "bg-background/90 text-foreground hover:bg-background"
            )}
          >
            <Flag className="size-3.5" />
            Куда
          </button>
        </div>
      )}

      {mapState === "ready" && autoPick && (
        <button
          type="button"
          onClick={handleAutoPickButton}
          className={cn(
            "absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium shadow-sm backdrop-blur transition-colors",
            pickMode !== null
              ? "bg-primary text-primary-foreground"
              : "bg-background/90 text-foreground hover:bg-background"
          )}
        >
          <MapPinned className="size-3.5" />
          {pickMode !== null ? "Завершить выбор" : "Отметить на карте"}
        </button>
      )}

      {mapState === "ready" && showLocate && (
        <button
          type="button"
          onClick={() => void locate({ force: true })}
          disabled={locating}
          aria-label="Моё местоположение"
          title="Определить моё местоположение"
          className="absolute bottom-3 right-3 z-10 inline-flex h-9 w-9 items-center justify-center rounded-full bg-background/95 text-primary shadow-md backdrop-blur transition-colors hover:bg-background disabled:opacity-60"
        >
          {locating ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Crosshair className="size-4" />
          )}
        </button>
      )}

      {mapState === "ready" && pickMode !== null && (
        <div className="pointer-events-none absolute inset-x-0 bottom-3 z-10 flex justify-center px-4">
          <span className="pointer-events-auto inline-flex items-center gap-1.5 rounded-full bg-background/95 px-3.5 py-1.5 text-xs font-medium text-foreground shadow-md backdrop-blur">
            <Crosshair className="size-3.5 text-primary" />
            Кликните по карте, чтобы указать «{pickLabel(pickMode)}»
            {autoPick && (
              <button
                type="button"
                onClick={() => {
                  pickModeRef.current = null;
                  setPickMode(null);
                }}
                className="ml-1 rounded-full bg-muted px-2 py-0.5 font-semibold text-muted-foreground transition-colors hover:text-foreground"
              >
                Отмена
              </button>
            )}
          </span>
        </div>
      )}

      {mapState === "ready" && routeInfo && pickMode === null && (
        <div className="pointer-events-none absolute inset-x-0 bottom-3 z-10 flex justify-center px-4">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-background/95 px-3.5 py-1.5 text-xs font-medium text-foreground shadow-md backdrop-blur">
            <Navigation className="size-3.5 text-primary" />
            {routeInfo}
          </span>
        </div>
      )}
    </div>
  );
}
