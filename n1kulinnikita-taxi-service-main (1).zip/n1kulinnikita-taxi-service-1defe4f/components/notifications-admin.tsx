"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Bell,
  BellRing,
  Clock,
  MonitorSmartphone,
  Send,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PushMessageDoc, PushSubscriptionDoc } from "@/lib/models";

function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function shortEndpoint(endpoint: string): string {
  try {
    const url = new URL(endpoint);
    return url.host + url.pathname.slice(0, 40);
  } catch {
    return endpoint.slice(0, 60);
  }
}

export function NotificationsAdmin() {
  const [tab, setTab] = useState<"subscribers" | "send" | "history">(
    "subscribers"
  );
  const [subscriptions, setSubscriptions] = useState<PushSubscriptionDoc[]>([]);
  const [messages, setMessages] = useState<PushMessageDoc[]>([]);
  const [loadingSubs, setLoadingSubs] = useState(true);
  const [loadingMsgs, setLoadingMsgs] = useState(true);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [removing, setRemoving] = useState<string | null>(null);

  const refreshSubscriptions = useCallback(async () => {
    try {
      const res = await fetch("/api/push/subscriptions");
      if (res.ok) setSubscriptions((await res.json()) as PushSubscriptionDoc[]);
    } catch (error) {
      console.error("Ошибка загрузки подписок:", error);
    } finally {
      setLoadingSubs(false);
    }
  }, []);

  const refreshMessages = useCallback(async () => {
    try {
      const res = await fetch("/api/push/send");
      if (res.ok) setMessages((await res.json()) as PushMessageDoc[]);
    } catch (error) {
      console.error("Ошибка загрузки истории отправок:", error);
    } finally {
      setLoadingMsgs(false);
    }
  }, []);

  useEffect(() => {
    refreshSubscriptions();
    refreshMessages();
  }, [refreshSubscriptions, refreshMessages]);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!body.trim()) {
      toast.error("Введите текст уведомления");
      return;
    }
    setSending(true);
    const id = toast.loading("Отправляем push-уведомление...");
    try {
      const res = await fetch("/api/push/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim() || undefined,
          body: body.trim(),
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось отправить уведомление", { id });
        return;
      }
      toast.success(data?.message ?? "Уведомление отправлено", { id });
      setBody("");
      setTitle("");
      refreshMessages();
    } catch (error) {
      console.error("Ошибка отправки push-уведомления:", error);
      toast.error("Не удалось отправить уведомление", { id });
    } finally {
      setSending(false);
    }
  }

  async function handleRemove(endpoint: string) {
    setRemoving(endpoint);
    const id = toast.loading("Удаляем подписку...");
    try {
      const res = await fetch(
        `/api/push/subscriptions?endpoint=${encodeURIComponent(endpoint)}`,
        { method: "DELETE" }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось удалить подписку", { id });
        return;
      }
      toast.success("Подписка удалена", { id });
      refreshSubscriptions();
    } catch (error) {
      console.error("Ошибка удаления подписки:", error);
      toast.error("Не удалось удалить подписку", { id });
    } finally {
      setRemoving(null);
    }
  }

  return (
    <section className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Bell className="size-5" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-semibold">Уведомления</h2>
            <p className="text-xs text-muted-foreground">
              Управление push-подписками и рассылкой уведомлений.
            </p>
          </div>
        </div>
      </div>

      <Tabs
        value={tab}
        onValueChange={(v) => setTab(v as "subscribers" | "send" | "history")}
      >
        <TabsList>
          <TabsTrigger value="subscribers" className="gap-1.5">
            <Users className="size-4" />
            Список подписанных
          </TabsTrigger>
          <TabsTrigger value="send" className="gap-1.5">
            <Send className="size-4" />
            Отправка
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-1.5">
            <BellRing className="size-4" />
            Отправленные
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {tab === "subscribers" ? (
        <SubscribersList
          subscriptions={subscriptions}
          loading={loadingSubs}
          removing={removing}
          onRemove={handleRemove}
        />
      ) : tab === "send" ? (
        <SendForm
          title={title}
          body={body}
          onTitle={setTitle}
          onBody={setBody}
          onSubmit={handleSend}
          sending={sending}
          subscribersCount={subscriptions.length}
        />
      ) : (
        <HistoryList messages={messages} loading={loadingMsgs} />
      )}
    </section>
  );
}

function SubscribersList({
  subscriptions,
  loading,
  removing,
  onRemove,
}: {
  subscriptions: PushSubscriptionDoc[];
  loading: boolean;
  removing: string | null;
  onRemove: (endpoint: string) => void;
}) {
  if (loading) {
    return (
      <div className="space-y-3">
        {[0, 1].map((i) => (
          <Skeleton key={i} className="h-24 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <EmptyState
        icon={Users}
        title="Подписок пока нет"
        description="Подписки появятся, когда клиенты разрешат уведомления и подпишутся в браузере."
      />
    );
  }

  return (
    <div className="grid gap-3">
      <Badge variant="outline" className="w-fit gap-1.5">
        <Users className="size-3.5" />
        Всего подписок: {subscriptions.length}
      </Badge>
      {subscriptions.map((sub) => (
        <Card key={sub.endpoint} size="sm">
          <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0 space-y-1.5">
              <p className="truncate font-medium">
                {shortEndpoint(sub.endpoint)}
              </p>
              <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <MonitorSmartphone className="size-3.5" />
                  {sub.userAgent || "Браузер"}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="size-3.5" />
                  {formatDateTime(sub.createdAt)}
                </span>
              </div>
              <p className="break-all text-[11px] text-muted-foreground/70">
                {sub.endpoint}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
              disabled={removing === sub.endpoint}
              onClick={() => onRemove(sub.endpoint)}
            >
              <Trash2 className="size-4" />
              Удалить
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function SendForm({
  title,
  body,
  onTitle,
  onBody,
  onSubmit,
  sending,
  subscribersCount,
}: {
  title: string;
  body: string;
  onTitle: (v: string) => void;
  onBody: (v: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  sending: boolean;
  subscribersCount: number;
}) {
  return (
    <Card>
      <CardContent className="space-y-5 p-6">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Send className="size-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Отправка уведомления</h3>
            <p className="text-xs text-muted-foreground">
              Уведомление будет отправлено всем подписанным устройствам (
              {subscribersCount}).
            </p>
          </div>
        </div>

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="push-title">Заголовок (необязательно)</Label>
            <Input
              id="push-title"
              placeholder="Например: Машина назначена"
              maxLength={100}
              value={title}
              onChange={(e) => onTitle(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="push-body">Текст сообщения</Label>
            <Textarea
              id="push-body"
              placeholder="Введите текст push-уведомления"
              maxLength={2000}
              value={body}
              onChange={(e) => onBody(e.target.value)}
            />
          </div>
          <Button type="submit" className="gap-2" disabled={sending}>
            <Send className="size-4" />
            {sending ? "Отправляем..." : "Отправить всем подписанным"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function HistoryList({
  messages,
  loading,
}: {
  messages: PushMessageDoc[];
  loading: boolean;
}) {
  if (loading) {
    return (
      <div className="space-y-3">
        {[0, 1].map((i) => (
          <Skeleton key={i} className="h-24 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <EmptyState
        icon={BellRing}
        title="Отправленных уведомлений пока нет"
        description="Здесь появится история рассылок push-уведомлений."
      />
    );
  }

  return (
    <div className="grid gap-3">
      {messages.map((message) => (
        <Card key={message.id} size="sm">
          <CardContent className="space-y-3 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="gap-1.5">
                <BellRing className="size-3" />
                {message.title || "Уведомление"}
              </Badge>
              <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                <Clock className="size-3.5" />
                {formatDateTime(message.sentAt)}
              </span>
            </div>
            <p className="whitespace-pre-line text-sm">{message.body}</p>
            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
              <Badge variant="outline">Получателей: {message.recipients}</Badge>
              <Badge
                variant="outline"
                className="border-emerald-200 bg-emerald-500/10 text-emerald-700"
              >
                Отправлено: {message.sent}
              </Badge>
              {message.failed > 0 && (
                <Badge
                  variant="outline"
                  className="border-destructive/30 bg-destructive/10 text-destructive"
                >
                  Ошибок: {message.failed}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Icon className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
