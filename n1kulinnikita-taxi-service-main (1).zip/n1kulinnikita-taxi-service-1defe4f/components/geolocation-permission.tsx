"use client";

import { useEffect } from "react";
import { maybeRequestGeolocationPermission } from "@/lib/geolocation";

export function GeolocationPermission() {
  useEffect(() => {
    if (typeof window === "undefined" || !("geolocation" in navigator)) {
      return;
    }

    const initial = window.setTimeout(() => {
      void maybeRequestGeolocationPermission();
    }, 1500);

    return () => {
      window.clearTimeout(initial);
    };
  }, []);

  return null;
}
