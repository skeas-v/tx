"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  Baby,
  BaggageClaim,
  Banknote,
  CarFront,
  CheckCircle2,
  CircleOff,
  ClipboardList,
  Clock,
  History,
  KeyRound,
  LogOut,
  MapPin,
  MessageCircle,
  MessageSquare,
  Package,
  Pencil,
  Phone,
  PhoneCall,
  ShieldCheck,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { buttonVariants } from "@/components/ui/button";
import {
  CallResult,
  Driver,
  Order,
  OrderStatus,
  OrderStop,
  formatOrderNumber,
} from "@/lib/models";
import { addressWithEntrance } from "@/lib/address";
import { cn } from "@/lib/utils";
import { CAR_COLORS } from "@/lib/car-colors";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const PHONE_KEY = "taxi_driver_phone";

function formatDateTime(iso: string): string {
  const date = new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  const time = new Date(iso).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
  return `${date}, ${time}`;
}

export function DriverCabinet() {
  const [driver, setDriver] = useState<Driver | null>(null);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [orders, setOrders] = useState<Order[]>([]);
  const [callOrders, setCallOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [callOrdersLoading, setCallOrdersLoading] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [editOpen, setEditOpen] = useState(false);

  const [profile, setProfile] = useState({
    name: "",
    phone: "",
    vkId: "",
    carMake: "",
    carNumber: "",
    carColor: "",
    currentPassword: "",
    password: "",
  });

  const syncProfileForm = useCallback((d: Driver) => {
    setProfile({
      name: d.name,
      phone: d.phone,
      vkId: d.vkId ?? "",
      carMake: d.carMake ?? "",
      carNumber: d.carNumber ?? "",
      carColor: d.carColor ?? "",
      currentPassword: "",
      password: "",
    });
  }, []);

  const loadCompleted = useCallback(async (driverName: string) => {
    setOrdersLoading(true);
    try {
      const res = await fetch(
        `/api/orders?driver=${encodeURIComponent(
          driverName
        )}&status=${OrderStatus.COMPLETED}`
      );
      if (res.ok) {
        setOrders((await res.json()) as Order[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки выполненных заказов:", error);
    } finally {
      setOrdersLoading(false);
    }
  }, []);

  const loadCallOrders = useCallback(async (driverName: string) => {
    setCallOrdersLoading(true);
    try {
      const res = await fetch(
        `/api/orders?driver=${encodeURIComponent(driverName)}&phoneCall=true`
      );
      if (res.ok) {
        setCallOrders((await res.json()) as Order[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки заказов по звонку:", error);
    } finally {
      setCallOrdersLoading(false);
    }
  }, []);

  useEffect(() => {
    const storedPhone = localStorage.getItem(PHONE_KEY);
    if (storedPhone) {
      fetch("/api/drivers")
        .then((res) => (res.ok ? res.json() : []))
        .then((list: Driver[]) => {
          const found = list.find((d) => d.phone === storedPhone);
          if (found) {
            if (found.isBlocked) {
              localStorage.removeItem(PHONE_KEY);
              toast.error(
                "Водитель заблокирован. Обратитесь к администратору."
              );
            } else {
              setDriver(found);
              syncProfileForm(found);
              loadCompleted(found.name);
              loadCallOrders(found.name);
            }
          } else {
            localStorage.removeItem(PHONE_KEY);
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [loadCompleted, loadCallOrders, syncProfileForm]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!phone.trim()) {
      toast.error("Укажите номер телефона");
      return;
    }
    if (!password) {
      toast.error("Введите пароль");
      return;
    }
    setAuthLoading(true);
    const id = toast.loading("Входим в кабинет...");
    try {
      const res = await fetch("/api/drivers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.trim(), password }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось войти в кабинет", { id });
        return;
      }
      const found: Driver = data.driver;
      localStorage.setItem(PHONE_KEY, found.phone);
      setDriver(found);
      syncProfileForm(found);
      setOrders([]);
      setCallOrders([]);
      loadCompleted(found.name);
      loadCallOrders(found.name);
      toast.success("Вы вошли в личный кабинет", { id });
    } catch (error) {
      console.error("Ошибка авторизации:", error);
      toast.error("Не удалось войти в кабинет", { id });
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!driver) return;
    if (!profile.name.trim()) {
      toast.error("Укажите имя");
      return;
    }
    if (!profile.currentPassword) {
      toast.error("Введите текущий пароль для подтверждения");
      return;
    }
    setSavingProfile(true);
    const id = toast.loading("Сохраняем изменения...");
    try {
      const res = await fetch(
        `/api/drivers/${encodeURIComponent(driver.id)}/profile`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            currentPassword: profile.currentPassword,
            name: profile.name.trim(),
            phone: profile.phone.trim(),
            vkId: profile.vkId.trim(),
            carMake: profile.carMake.trim(),
            carNumber: profile.carNumber.trim(),
            carColor: profile.carColor.trim(),
            password: profile.password || undefined,
          }),
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить изменения", { id });
        return;
      }
      const updated: Driver = data;
      localStorage.setItem(PHONE_KEY, updated.phone);
      setDriver(updated);
      syncProfileForm(updated);
      setOrders([]);
      setCallOrders([]);
      loadCompleted(updated.name);
      loadCallOrders(updated.name);
      setEditOpen(false);
      toast.success("Данные сохранены", { id });
    } catch (error) {
      console.error("Ошибка сохранения данных:", error);
      toast.error("Не удалось сохранить изменения", { id });
    } finally {
      setSavingProfile(false);
    }
  }

  function handleLogout() {
    localStorage.removeItem(PHONE_KEY);
    setDriver(null);
    setOrders([]);
    setCallOrders([]);
    setPhone("");
    setPassword("");
    toast.success("Вы вышли из кабинета");
  }

  async function confirmOrderResult(order: Order, result: CallResult) {
    setConfirmingId(order.id);
    const id = toast.loading("Сохраняем подтверждение...");
    try {
      const res = await fetch(`/api/orders/${order.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirmResult: result }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить подтверждение", {
          id,
        });
        return;
      }
      toast.success(
        result === CallResult.PICKED_UP
          ? "Поездка подтверждена — «Увез»"
          : "Подтверждён отказ",
        { id }
      );
      if (driver) {
        await loadCallOrders(driver.name);
        await loadCompleted(driver.name);
      }
    } catch (error) {
      console.error("Ошибка подтверждения заказа:", error);
      toast.error("Не удалось сохранить подтверждение", { id });
    } finally {
      setConfirmingId(null);
    }
  }

  async function setOnlineStatus(target: boolean) {
    if (!driver || driver.isOnLine === target) return;
    setToggling(true);
    const id = toast.loading("Обновляем статус...");
    try {
      const res = await fetch(`/api/drivers/${encodeURIComponent(driver.id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isOnLine: target }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось обновить статус", { id });
        return;
      }
      setDriver(data as Driver);
      toast.success(data.isOnLine ? "Вы на линии" : "Вы не на линии", { id });
    } catch (error) {
      console.error("Ошибка обновления статуса:", error);
      toast.error("Не удалось обновить статус", { id });
    } finally {
      setToggling(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64 rounded-xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }

  if (!driver) {
    return (
      <LoginForm
        phone={phone}
        password={password}
        onPhone={setPhone}
        onPassword={setPassword}
        onSubmit={handleLogin}
        busying={authLoading}
      />
    );
  }

  const carLabel =
    [driver.carMake, driver.carNumber, driver.carColor]
      .filter(Boolean)
      .join(", ") || "Не указано";

  const pendingCalls = callOrders.filter((o) => !o.confirmResult);
  const resolvedCalls = callOrders.filter((o) => o.confirmResult);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight">
            Личный кабинет водителя
          </h1>
          <p className="text-muted-foreground">
            Профиль, подтверждение заказов по звонку и история выполненных
            заказов.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <Button
            variant="outline"
            className="h-12 gap-2 sm:h-10"
            onClick={() => {
              syncProfileForm(driver);
              setEditOpen(true);
            }}
          >
            <Pencil className="size-5 sm:size-4" />
            Редактировать профиль
          </Button>
          <Button
            variant="outline"
            className="h-12 gap-2 sm:h-10"
            onClick={handleLogout}
          >
            <LogOut className="size-5 sm:size-4" />
            Выйти
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="space-y-5 p-6">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <User className="size-7" />
            </div>
            <div className="min-w-0 space-y-1">
              <p className="text-xl font-semibold">{driver.name}</p>
              <Badge
                variant="outline"
                className={cn(
                  "gap-1.5",
                  driver.isOnLine
                    ? "border-emerald-200 bg-emerald-500/10 text-emerald-700"
                    : "border-muted-foreground/30 text-muted-foreground"
                )}
              >
                <span
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    driver.isOnLine ? "bg-emerald-500" : "bg-muted-foreground"
                  )}
                />
                {driver.isOnLine ? "На линии" : "Не на линии"}
              </Badge>
            </div>
          </div>

          <Separator />

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                <Phone className="size-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground">Телефон</p>
                <p className="truncate font-medium">{driver.phone}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                <CarFront className="size-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground">Автомобиль</p>
                <p className="truncate font-medium">{carLabel}</p>
              </div>
            </div>
            {driver.vkId ? (
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                  <MessageCircle className="size-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">VK ID</p>
                  <p className="truncate font-medium">{driver.vkId}</p>
                </div>
              </div>
            ) : null}
          </div>

          <Separator />

          <div>
            <p className="mb-2 text-sm font-medium">Статус «на линии»</p>
            <div
              className="grid grid-cols-2 gap-1.5 rounded-2xl border bg-muted/50 p-1.5 sm:max-w-md"
              role="group"
              aria-label="Статус на линии"
            >
              <Button
                size="lg"
                variant={driver.isOnLine ? "default" : "ghost"}
                className={cn(
                  "h-14 gap-2 rounded-xl text-base",
                  !driver.isOnLine && "text-muted-foreground"
                )}
                disabled={toggling}
                onClick={() => setOnlineStatus(true)}
              >
                <CheckCircle2 className="size-5" />
                На линии
              </Button>
              <Button
                size="lg"
                variant={!driver.isOnLine ? "default" : "ghost"}
                className={cn(
                  "h-14 gap-2 rounded-xl text-base",
                  driver.isOnLine && "text-muted-foreground"
                )}
                disabled={toggling}
                onClick={() => setOnlineStatus(false)}
              >
                <CircleOff className="size-5" />
                Не на линии
              </Button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Выберите статус — он сохраняется и показывается клиентам.
            </p>
          </div>
        </CardContent>
      </Card>

      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <PhoneCall className="size-5" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">
              Подтверждение заказов по звонку
            </h2>
            <p className="text-xs text-muted-foreground">
              Клиент позвонил вам напрямую — зафиксируйте результат поездки.
            </p>
          </div>
          <Badge variant="outline" className="ml-auto">
            {pendingCalls.length}
          </Badge>
        </div>

        {callOrdersLoading ? (
          <div className="space-y-3">
            {[0, 1].map((i) => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
        ) : pendingCalls.length > 0 || resolvedCalls.length > 0 ? (
          <div className="grid gap-3">
            {pendingCalls.map((order) => (
              <Card key={order.id} size="sm">
                <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-start gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600">
                      <PhoneCall className="size-4" />
                    </div>
                    <div className="min-w-0 space-y-1.5">
                      <RouteLine
                        from={order.from}
                        to={order.to}
                        fromEntrance={order.fromEntrance}
                        toEntrance={order.toEntrance}
                        stops={order.stops}
                      />
                      {order.comment && (
                        <div className="flex items-start gap-1.5 text-xs text-amber-700">
                          <MessageSquare className="mt-0.5 size-3.5 shrink-0" />
                          <span className="min-w-0">
                            <span className="font-medium">
                              Комментарий водителю:
                            </span>{" "}
                            {order.comment}
                          </span>
                        </div>
                      )}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1 font-medium text-foreground/80">
                          №{formatOrderNumber(order.id)}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <User className="size-3.5" />
                          {order.clientName ?? "Клиент"}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Phone className="size-3.5" />
                          {order.clientPhone ? (
                            <a
                              href={`tel:${order.clientPhone}`}
                              className="underline-offset-2 hover:underline"
                            >
                              {order.clientPhone}
                            </a>
                          ) : (
                            "—"
                          )}
                        </span>
                        {order.childSeat && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Baby className="size-3.5" /> Детское кресло
                          </span>
                        )}
                        {order.delivery && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Package className="size-3.5" /> Доставка +350₽
                          </span>
                        )}
                        {order.trunk && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <BaggageClaim className="size-3.5" /> Багажник +50₽
                          </span>
                        )}
                        {order.paymentMethod === "cash" && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Banknote className="size-3.5" /> Наличными
                            {order.cashChangeFrom != null && (
                              <span className="font-semibold">
                                · с {order.cashChangeFrom}₽
                              </span>
                            )}
                          </span>
                        )}
                        {order.paymentMethod === "card" && (
                          <span className="inline-flex items-center gap-1 text-muted-foreground">
                            <Banknote className="size-3.5" /> Перевод
                          </span>
                        )}
                        {order.suburbanPrice && (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <MapPin className="size-3.5" />{" "}
                            {order.suburbanPrice.name} ·{" "}
                            {order.suburbanPrice.direction === "from"
                              ? "забрать"
                              : "везти"}{" "}
                            {order.suburbanPrice.price}₽
                          </span>
                        )}
                        {order.popularPlacePrice && (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <MapPin className="size-3.5" />{" "}
                            {order.popularPlacePrice.name} ·{" "}
                            {order.popularPlacePrice.price}₽
                          </span>
                        )}
                        <span className="inline-flex items-center gap-1">
                          <Clock />
                          {formatDateTime(order.createdAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex w-full flex-col items-stretch gap-2 sm:w-auto sm:items-end">
                    <Badge
                      variant="outline"
                      className="gap-1.5 self-start border-amber-200 bg-amber-500/10 text-amber-700 sm:self-auto"
                    >
                      <PhoneCall className="size-3" />
                      Звонок клиента
                    </Badge>
                    <div className="grid w-full grid-cols-2 gap-2 sm:flex sm:w-auto">
                      <Button
                        size="lg"
                        className="h-12 gap-1.5 text-base sm:h-10 sm:text-sm"
                        disabled={confirmingId === order.id}
                        onClick={() =>
                          confirmOrderResult(order, CallResult.PICKED_UP)
                        }
                      >
                        <CheckCircle2 className="size-5 sm:size-4" />
                        Увез
                      </Button>
                      <Button
                        size="lg"
                        variant="outline"
                        className="h-12 gap-1.5 text-base sm:h-10 sm:text-sm"
                        disabled={confirmingId === order.id}
                        onClick={() =>
                          confirmOrderResult(order, CallResult.DECLINED)
                        }
                      >
                        <CircleOff className="size-5 sm:size-4" />
                        Отказ
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {resolvedCalls.map((order) => (
              <Card key={order.id} size="sm">
                <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-start gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                      <CircleOff className="size-4" />
                    </div>
                    <div className="min-w-0 space-y-1.5">
                      <RouteLine
                        from={order.from}
                        to={order.to}
                        fromEntrance={order.fromEntrance}
                        toEntrance={order.toEntrance}
                        stops={order.stops}
                      />
                      {order.comment && (
                        <div className="flex items-start gap-1.5 text-xs text-amber-700">
                          <MessageSquare className="mt-0.5 size-3.5 shrink-0" />
                          <span className="min-w-0">
                            <span className="font-medium">
                              Комментарий водителю:
                            </span>{" "}
                            {order.comment}
                          </span>
                        </div>
                      )}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1 font-medium text-foreground/80">
                          №{formatOrderNumber(order.id)}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <User className="size-3.5" />
                          {order.clientName ?? "Клиент"}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Phone className="size-3.5" />
                          {order.clientPhone ? (
                            <a
                              href={`tel:${order.clientPhone}`}
                              className="underline-offset-2 hover:underline"
                            >
                              {order.clientPhone}
                            </a>
                          ) : (
                            "—"
                          )}
                        </span>
                        {order.childSeat && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Baby className="size-3.5" /> Детское кресло
                          </span>
                        )}
                        {order.delivery && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Package className="size-3.5" /> Доставка +350₽
                          </span>
                        )}
                        {order.trunk && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <BaggageClaim className="size-3.5" /> Багажник +50₽
                          </span>
                        )}
                        {order.paymentMethod === "cash" && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Banknote className="size-3.5" /> Наличными
                            {order.cashChangeFrom != null && (
                              <span className="font-semibold">
                                · с {order.cashChangeFrom}₽
                              </span>
                            )}
                          </span>
                        )}
                        {order.paymentMethod === "card" && (
                          <span className="inline-flex items-center gap-1 text-muted-foreground">
                            <Banknote className="size-3.5" /> Перевод
                          </span>
                        )}
                        {order.suburbanPrice && (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <MapPin className="size-3.5" />{" "}
                            {order.suburbanPrice.name} ·{" "}
                            {order.suburbanPrice.direction === "from"
                              ? "забрать"
                              : "везти"}{" "}
                            {order.suburbanPrice.price}₽
                          </span>
                        )}
                        {order.popularPlacePrice && (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <MapPin className="size-3.5" />{" "}
                            {order.popularPlacePrice.name} ·{" "}
                            {order.popularPlacePrice.price}₽
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-start gap-1.5 sm:items-end">
                    {order.confirmResult === CallResult.PICKED_UP ? (
                      <Badge className="gap-1.5 bg-emerald-500/10 text-emerald-700">
                        <CheckCircle2 className="size-3" />
                        Увез
                      </Badge>
                    ) : (
                      <Badge className="gap-1.5 bg-destructive/10 text-destructive">
                        <CircleOff className="size-3" />
                        Отказ
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {formatDateTime(order.updatedAt)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={PhoneCall}
            title="Нет заказов, требующих подтверждения"
            description="Когда клиент вызовет вас по телефону, заказ появится здесь для подтверждения «Увез» или «Отказ»."
          />
        )}
      </section>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-h-[min(90vh,52rem)] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Редактирование профиля</DialogTitle>
            <DialogDescription>
              Измените свои данные и сохраните, или обновите пароль.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="cabinet-edit-name">Имя</Label>
                <Input
                  id="cabinet-edit-name"
                  placeholder="Иван Петров"
                  className="h-12 text-base"
                  value={profile.name}
                  onChange={(e) =>
                    setProfile({ ...profile, name: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cabinet-edit-phone">Телефон</Label>
                <Input
                  id="cabinet-edit-phone"
                  type="tel"
                  placeholder="+7 900 000-00-00"
                  className="h-12 text-base"
                  value={profile.phone}
                  onChange={(e) =>
                    setProfile({ ...profile, phone: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cabinet-edit-vk-id">VK ID</Label>
                <Input
                  id="cabinet-edit-vk-id"
                  placeholder="12345678"
                  className="h-12 text-base"
                  value={profile.vkId}
                  onChange={(e) =>
                    setProfile({ ...profile, vkId: e.target.value })
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Идентификатор пользователя ВКонтакте для управления статусом
                  через беседу.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cabinet-edit-make">Марка автомобиля</Label>
                <Input
                  id="cabinet-edit-make"
                  placeholder="Toyota Camry"
                  className="h-12 text-base"
                  value={profile.carMake}
                  onChange={(e) =>
                    setProfile({ ...profile, carMake: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cabinet-edit-number">Госномер</Label>
                <Input
                  id="cabinet-edit-number"
                  placeholder="А123ВС77"
                  className="h-12 text-base"
                  value={profile.carNumber}
                  onChange={(e) =>
                    setProfile({ ...profile, carNumber: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cabinet-edit-color">Цвет автомобиля</Label>
                <Select
                  items={CAR_COLORS.map((color) => ({
                    label: color,
                    value: color,
                  }))}
                  value={profile.carColor || null}
                  onValueChange={(value) =>
                    setProfile({ ...profile, carColor: value ?? "" })
                  }
                >
                  <SelectTrigger
                    id="cabinet-edit-color"
                    className="h-12 w-full text-base"
                  >
                    <SelectValue placeholder="Выберите цвет" />
                  </SelectTrigger>
                  <SelectContent className="w-full">
                    <SelectGroup>
                      {CAR_COLORS.map((color) => (
                        <SelectItem key={color} value={color}>
                          {color}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="cabinet-edit-current">
                <span className="inline-flex items-center gap-1.5">
                  <KeyRound className="size-4 text-primary" />
                  Текущий пароль (для подтверждения)
                </span>
              </Label>
              <Input
                id="cabinet-edit-current"
                type="password"
                placeholder="••••••"
                className="h-12 text-base"
                value={profile.currentPassword}
                onChange={(e) =>
                  setProfile({ ...profile, currentPassword: e.target.value })
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cabinet-edit-password">Новый пароль</Label>
              <Input
                id="cabinet-edit-password"
                type="password"
                placeholder="Оставьте пустым, если не меняете"
                className="h-12 text-base"
                value={profile.password}
                onChange={(e) =>
                  setProfile({ ...profile, password: e.target.value })
                }
              />
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setEditOpen(false)}
              >
                Отмена
              </Button>
              <Button
                type="submit"
                className="h-12 w-full gap-2 text-base sm:h-10 sm:w-auto sm:text-sm"
                disabled={savingProfile}
              >
                <Pencil className="size-5 sm:size-4" />
                {savingProfile ? "Сохраняем..." : "Сохранить изменения"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Выполненные заказы</h2>
          <Badge variant="outline">{orders.length}</Badge>
        </div>

        {ordersLoading ? (
          <div className="space-y-3">
            {[0, 1].map((i) => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
        ) : orders.length > 0 ? (
          <div className="grid gap-3">
            {orders.map((order) => (
              <Card key={order.id} size="sm">
                <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-start gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600">
                      <History className="size-4" />
                    </div>
                    <div className="min-w-0 space-y-1.5">
                      <RouteLine
                        from={order.from}
                        to={order.to}
                        fromEntrance={order.fromEntrance}
                        toEntrance={order.toEntrance}
                        stops={order.stops}
                      />
                      {order.comment && (
                        <div className="flex items-start gap-1.5 text-xs text-amber-700">
                          <MessageSquare className="mt-0.5 size-3.5 shrink-0" />
                          <span className="min-w-0">
                            <span className="font-medium">
                              Комментарий водителю:
                            </span>{" "}
                            {order.comment}
                          </span>
                        </div>
                      )}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1 font-medium text-foreground/80">
                          №{formatOrderNumber(order.id)}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <User className="size-3.5" />
                          {order.clientName ?? "Клиент"}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Phone className="size-3.5" />
                          {order.clientPhone ? (
                            <a
                              href={`tel:${order.clientPhone}`}
                              className="underline-offset-2 hover:underline"
                            >
                              {order.clientPhone}
                            </a>
                          ) : (
                            "—"
                          )}
                        </span>
                        {order.childSeat && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Baby className="size-3.5" /> Детское кресло
                          </span>
                        )}
                        {order.delivery && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Package className="size-3.5" /> Доставка +350₽
                          </span>
                        )}
                        {order.trunk && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <BaggageClaim className="size-3.5" /> Багажник +50₽
                          </span>
                        )}
                        {order.paymentMethod === "cash" && (
                          <span className="inline-flex items-center gap-1 text-amber-700">
                            <Banknote className="size-3.5" /> Наличными
                            {order.cashChangeFrom != null && (
                              <span className="font-semibold">
                                · с {order.cashChangeFrom}₽
                              </span>
                            )}
                          </span>
                        )}
                        {order.paymentMethod === "card" && (
                          <span className="inline-flex items-center gap-1 text-muted-foreground">
                            <Banknote className="size-3.5" /> Перевод
                          </span>
                        )}
                        {order.suburbanPrice && (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <MapPin className="size-3.5" />{" "}
                            {order.suburbanPrice.name} ·{" "}
                            {order.suburbanPrice.direction === "from"
                              ? "забрать"
                              : "везти"}{" "}
                            {order.suburbanPrice.price}₽
                          </span>
                        )}
                        {order.popularPlacePrice && (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <MapPin className="size-3.5" />{" "}
                            {order.popularPlacePrice.name} ·{" "}
                            {order.popularPlacePrice.price}₽
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-start gap-1.5 sm:items-end">
                    <Badge className="gap-1.5 bg-emerald-500/10 text-emerald-700">
                      <CheckCircle2 className="size-3" />
                      Выполнен
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {formatDateTime(order.createdAt)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={ClipboardList}
            title="Нет выполненных заказов"
            description="Завершённые поездки появятся в этом списке после выполнения заказов."
          />
        )}
      </section>

      <div className="flex items-center gap-3 rounded-xl border bg-muted/30 p-4">
        <ShieldCheck className="size-5 shrink-0 text-primary" />
        <div className="flex flex-1 flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground">
            Хотите взять заказ из общей очереди?
          </p>
          <Link
            href="/driver"
            className={cn(
              buttonVariants({ variant: "outline" }),
              "h-12 gap-2 sm:h-10"
            )}
          >
            <ClipboardList className="size-5 sm:size-4" />
            Панель заказов
          </Link>
        </div>
      </div>
    </div>
  );
}

function LoginForm({
  phone: phoneValue,
  password: passwordValue,
  onPhone,
  onPassword,
  onSubmit,
  busying,
}: {
  phone: string;
  password: string;
  onPhone: (v: string) => void;
  onPassword: (v: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  busying: boolean;
}) {
  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold tracking-tight">
          Личный кабинет водителя
        </h1>
        <p className="text-muted-foreground">
          Войдите в кабинет, чтобы видеть свой профиль, статус и историю
          заказов.
        </p>
      </div>

      <Card className="mx-auto max-w-md">
        <CardContent className="space-y-4 p-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <ShieldCheck className="size-5" />
            </div>
            <div>
              <p className="font-semibold">Авторизация водителя</p>
              <p className="text-xs text-muted-foreground">
                Введите номер телефона и пароль для входа
              </p>
            </div>
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="cabinet-phone">
                <span className="inline-flex items-center gap-1.5">
                  <Phone className="size-4 text-primary" />
                  Телефон
                </span>
              </Label>
              <Input
                id="cabinet-phone"
                type="tel"
                placeholder="+7 900 000-00-00"
                className="h-12 text-base"
                value={phoneValue}
                onChange={(e) => onPhone(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cabinet-password">
                <span className="inline-flex items-center gap-1.5">
                  <KeyRound className="size-4 text-primary" />
                  Пароль
                </span>
              </Label>
              <Input
                id="cabinet-password"
                type="password"
                placeholder="••••••"
                className="h-12 text-base"
                value={passwordValue}
                onChange={(e) => onPassword(e.target.value)}
              />
            </div>
            <Button
              type="submit"
              className="h-12 w-full gap-2 text-base"
              disabled={busying}
            >
              <ShieldCheck className="size-5" />
              {busying ? "Входим..." : "Войти в кабинет"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function RouteLine({
  from,
  to,
  fromEntrance,
  toEntrance,
  stops,
}: {
  from: string;
  to: string;
  fromEntrance?: string;
  toEntrance?: string;
  stops?: OrderStop[];
}) {
  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 flex flex-col items-center gap-1">
        <span className="h-2 w-2 rounded-full bg-emerald-500" />
        {stops?.map((_, i) => (
          <span key={i} className="h-2 w-2 rounded-full bg-primary/70" />
        ))}
        <span className="h-3 w-0.5 border-l border-dashed border-muted-foreground/50" />
        <span className="h-2 w-2 rounded-full bg-destructive" />
      </div>
      <div className="space-y-1.5">
        <p className="text-sm font-semibold leading-tight">
          {addressWithEntrance(from, fromEntrance)}
        </p>
        {stops?.map((stop, i) => (
          <p
            key={i}
            className="text-sm font-medium leading-tight text-muted-foreground"
          >
            {addressWithEntrance(stop.address, stop.entrance)}
          </p>
        ))}
        <p className="text-sm font-semibold leading-tight">
          {addressWithEntrance(to, toEntrance)}
        </p>
      </div>
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Icon className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
