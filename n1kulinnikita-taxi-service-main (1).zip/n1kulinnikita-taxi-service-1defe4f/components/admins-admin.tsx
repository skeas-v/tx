"use client";

import { useCallback, useEffect, useState } from "react";
import { KeyRound, Plus, ShieldCheck, Trash2, User, Users } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ADMIN_ROLE_LABELS, Admin, AdminRole } from "@/lib/models";
import { AdminRoleSelect } from "@/components/admin-role-select";
import { cn } from "@/lib/utils";

const SESSION_HEADER = "x-admin-login";

const ROLE_STYLES: Record<AdminRole, string> = {
  [AdminRole.DEVELOPER]: "border-amber-300 bg-amber-500/10 text-amber-700",
  [AdminRole.ADMIN]: "border-primary/30 bg-primary/10 text-primary",
  [AdminRole.EDITOR]: "border-muted-foreground/30 text-muted-foreground",
};

interface AdminFormState {
  login: string;
  password: string;
  role: AdminRole;
}

const emptyForm: AdminFormState = {
  login: "",
  password: "",
  role: AdminRole.ADMIN,
};

function formatDate(iso: string): string {
  if (!iso) return "";
  return new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function AdminsAdmin({
  currentLogin,
  role,
}: {
  currentLogin: string;
  role: AdminRole;
}) {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<AdminFormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [resetOpenId, setResetOpenId] = useState<string | null>(null);
  const [resetPassword, setResetPassword] = useState("");

  const canManage = role === AdminRole.DEVELOPER || role === AdminRole.ADMIN;
  // Администратор и редактор не видят аккаунты разработчиков и не могут с
  // ними взаимодействовать. Разработчик видит всех.
  const isDeveloperViewer = role === AdminRole.DEVELOPER;

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/users", {
        headers: { [SESSION_HEADER]: currentLogin },
      });
      if (res.ok) {
        setAdmins((await res.json()) as Admin[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки администраторов:", error);
    } finally {
      setLoading(false);
    }
  }, [currentLogin]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!form.login.trim()) {
      toast.error("Укажите логин");
      return;
    }
    if (form.password.length < 4) {
      toast.error("Пароль должен быть не короче 4 символов");
      return;
    }
    setSaving(true);
    const id = toast.loading("Добавляем пользователя...");
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          [SESSION_HEADER]: currentLogin,
        },
        body: JSON.stringify({
          login: form.login.trim(),
          password: form.password,
          role: form.role,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось добавить пользователя", { id });
        return;
      }
      toast.success("Пользователь добавлен", { id });
      setOpen(false);
      setForm(emptyForm);
      refresh();
    } catch (error) {
      console.error("Ошибка добавления пользователя:", error);
      toast.error("Не удалось добавить пользователя", { id });
    } finally {
      setSaving(false);
    }
  }

  async function handleChangeRole(admin: Admin, role: AdminRole) {
    setBusyId(admin.id);
    const id = toast.loading("Сохраняем роль...");
    try {
      const res = await fetch(
        `/api/admin/users/${encodeURIComponent(admin.id)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            [SESSION_HEADER]: currentLogin,
          },
          body: JSON.stringify({ role }),
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось изменить роль", { id });
        return;
      }
      toast.success("Роль обновлена", { id });
      refresh();
    } catch (error) {
      console.error("Ошибка изменения роли:", error);
      toast.error("Не удалось изменить роль", { id });
    } finally {
      setBusyId(null);
    }
  }

  async function handleResetPassword(admin: Admin) {
    if (resetPassword.length < 4) {
      toast.error("Пароль должен быть не короче 4 символов");
      return;
    }
    setSaving(true);
    const id = toast.loading("Сохраняем пароль...");
    try {
      const res = await fetch(
        `/api/admin/users/${encodeURIComponent(admin.id)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            [SESSION_HEADER]: currentLogin,
          },
          body: JSON.stringify({ password: resetPassword }),
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось изменить пароль", { id });
        return;
      }
      toast.success("Пароль изменён", { id });
      setResetOpenId(null);
      setResetPassword("");
      refresh();
    } catch (error) {
      console.error("Ошибка изменения пароля:", error);
      toast.error("Не удалось изменить пароль", { id });
    } finally {
      setSaving(false);
    }
  }

  function confirmDelete(admin: Admin) {
    toast(`Удалить пользователя ${admin.login}?`, {
      description:
        "Действие необратимо. Пользователь потеряет доступ к панели.",
      action: {
        label: "Удалить",
        onClick: () => handleDelete(admin),
      },
      cancel: {
        label: "Отмена",
        onClick: () => {},
      },
    });
  }

  async function handleDelete(admin: Admin) {
    setBusyId(admin.id);
    const id = toast.loading("Удаляем пользователя...");
    try {
      const res = await fetch(
        `/api/admin/users/${encodeURIComponent(admin.id)}`,
        {
          method: "DELETE",
          headers: { [SESSION_HEADER]: currentLogin },
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось удалить пользователя", { id });
        return;
      }
      toast.success("Пользователь удалён", { id });
      refresh();
    } catch (error) {
      console.error("Ошибка удаления пользователя:", error);
      toast.error("Не удалось удалить пользователя", { id });
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Доступ</h2>
          <Badge variant="outline">{admins.length}</Badge>
        </div>
        {canManage && (
          <Button className="gap-2" onClick={() => setOpen(true)}>
            <Plus className="size-4" />
            Добавить администратора
          </Button>
        )}
      </div>

      <p className="text-sm text-muted-foreground">
        Разработчик видит все функции, администратор — все функции и управление
        доступом, редактор — заказы и управление водителями. Аккаунты
        разработчиков скрыты от администраторов и редакторов.
      </p>

      {loading ? (
        <div className="grid gap-3">
          {[0, 1].map((i) => (
            <Skeleton key={i} className="h-20 w-full rounded-xl" />
          ))}
        </div>
      ) : admins.length > 0 ? (
        <div className="grid gap-3">
          {admins.map((admin) => {
            const isMe = admin.login === currentLogin;
            // Разработчик видит всех. Администратор/редактор — только
            // обычных администраторов и редакторов (фильтр на клиенте как
            // дополнительная защита к серверной фильтрации).
            const isDeveloper = admin.role === AdminRole.DEVELOPER;
            if (!isDeveloperViewer && isDeveloper) return null;
            const canManageThis =
              canManage && (isDeveloperViewer || !isDeveloper);
            return (
              <Card key={admin.id} size="sm">
                <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <User className="size-5" />
                    </div>
                    <div className="min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="truncate font-medium">{admin.login}</p>
                        {isMe && <Badge variant="outline">Вы</Badge>}
                        <Badge
                          variant="outline"
                          className={cn(
                            "gap-1.5",
                            ROLE_STYLES[admin.role] ??
                              ROLE_STYLES[AdminRole.ADMIN]
                          )}
                        >
                          <ShieldCheck className="size-3" />
                          {ADMIN_ROLE_LABELS[admin.role] ??
                            ADMIN_ROLE_LABELS[AdminRole.ADMIN]}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Создан: {formatDate(admin.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {canManageThis && (
                      <AdminRoleSelect
                        value={admin.role}
                        disabled={busyId === admin.id}
                        allowedRoles={
                          role === AdminRole.DEVELOPER
                            ? Object.values(AdminRole)
                            : [AdminRole.ADMIN, AdminRole.EDITOR]
                        }
                        onValueChange={(value) =>
                          handleChangeRole(
                            admin,
                            (value ?? admin.role) as AdminRole
                          )
                        }
                      />
                    )}
                    {canManageThis && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        disabled={busyId === admin.id}
                        onClick={() => setResetOpenId(admin.id)}
                      >
                        <KeyRound className="size-4" />
                        Пароль
                      </Button>
                    )}
                    {canManageThis && !isMe && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                        disabled={busyId === admin.id}
                        onClick={() => confirmDelete(admin)}
                      >
                        <Trash2 className="size-4" />
                        Удалить
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <EmptyState
          title="Пользователи панели не найдены"
          description="Добавьте первого администратора."
        />
      )}

      <Dialog open={open} onOpenChange={(v) => setOpen(v)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Добавить администратора</DialogTitle>
            <DialogDescription>
              Новый пользователь сможет входить в админ-панель с указанной
              ролью.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreate} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="admin-user-login">Логин</Label>
              <Input
                id="admin-user-login"
                placeholder="admin"
                value={form.login}
                onChange={(e) => setForm({ ...form, login: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-user-password">Пароль</Label>
              <Input
                id="admin-user-password"
                type="password"
                placeholder="••••••"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-user-role">Роль</Label>
              <Select
                items={[
                  { label: "Администратор", value: AdminRole.ADMIN },
                  ...(role === AdminRole.DEVELOPER
                    ? [{ label: "Разработчик", value: AdminRole.DEVELOPER }]
                    : []),
                  { label: "Редактор", value: AdminRole.EDITOR },
                ]}
                value={form.role}
                onValueChange={(value) =>
                  setForm({
                    ...form,
                    role: (value ?? AdminRole.ADMIN) as AdminRole,
                  })
                }
              >
                <SelectTrigger id="admin-user-role" className="h-10 w-full">
                  <SelectValue placeholder="Выберите роль" />
                </SelectTrigger>
                <SelectContent className="w-full">
                  <SelectGroup>
                    <SelectItem value={AdminRole.ADMIN}>
                      Администратор
                    </SelectItem>
                    {role === AdminRole.DEVELOPER && (
                      <SelectItem value={AdminRole.DEVELOPER}>
                        Разработчик
                      </SelectItem>
                    )}
                    <SelectItem value={AdminRole.EDITOR}>Редактор</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Редактор видит заказы и может редактировать и блокировать
                водителей.
              </p>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
              >
                Отмена
              </Button>
              <Button type="submit" className="gap-2" disabled={saving}>
                <Plus className="size-4" />
                {saving ? "Добавляем..." : "Добавить"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={resetOpenId !== null}
        onOpenChange={(v) => {
          if (!v) {
            setResetOpenId(null);
            setResetPassword("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Новый пароль</DialogTitle>
            <DialogDescription>
              Введите новый пароль для входа в панель.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="admin-user-reset-password">Пароль</Label>
            <Input
              id="admin-user-reset-password"
              type="password"
              placeholder="••••••"
              value={resetPassword}
              onChange={(e) => setResetPassword(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setResetOpenId(null);
                setResetPassword("");
              }}
            >
              Отмена
            </Button>
            <Button
              type="button"
              className="gap-2"
              disabled={saving}
              onClick={() => {
                const admin = admins.find((a) => a.id === resetOpenId);
                if (admin) void handleResetPassword(admin);
              }}
            >
              <KeyRound className="size-4" />
              {saving ? "Сохраняем..." : "Сохранить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

function EmptyState({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Users className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
