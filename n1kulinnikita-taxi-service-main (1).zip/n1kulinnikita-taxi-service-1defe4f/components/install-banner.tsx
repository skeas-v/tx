"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { AppWindow, Share, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const DISMISSED_KEY = "taxi_install_banner_dismissed";

type DeferredPrompt = {
  prompt: () => void;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const NON_CLIENT_PREFIXES = ["/driver", "/admin", "/demo", "/api", "/order"];

function isStandalone(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (navigator as any).standalone === true
  );
}

export function InstallBanner() {
  const pathname = usePathname();
  const [visible, setVisible] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const deferredPromptRef = useRef<DeferredPrompt | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const isClientPage = !NON_CLIENT_PREFIXES.some(
      (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`)
    );
    if (!isClientPage) return;

    if (
      localStorage.getItem("taxi_driver_phone") ||
      localStorage.getItem("taxi_admin_login")
    ) {
      return;
    }
    if (isStandalone()) return;
    if (localStorage.getItem(DISMISSED_KEY)) return;

    const id = window.setTimeout(() => setVisible(true), 0);
    return () => window.clearTimeout(id);
  }, [pathname]);

  useEffect(() => {
    const onBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      deferredPromptRef.current = event as unknown as DeferredPrompt;
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstallPrompt);
    return () =>
      window.removeEventListener("beforeinstallprompt", onBeforeInstallPrompt);
  }, []);

  const handleInstall = async () => {
    const deferredPrompt = deferredPromptRef.current;
    if (deferredPrompt) {
      deferredPrompt.prompt();
      await deferredPrompt.userChoice.catch(() => undefined);
      deferredPromptRef.current = null;
      setVisible(false);
      return;
    }
    setShowHelp(true);
  };

  const handleDismiss = () => {
    if (typeof window !== "undefined") {
      localStorage.setItem(DISMISSED_KEY, "1");
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <>
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-40 px-4 sm:flex sm:justify-center">
        <div className="pointer-events-auto flex w-full max-w-md animate-in fade-in slide-in-from-bottom-4 duration-500 items-center gap-3 rounded-xl border border-primary/15 bg-popover p-3 shadow-warm-sm">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <AppWindow className="size-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold leading-tight">Твоё Новое</p>
            <p className="text-xs text-muted-foreground">
              Установите приложение и заказывайте поездки в один клик
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <Button size="sm" onClick={handleInstall}>
              Установить приложение
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={handleDismiss}
              aria-label="Закрыть баннер"
            >
              <X className="size-4" />
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={showHelp} onOpenChange={setShowHelp}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Как установить приложение</DialogTitle>
            <DialogDescription>
              Добавьте приложение на главный экран через меню браузера:
            </DialogDescription>
          </DialogHeader>
          <ol className="space-y-3">
            <li className="flex items-start gap-2.5">
              <Share className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>
                Нажмите кнопку <strong>«Поделиться»</strong> в меню браузера
                (значок квадрата со стрелкой).
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <AppWindow className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>
                Выберите <strong>«На главный экран»</strong> (или «Добавить на
                экран „Домой“»).
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <AppWindow className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>
                Подтвердите добавление — значок приложения появится на главном
                экране.
              </span>
            </li>
          </ol>
        </DialogContent>
      </Dialog>
    </>
  );
}
