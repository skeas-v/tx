"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CarFront,
  CheckCircle2,
  Crosshair,
  MapPin,
  Navigation,
  Phone,
  PhoneCall,
  Send,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  Driver,
  Order,
  OrderStatus,
  carArrivalLabel,
  formatOrderNumber,
} from "@/lib/models";
import {
  createCallOrderSchema,
  createOrderSchema,
} from "@/lib/validation/orders";
import { createCallReviewSchema } from "@/lib/validation/call-reviews";
import { OrderMap } from "@/components/order-map";
import { AddressInput } from "@/components/address-input";
import { RouteCard } from "@/components/route-card";
import { OrderTimeline } from "@/components/order-timeline";
import { looksLikeBuildingAddress } from "@/lib/address";
import type { ResolvedAddress } from "@/lib/yandex-maps";
import { DriverCard } from "@/components/driver-card";
import {
  maybeRequestNotificationPermission,
  showBrowserNotification,
} from "@/lib/notifications";
import { VK_CHAT_URL } from "@/lib/links";

const POLL_INTERVAL_MS = 5000;
const NO_DRIVER_TIMEOUT_MS = 7 * 60 * 1000;

function VkIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14C20.67 22 22 20.67 22 15.07V8.93C22 3.33 20.67 2 15.07 2zM12.2 17c-4.28 0-6.72-2.94-6.82-7.83h2.14c.07 3.58 1.65 5.1 2.9 5.41V9.17h2.02v3.09c1.23-.13 2.53-1.54 2.97-3.09h2.02c-.34 1.92-1.75 3.33-2.75 3.91 1 .47 2.61 1.7 3.22 3.92H15.6c-.48-1.51-1.66-2.67-3.24-2.83V17H12.2z" />
    </svg>
  );
}

export function BookingForm() {
  const router = useRouter();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [fromEntrance, setFromEntrance] = useState("");
  const [toEntrance, setToEntrance] = useState("");
  const [fromAddress, setFromAddress] = useState<string | undefined>();
  const [toAddress, setToAddress] = useState<string | undefined>();
  const [fromLat, setFromLat] = useState<number | undefined>();
  const [fromLng, setFromLng] = useState<number | undefined>();
  const [toLat, setToLat] = useState<number | undefined>();
  const [toLng, setToLng] = useState<number | undefined>();
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);
  const [calling, setCalling] = useState(false);
  const [callDriver, setCallDriver] = useState<Driver | null>(null);
  const [callOrderId, setCallOrderId] = useState<string | null>(null);
  const [callStep, setCallStep] = useState<
    "question" | "agreed" | "declined" | "submitted" | null
  >(null);
  const [reviewText, setReviewText] = useState("");
  const [sendingReview, setSendingReview] = useState(false);
  const driverNotifiedRef = useRef(false);
  const timeoutNotifiedRef = useRef(false);
  const driverWaitingNotifiedRef = useRef<string | null>(null);
  const completedNotifiedRef = useRef(false);

  async function handleCallDriver() {
    const parsed = createCallOrderSchema.safeParse({
      clientName,
      clientPhone,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Укажите контактные данные");
      return;
    }

    setCalling(true);
    const id = toast.loading("Ищем свободного водителя...");
    void maybeRequestNotificationPermission();
    try {
      const res = await fetch("/api/orders/call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      const driver = data?.driver;
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось найти водителя", { id });
        return;
      }
      if (!driver?.phone) {
        toast.error("Никого нет сейчас", { id });
        return;
      }
      const orderNumber = data?.order?.id
        ? ` Заказ №${formatOrderNumber(data.order.id)}.`
        : "";
      toast.success(`Связываем вас с свободным водителем.${orderNumber}`, {
        id,
      });
      setCallDriver(driver as Driver);
      setCallOrderId(data?.order?.id ?? null);
      setCallStep("question");
      setReviewText("");
      window.location.href = `tel:${driver.phone}`;
    } catch (err) {
      console.error("Ошибка вызова водителя:", err);
      toast.error("Никого нет сейчас", { id });
    } finally {
      setCalling(false);
    }
  }

  function resetCallFlow() {
    setCallDriver(null);
    setCallOrderId(null);
    setCallStep(null);
    setReviewText("");
  }

  async function handleSubmitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!callDriver) return;
    const parsed = createCallReviewSchema.safeParse({
      orderId: callOrderId ?? undefined,
      driverId: callDriver.id,
      driverName: callDriver.name,
      clientName: clientName.trim() || undefined,
      clientPhone: clientPhone.trim() || undefined,
      review: reviewText,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Опишите причину");
      return;
    }

    setSendingReview(true);
    const id = toast.loading("Отправляем отзыв...");
    try {
      const res = await fetch("/api/call-reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось отправить отзыв", { id });
        return;
      }
      toast.success("Спасибо за отзыв", { id });
      setCallStep("submitted");
    } catch (err) {
      console.error("Ошибка отправки отзыва:", err);
      toast.error("Не удалось отправить отзыв", { id });
    } finally {
      setSendingReview(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const parsed = createOrderSchema.safeParse({
      from,
      to,
      fromAddress,
      toAddress,
      fromEntrance: looksLikeBuildingAddress(from)
        ? fromEntrance.trim() || undefined
        : undefined,
      toEntrance: looksLikeBuildingAddress(to)
        ? toEntrance.trim() || undefined
        : undefined,
      fromLat,
      fromLng,
      toLat,
      toLng,
      clientName,
      clientPhone,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Укажите корректные точки маршрута");
      return;
    }

    setSubmitting(true);
    const id = toast.loading("Оформляем заказ...");
    void maybeRequestNotificationPermission();

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast.error(data?.error ?? "Не удалось оформить заказ", { id });
        return;
      }

      const order: Order = await res.json();
      setConfirmedOrder(order);
      setConfirmedOrderId(order.id);
      driverNotifiedRef.current = false;
      timeoutNotifiedRef.current = false;
      driverWaitingNotifiedRef.current = null;
      completedNotifiedRef.current = false;
      toast.success("Заказ оформлен", { id });
    } catch (err) {
      console.error("Ошибка оформления заказа:", err);
      toast.error("Не удалось оформить заказ", { id });
    } finally {
      setSubmitting(false);
    }
  }

  useEffect(() => {
    if (!confirmedOrderId) return;

    const orderId = confirmedOrderId;
    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | null = null;

    async function poll() {
      try {
        const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}`);
        if (!res.ok) return;
        const next: Order = await res.json();
        if (cancelled) return;

        const arrived =
          (next.status === OrderStatus.ASSIGNED ||
            next.status === OrderStatus.IN_PROGRESS) &&
          (next.driver?.carMake || next.driver?.carNumber);
        if (arrived && !driverNotifiedRef.current) {
          driverNotifiedRef.current = true;
          const message = `К Вам приедет ${carArrivalLabel(next.driver)}`;
          toast.success(message);
          showBrowserNotification(message);
        }

        if (
          next.driverWaitingAt &&
          driverWaitingNotifiedRef.current !== next.driverWaitingAt
        ) {
          driverWaitingNotifiedRef.current = next.driverWaitingAt;
          toast.success("Водитель ожидает вас");
          showBrowserNotification("Водитель ожидает вас");
        }

        if (
          next.status === OrderStatus.COMPLETED &&
          !completedNotifiedRef.current
        ) {
          completedNotifiedRef.current = true;
          toast.success("Поездка выполнена");
          showBrowserNotification("Поездка выполнена");
        }

        const elapsed = Date.now() - new Date(next.createdAt).getTime();
        if (
          next.status === OrderStatus.WAITING &&
          !timeoutNotifiedRef.current &&
          elapsed >= NO_DRIVER_TIMEOUT_MS
        ) {
          timeoutNotifiedRef.current = true;
          const message =
            "К сожалению, на линии временно никого нет, попробуйте через чат ВКонтакте";
          toast.warning(message);
          showBrowserNotification(message);
        }

        setConfirmedOrder((prev) => (prev?.id === next.id ? next : prev));

        if (
          (next.status === OrderStatus.COMPLETED ||
            next.status === OrderStatus.CANCELLED) &&
          timer
        ) {
          clearInterval(timer);
          timer = null;
        }
      } catch {
        // Временные ошибки поллинга безопасно игнорировать
      }
    }

    poll();
    timer = setInterval(poll, POLL_INTERVAL_MS);

    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
    };
  }, [confirmedOrderId]);

  const callCarLabel = callDriver
    ? [callDriver.carMake, callDriver.carNumber].filter(Boolean).join(", ") ||
      "Автомобиль не указан"
    : "";

  const handleFromResolve = useCallback((res: ResolvedAddress | null) => {
    setFromAddress(res?.address);
    setFromLat(res?.lat);
    setFromLng(res?.lng);
  }, []);

  const handleToResolve = useCallback((res: ResolvedAddress | null) => {
    setToAddress(res?.address);
    setToLat(res?.lat);
    setToLng(res?.lng);
  }, []);

  const handleFromPick = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setFrom(res.address);
    setFromAddress(res.address);
    setFromLat(res.lat);
    setFromLng(res.lng);
  }, []);

  const handleToPick = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setTo(res.address);
    setToAddress(res.address);
    setToLat(res.lat);
    setToLng(res.lng);
  }, []);

  const handleLocate = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setFrom(res.address);
    setFromAddress(res.address);
    setFromLat(res.lat);
    setFromLng(res.lng);
  }, []);

  if (callStep && callDriver) {
    return (
      <Card className="card-hover relative z-10 rounded-2xl bg-background p-6 shadow-warm animate-in fade-in slide-in-from-bottom-8 duration-500 lg:p-8">
        <CardContent className="space-y-4 p-0">
          {callStep === "question" && (
            <>
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <PhoneCall className="size-7" />
                </div>
                <h2 className="text-xl font-bold tracking-tight">
                  Вы договорились с водителем?
                </h2>
                <p className="text-sm text-muted-foreground">
                  Мы соединили вас с водителем. Подтвердите, удалось ли
                  договориться о поездке.
                </p>
              </div>

              <div className="grid gap-2">
                <Button
                  className="group/btn w-full gap-2"
                  onClick={() => setCallStep("agreed")}
                >
                  <CheckCircle2 className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                  Да, договорились
                </Button>
                <Button
                  variant="outline"
                  className="group/btn w-full gap-2"
                  onClick={() => setCallStep("declined")}
                >
                  <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                  Нет, не получилось
                </Button>
              </div>
            </>
          )}

          {callStep === "agreed" && (
            <>
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                  <CheckCircle2 className="size-8" />
                </div>
                <h2 className="text-xl font-bold tracking-tight">
                  Машина приедет
                </h2>
                <p className="text-sm text-muted-foreground">
                  Ожидайте автомобиль. Время ожидания — 5–7 минут.
                </p>
              </div>

              <div className="space-y-3 rounded-2xl border bg-gradient-to-br from-card to-accent/40 p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <CarFront className="size-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-muted-foreground">
                      Какая машина приедет
                    </p>
                    <p className="truncate font-semibold">{callCarLabel}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <User className="size-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-muted-foreground">Водитель</p>
                    <p className="truncate font-semibold">{callDriver.name}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between rounded-xl border bg-muted/40 px-4 py-3 text-sm">
                <span className="text-muted-foreground">Время ожидания</span>
                <span className="font-semibold">5–7 минут</span>
              </div>

              <div className="grid gap-2">
                <Button
                  className="group/btn w-full gap-2"
                  onClick={() => {
                    window.location.href = `tel:${callDriver.phone}`;
                  }}
                >
                  <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                  Связаться с этим водителем повторно
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={resetCallFlow}
                >
                  Вернуться к заказу
                </Button>
              </div>
            </>
          )}

          {callStep === "declined" && (
            <form onSubmit={handleSubmitReview} className="space-y-4">
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
                  <Phone className="size-7" />
                </div>
                <h2 className="text-xl font-bold tracking-tight">
                  Расскажите, почему не удалось вызвать машину?
                </h2>
                <p className="text-sm text-muted-foreground">
                  Ваш отзыв поможет нам улучшить сервис.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="call-review" className="sr-only">
                  Причина
                </Label>
                <Textarea
                  id="call-review"
                  placeholder="Например: водитель не ответил, не приехал вовремя..."
                  value={reviewText}
                  maxLength={1000}
                  onChange={(e) => setReviewText(e.target.value)}
                  required
                />
              </div>

              <div className="grid gap-2">
                <Button
                  type="submit"
                  className="w-full gap-2"
                  disabled={sendingReview}
                >
                  <Send className="size-4" />
                  {sendingReview ? "Отправляем..." : "Отправить отзыв"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={resetCallFlow}
                >
                  Отмена
                </Button>
              </div>
            </form>
          )}

          {callStep === "submitted" && (
            <div className="space-y-4">
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                  <CheckCircle2 className="size-8" />
                </div>
                <h2 className="text-xl font-bold tracking-tight">
                  Спасибо за отзыв
                </h2>
                <p className="text-sm text-muted-foreground">
                  Мы передали ваш ответ администратору.
                </p>
              </div>
              <Button
                variant="outline"
                className="w-full"
                onClick={resetCallFlow}
              >
                Вернуться к заказу
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  if (confirmedOrder) {
    return (
      <Card className="card-hover relative z-10 rounded-2xl bg-background p-6 shadow-warm animate-in fade-in slide-in-from-bottom-8 duration-500 lg:p-8">
        <CardContent className="space-y-4 p-0">
          <div className="flex flex-col items-center gap-3 text-center">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
              <span className="absolute inset-0 rounded-full bg-emerald-500/10 animate-ping opacity-40" />
              <CheckCircle2 className="size-8" />
            </div>
            <h2 className="text-xl font-bold tracking-tight">Заказ оформлен</h2>
            <p className="text-sm text-muted-foreground">
              Ваш заказ отправлен в очередь для водителей. Водитель скоро его
              примет.
            </p>
          </div>

          <RouteCard
            from={confirmedOrder.from}
            to={confirmedOrder.to}
            fromEntrance={confirmedOrder.fromEntrance}
            toEntrance={confirmedOrder.toEntrance}
          />

          <OrderTimeline status={confirmedOrder.status} />

          {(confirmedOrder.driver || confirmedOrder.driverName) && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
              <DriverCard order={confirmedOrder} />
            </div>
          )}

          <OrderMap
            from={confirmedOrder.from}
            to={confirmedOrder.to}
            height={196}
          />

          <div className="flex items-center justify-between rounded-xl border bg-muted/40 px-4 py-3 text-sm">
            <span className="text-muted-foreground">Номер заказа</span>
            <span className="font-mono font-semibold">
              №{formatOrderNumber(confirmedOrder.id)}
            </span>
          </div>

          <div className="grid gap-2">
            <Button
              className="group/btn w-full gap-2"
              onClick={() =>
                router.push(
                  `/track?id=${encodeURIComponent(confirmedOrder.id)}`
                )
              }
            >
              <MapPin className="size-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
              Отслеживать статус заказа
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setConfirmedOrder(null);
                setConfirmedOrderId(null);
                driverNotifiedRef.current = false;
                timeoutNotifiedRef.current = false;
                driverWaitingNotifiedRef.current = null;
                completedNotifiedRef.current = false;
              }}
            >
              Оформить ещё один заказ
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const fromHasEntrance = looksLikeBuildingAddress(from);
  const toHasEntrance = looksLikeBuildingAddress(to);

  return (
    <Card className="card-hover relative z-10 overflow-hidden rounded-2xl bg-background shadow-warm animate-in fade-in slide-in-from-bottom-8 duration-700">
      <OrderMap
        from={from}
        to={to}
        height={240}
        showLocate
        autoLocate
        className="rounded-none border-0"
        onFromResolve={handleFromResolve}
        onToResolve={handleToResolve}
        onFromPick={handleFromPick}
        onToPick={handleToPick}
        onLocate={handleLocate}
      />

      <CardContent className="p-5 sm:p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-center gap-1 py-1">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
              <span className="h-7 w-0.5 border-l border-dashed border-muted-foreground/40" />
              <span className="h-2.5 w-2.5 rounded-full bg-destructive" />
            </div>
            <div className="flex flex-1 flex-col gap-3">
              <div className="space-y-2">
                <Label htmlFor="from" className="sr-only">
                  Откуда
                </Label>
                <AddressInput
                  id="from"
                  placeholder="Откуда — адрес или точка на карте"
                  value={from}
                  onValueChange={(v) => {
                    setFrom(v);
                    setFromAddress(undefined);
                    if (!looksLikeBuildingAddress(v)) {
                      setFromEntrance("");
                    }
                  }}
                  required
                />
                {fromHasEntrance && (
                  <Input
                    id="fromEntrance"
                    inputMode="text"
                    maxLength={10}
                    placeholder="Подъезд (если есть)"
                    value={fromEntrance}
                    onChange={(e) => setFromEntrance(e.target.value)}
                  />
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="to" className="sr-only">
                  Куда
                </Label>
                <AddressInput
                  id="to"
                  placeholder="Куда — адрес или точка на карте"
                  value={to}
                  onValueChange={(v) => {
                    setTo(v);
                    setToAddress(undefined);
                    if (!looksLikeBuildingAddress(v)) {
                      setToEntrance("");
                    }
                  }}
                  required
                />
                {toHasEntrance && (
                  <Input
                    id="toEntrance"
                    inputMode="text"
                    maxLength={10}
                    placeholder="Подъезд (если есть)"
                    value={toEntrance}
                    onChange={(e) => setToEntrance(e.target.value)}
                  />
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-xl border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
            <Crosshair className="size-3.5 shrink-0 text-primary" />
            <span>
              Нажмите на карту, чтобы отметить точку, или определите своё
              местоположение — адрес заполнится автоматически.
            </span>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="clientName">Имя (необязательно)</Label>
              <Input
                id="clientName"
                placeholder="Как вас зовут?"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="clientPhone">Телефон (необязательно)</Label>
              <Input
                id="clientPhone"
                type="tel"
                placeholder="+7 ___ ___-__-__"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
              />
            </div>
          </div>

          <Button
            type="submit"
            className="group/btn w-full gap-2 shadow-warm-sm"
            size="lg"
            disabled={submitting}
          >
            {submitting ? (
              <span className="flex items-center gap-2">
                <MapPin className="size-4 animate-pulse" />
                Оформляем...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Navigation className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                Оформить заказ
              </span>
            )}
          </Button>

          <div className="grid gap-2 sm:grid-cols-2">
            <Button
              type="button"
              variant="outline"
              className="group/btn w-full gap-2"
              size="lg"
              disabled={calling}
              onClick={handleCallDriver}
            >
              <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
              {calling ? "Ищем..." : "Вызвать по телефону"}
            </Button>

            <a
              href={VK_CHAT_URL}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                buttonVariants({ variant: "outline", size: "lg" }),
                "group/btn w-full gap-2"
              )}
            >
              <VkIcon className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
              Через Чат
            </a>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
