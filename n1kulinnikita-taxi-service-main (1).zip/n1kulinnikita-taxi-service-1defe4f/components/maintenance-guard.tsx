"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Wrench, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

const LOGIN_KEY = "taxi_admin_login";

interface PublicSettings {
  siteName?: string;
  maintenanceMode?: boolean;
}

export function MaintenanceGuard({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [settings, setSettings] = useState<PublicSettings | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/settings")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: PublicSettings | null) => {
        if (!cancelled) {
          setSettings(data ?? { maintenanceMode: false });
        }
      })
      .catch(() => {
        if (!cancelled) setSettings({ maintenanceMode: false });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const isAdmin =
    typeof window !== "undefined" && !!localStorage.getItem(LOGIN_KEY);
  const isAdminRoute = pathname?.startsWith("/admin") ?? false;
  const maintenanceOn = settings?.maintenanceMode === true;

  if (maintenanceOn && !isAdmin && !isAdminRoute) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center px-4 py-16">
        <div className="w-full max-w-md space-y-5 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Wrench className="size-8" />
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight">
              Технические работы
            </h1>
            <p className="text-muted-foreground">
              На сайте сейчас проводятся технические работы. Попробуйте зайти
              чуть позже.
            </p>
          </div>
          <Button
            variant="outline"
            className="gap-2"
            render={<Link href="/admin" />}
          >
            <ShieldCheck className="size-4" />
            Вход для администратора
          </Button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
