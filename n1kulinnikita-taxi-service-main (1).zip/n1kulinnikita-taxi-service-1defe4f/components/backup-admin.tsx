"use client";

import { useRef, useState } from "react";
import {
  DatabaseBackup,
  Download,
  FileJson,
  FolderLock,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function BackupAdmin() {
  const [exporting, setExporting] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [lastExport, setLastExport] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function handleEncryptedExport() {
    setExporting(true);
    const id = toast.loading("Сохраняем данные в зашифрованный файл...");
    try {
      const res = await fetch("/api/admin/export", { method: "POST" });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить файл", { id });
        return;
      }
      setLastExport(data.filename ?? null);
      toast.success("Данные сохранены в зашифрованный файл", { id });
    } catch (error) {
      console.error("Ошибка экспорта данных:", error);
      toast.error("Не удалось сохранить файл", { id });
    } finally {
      setExporting(false);
    }
  }

  async function handleDownload() {
    setDownloading(true);
    const id = toast.loading("Формируем файл бэкапа...");
    try {
      const res = await fetch("/api/admin/backup");
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast.error(data?.error ?? "Не удалось сформировать бэкап", { id });
        return;
      }
      const blob = await res.blob();
      const disposition = res.headers.get("Content-Disposition") ?? "";
      const match = disposition.match(/filename="?([^"]+)"?/);
      const filename = match?.[1] ?? `backup-${Date.now()}.json`;

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast.success("Бэкап скачан", { id });
    } catch (error) {
      console.error("Ошибка выгрузки бэкапа:", error);
      toast.error("Не удалось скачать бэкап", { id });
    } finally {
      setDownloading(false);
    }
  }

  async function handleImportFile(file: File) {
    setImporting(true);
    const id = toast.loading("Восстанавливаем данные из бэкапа...");
    try {
      const text = await file.text();
      const payload = JSON.parse(text);
      const res = await fetch("/api/admin/backup/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payload }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось восстановить данные", { id });
        return;
      }
      const counts = data?.counts as
        | {
            orders?: number;
            drivers?: number;
            subscriptions?: number;
            reviews?: number;
            suburbanAddresses?: number;
            popularPlaces?: number;
          }
        | undefined;
      toast.success(
        `Данные восстановлены: заказов ${counts?.orders ?? 0}, водителей ${
          counts?.drivers ?? 0
        }, подписок ${counts?.subscriptions ?? 0}, отзывов ${
          counts?.reviews ?? 0
        }, адресов ${counts?.suburbanAddresses ?? 0}, мест ${
          counts?.popularPlaces ?? 0
        }`,
        { id }
      );
    } catch (error) {
      console.error("Ошибка восстановления бэкапа:", error);
      toast.error("Не удалось прочитать файл бэкапа", { id });
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  function onFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    void handleImportFile(file);
  }

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <DatabaseBackup className="size-5" />
        </div>
        <div className="flex-1">
          <h2 className="text-xl font-semibold">Бэкап данных</h2>
          <p className="text-xs text-muted-foreground">
            Выгрузка и восстановление всех данных приложения.
          </p>
        </div>
      </div>

      <Card>
        <CardContent className="space-y-5 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Download className="size-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Скачать бэкап</h3>
              <p className="text-xs text-muted-foreground">
                Сохраняет все данные (заказы, водители, настройки, подписки,
                отзывы) в файл JSON.
              </p>
            </div>
          </div>

          <Button
            className="gap-2"
            onClick={handleDownload}
            disabled={downloading}
          >
            <Download className="size-4" />
            {downloading ? "Формируем..." : "Скачать файл бэкапа"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-5 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Upload className="size-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Восстановить из файла</h3>
              <p className="text-xs text-muted-foreground">
                Загрузите ранее сохранённый файл бэкапа, чтобы восстановить
                данные.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              className="hidden"
              onChange={onFileSelected}
            />
            <Button
              variant="outline"
              className="gap-2"
              disabled={importing}
              onClick={() => fileInputRef.current?.click()}
            >
              <FileJson className="size-4" />
              {importing ? "Восстанавливаем..." : "Выбрать файл бэкапа"}
            </Button>
            <span className="text-xs text-muted-foreground">
              Поддерживаются файлы JSON, скачанные из админ-панели.
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-5 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <FolderLock className="size-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">
                Экспорт в зашифрованный файл
              </h3>
              <p className="text-xs text-muted-foreground">
                Сохранить все данные в зашифрованный файл (AES-256-GCM) в папке
                /sec/bd/.
              </p>
            </div>
          </div>

          <Button
            className="gap-2"
            onClick={handleEncryptedExport}
            disabled={exporting}
          >
            <FolderLock className="size-4" />
            {exporting
              ? "Сохраняем..."
              : "Сохранить данные в зашифрованный файл"}
          </Button>

          {lastExport && (
            <p className="text-xs text-muted-foreground">
              Файл:{" "}
              <span className="font-medium text-foreground">{lastExport}</span>
            </p>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
