import { Flag, MapPin } from "lucide-react";

import { cn } from "@/lib/utils";
import { addressWithEntrance } from "@/lib/address";
import type { OrderStop } from "@/lib/models";

interface RouteCardProps {
  from: string;
  to: string;
  fromEntrance?: string;
  toEntrance?: string;
  stops?: OrderStop[];
  className?: string;
}

export function RouteCard({
  from,
  to,
  fromEntrance,
  toEntrance,
  stops,
  className,
}: RouteCardProps) {
  return (
    <div
      className={cn(
        "rounded-2xl border bg-gradient-to-br from-card to-accent/40 p-4",
        className
      )}
    >
      <div className="flex items-start gap-3">
        <div className="flex flex-col items-center pt-0.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600 ring-1 ring-emerald-500/30">
            <MapPin className="size-4" />
          </span>
          {stops?.map((stop, i) => (
            <span
              key={i}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary ring-1 ring-primary/30"
              title="Промежуточная точка"
            >
              {i + 1}
            </span>
          ))}
          <span className="my-1 h-8 w-px border-l-2 border-dashed border-muted-foreground/30" />
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-destructive/10 text-destructive ring-1 ring-destructive/30">
            <Flag className="size-4" />
          </span>
        </div>
        <div className="flex flex-1 flex-col gap-4 pt-1.5">
          <div>
            <p className="text-xs font-medium text-muted-foreground">Откуда</p>
            <p className="mt-0.5 text-sm font-semibold leading-snug">
              {addressWithEntrance(from, fromEntrance)}
            </p>
          </div>
          {stops?.map((stop, i) => (
            <div key={i}>
              <p className="text-xs font-medium text-muted-foreground">
                Остановка {i + 1}
              </p>
              <p className="mt-0.5 text-sm font-semibold leading-snug">
                {addressWithEntrance(stop.address, stop.entrance)}
              </p>
            </div>
          ))}
          <div>
            <p className="text-xs font-medium text-muted-foreground">Куда</p>
            <p className="mt-0.5 text-sm font-semibold leading-snug">
              {addressWithEntrance(to, toEntrance)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
