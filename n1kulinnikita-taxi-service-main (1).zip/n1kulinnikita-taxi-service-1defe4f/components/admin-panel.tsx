"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Baby,
  BaggageClaim,
  Banknote,
  BarChart3,
  Bell,
  CarFront,
  CheckCircle2,
  CircleOff,
  Clock,
  DatabaseBackup,
  History,
  Inbox,
  KeyRound,
  LogOut,
  MapPin,
  MessageSquare,
  Package,
  Pencil,
  Phone,
  PhoneCall,
  Search,
  Settings,
  ShieldCheck,
  Trash2,
  Undo2,
  User,
  UserRound,
  Users,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Admin,
  ADMIN_ROLE_LABELS,
  AdminRole,
  CallResult,
  CallReview,
  Order,
  OrderStatus,
  OrderStop,
  formatOrderNumber,
} from "@/lib/models";
import { addressWithEntrance } from "@/lib/address";
import { cn } from "@/lib/utils";
import { DriversAdmin } from "@/components/drivers-admin";
import { AdminsAdmin } from "@/components/admins-admin";
import { NotificationsAdmin } from "@/components/notifications-admin";
import { SettingsAdmin } from "@/components/settings-admin";
import { ContentSettingsAdmin } from "@/components/content-settings-admin";
import { BackupAdmin } from "@/components/backup-admin";
import { FeedbackAdmin } from "@/components/feedback-admin";
import { SuburbanAddressesAdmin } from "@/components/suburban-addresses-admin";
import { PopularPlacesAdmin } from "@/components/popular-places-admin";
import { StatisticsAdmin } from "@/components/statistics-admin";

const LOGIN_KEY = "taxi_admin_login";

const statusMeta: Record<OrderStatus, { label: string; dot: string }> = {
  [OrderStatus.WAITING]: { label: "Ожидает водителя", dot: "bg-amber-500" },
  [OrderStatus.ASSIGNED]: { label: "Взят в работу", dot: "bg-orange-500" },
  [OrderStatus.IN_PROGRESS]: { label: "В пути", dot: "bg-amber-600" },
  [OrderStatus.COMPLETED]: { label: "Выполнен", dot: "bg-emerald-500" },
  [OrderStatus.CANCELLED]: { label: "Отменён", dot: "bg-muted-foreground" },
};

function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AdminPanel() {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [section, setSection] = useState<
    | "orders"
    | "calls"
    | "drivers"
    | "access"
    | "notifications"
    | "settings"
    | "backup"
    | "feedback"
    | "statistics"
  >("orders");
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<CallReview[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | OrderStatus>("all");
  const [search, setSearch] = useState("");
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [creds, setCreds] = useState({
    login: "",
    currentPassword: "",
    password: "",
  });
  const [savingCreds, setSavingCreds] = useState(false);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const refresh = useCallback(async () => {
    setReviewsLoading(true);
    try {
      const [ordersRes, reviewsRes] = await Promise.all([
        fetch("/api/orders?all=true"),
        fetch("/api/call-reviews"),
      ]);
      if (ordersRes.ok) {
        const data: Order[] = await ordersRes.json();
        if (mounted.current) setOrders(data);
      }
      if (reviewsRes.ok) {
        const data: CallReview[] = await reviewsRes.json();
        if (mounted.current) setReviews(data);
      }
    } catch (error) {
      console.error("Ошибка загрузки истории заказов:", error);
    } finally {
      if (mounted.current) setReviewsLoading(false);
    }
  }, []);

  const restoreSession = useCallback(async () => {
    const storedLogin = localStorage.getItem(LOGIN_KEY);
    if (!storedLogin) {
      if (mounted.current) setLoading(false);
      return;
    }
    try {
      const res = await fetch("/api/admin/auth", {
        headers: { "x-admin-login": storedLogin },
      });
      if (res.ok) {
        const data = (await res.json()) as Admin;
        if (data.login === storedLogin || data.id === storedLogin) {
          setAdmin(data);
          setCreds({ login: data.login, currentPassword: "", password: "" });
          refresh();
        } else {
          localStorage.removeItem(LOGIN_KEY);
        }
      }
    } catch (error) {
      console.error("Ошибка восстановления сессии администратора:", error);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, [refresh]);

  useEffect(() => {
    restoreSession();
  }, [restoreSession]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!login.trim()) {
      toast.error("Введите логин");
      return;
    }
    if (!password) {
      toast.error("Введите пароль");
      return;
    }
    setAuthLoading(true);
    const id = toast.loading("Входим в панель...");
    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login: login.trim(), password }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось войти в панель", { id });
        return;
      }
      const found: Admin = data.admin;
      localStorage.setItem(LOGIN_KEY, found.login);
      setAdmin(found);
      setSection("orders");
      setOrders([]);
      setLogin("");
      setPassword("");
      setCreds({ login: found.login, currentPassword: "", password: "" });
      refresh();
      toast.success("Вы вошли в административную панель", { id });
    } catch (error) {
      console.error("Ошибка авторизации:", error);
      toast.error("Не удалось войти в панель", { id });
    } finally {
      setAuthLoading(false);
    }
  }

  function handleLogout() {
    localStorage.removeItem(LOGIN_KEY);
    setAdmin(null);
    setOrders([]);
    setLogin("");
    setPassword("");
    setCreds({ login: "", currentPassword: "", password: "" });
    toast.success("Вы вышли из панели");
  }

  async function handleSaveCredentials(e: React.FormEvent) {
    e.preventDefault();
    if (!admin) return;
    if (!creds.login.trim()) {
      toast.error("Укажите логин");
      return;
    }
    if (!creds.currentPassword) {
      toast.error("Введите текущий пароль для подтверждения");
      return;
    }
    if (creds.password && creds.password.length < 4) {
      toast.error("Пароль должен быть не короче 4 символов");
      return;
    }
    setSavingCreds(true);
    const id = toast.loading("Сохраняем изменения...");
    try {
      const res = await fetch("/api/admin/auth", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "x-admin-login": admin.login,
        },
        body: JSON.stringify({
          currentPassword: creds.currentPassword,
          login: creds.login.trim(),
          password: creds.password || undefined,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить изменения", { id });
        return;
      }
      const updated: Admin = data;
      localStorage.setItem(LOGIN_KEY, updated.login);
      setAdmin(updated);
      setCreds({ login: updated.login, currentPassword: "", password: "" });
      toast.success("Данные администратора сохранены", { id });
    } catch (error) {
      console.error("Ошибка сохранения данных:", error);
      toast.error("Не удалось сохранить изменения", { id });
    } finally {
      setSavingCreds(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64 rounded-xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }

  if (!admin) {
    return (
      <LoginForm
        login={login}
        password={password}
        onLogin={setLogin}
        onPassword={setPassword}
        onSubmit={handleLogin}
        busying={authLoading}
      />
    );
  }

  const adminRole = admin.role ?? AdminRole.ADMIN;
  const isDeveloper = adminRole === AdminRole.DEVELOPER;
  const isAdmin = adminRole === AdminRole.ADMIN;
  // Разработчик и администратор видят все разделы. Редактор видит заказы,
  // звонки, водителей и запросы.
  const canAccessAccess = isDeveloper || isAdmin;
  const canAccessNotifications = isDeveloper || isAdmin;
  const canAccessSettings = isDeveloper || isAdmin;
  const canAccessBackup = isDeveloper || isAdmin;
  // Статистика доступна только разработчику и администратору.
  const canAccessStatistics = isDeveloper || isAdmin;
  // Действия над заказами (отмена, снятие с водителя): разработчик и
  // администратор. Удаление и очистка заказов — только разработчик.
  const canManageOrders = isDeveloper || isAdmin;
  const canDeleteOrders = isDeveloper;

  async function runOrderAction(
    action: "cancel" | "release" | "delete",
    order: Order
  ) {
    if (!admin) return;
    const id = toast.loading("Выполняем действие...");
    try {
      const res = await fetch(
        `/api/admin/orders/${encodeURIComponent(order.id)}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-admin-login": admin.login,
          },
          body: JSON.stringify({ action }),
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось выполнить действие", { id });
        return;
      }
      if (action === "delete") {
        toast.success("Заказ удалён", { id });
        setOrders((prev) => prev.filter((o) => o.id !== order.id));
        return;
      }
      if (action === "cancel") {
        toast.success("Заказ отменён", { id });
      } else {
        toast.success("Заказ снят с водителя", { id });
      }
      const updated = data as Order | null;
      if (updated && updated.id === order.id) {
        setOrders((prev) =>
          prev.map((o) => (o.id === order.id ? { ...o, ...updated } : o))
        );
      } else {
        setOrders((prev) => prev.filter((o) => o.id !== order.id));
      }
    } catch (error) {
      console.error("Ошибка действия над заказом:", error);
      toast.error("Не удалось выполнить действие", { id });
    }
  }

  async function runClearOrders(ids: string[]) {
    if (!admin) return;
    const id = toast.loading("Очищаем заказы...");
    try {
      const res = await fetch("/api/admin/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-login": admin.login,
        },
        body: JSON.stringify({ ids }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось очистить заказы", { id });
        return;
      }
      toast.success(`Удалено заказов: ${data?.affected ?? 0}`, { id });
      setOrders([]);
    } catch (error) {
      console.error("Ошибка очистки заказов:", error);
      toast.error("Не удалось очистить заказы", { id });
    }
  }

  function confirmClearOrders() {
    if (filtered.length === 0) {
      toast.error("Нет заказов для очистки");
      return;
    }
    toast(`Очистить заказы (${filtered.length})?`, {
      description:
        "Заказы на этой вкладке будут полностью удалены из базы. Действие необратимо.",
      action: {
        label: "Очистить",
        onClick: () => runClearOrders(filtered.map((order) => order.id)),
      },
      cancel: {
        label: "Назад",
        onClick: () => {},
      },
    });
  }

  const filtered = orders
    .filter((o) => {
      if (filter !== "all" && o.status !== filter) return false;
      if (!search.trim()) return true;
      const q = search.trim().toLowerCase();
      return (
        o.from.toLowerCase().includes(q) ||
        o.to.toLowerCase().includes(q) ||
        (o.clientName ?? "").toLowerCase().includes(q) ||
        (o.clientPhone ?? "").toLowerCase().includes(q) ||
        o.id.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => (b.createdAt ?? "").localeCompare(a.createdAt ?? ""));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <ShieldCheck className="size-5" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">
                Административная панель
              </h1>
              <p className="text-muted-foreground flex items-center gap-2">
                Полная история заказов и управление водителями.
                <Badge
                  variant="outline"
                  className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
                >
                  <ShieldCheck className="size-3" />
                  {admin.role
                    ? (ADMIN_ROLE_LABELS[admin.role] ??
                      ADMIN_ROLE_LABELS[AdminRole.ADMIN])
                    : ADMIN_ROLE_LABELS[AdminRole.ADMIN]}
                </Badge>
              </p>
            </div>
          </div>
        </div>
        <Button variant="outline" className="gap-2" onClick={handleLogout}>
          <LogOut className="size-4" />
          Выйти
        </Button>
      </div>

      <Tabs
        value={section}
        onValueChange={(v) =>
          setSection(
            v as
              | "orders"
              | "calls"
              | "drivers"
              | "access"
              | "notifications"
              | "settings"
              | "backup"
              | "feedback"
              | "statistics"
          )
        }
      >
        <TabsList>
          <TabsTrigger value="orders" className="gap-1.5">
            <History className="size-4" />
            Заказы
          </TabsTrigger>
          <TabsTrigger value="calls" className="gap-1.5">
            <PhoneCall className="size-4" />
            Звонки
          </TabsTrigger>
          <TabsTrigger value="drivers" className="gap-1.5">
            <Users className="size-4" />
            Водители
          </TabsTrigger>
          {canAccessAccess && (
            <TabsTrigger value="access" className="gap-1.5">
              <ShieldCheck className="size-4" />
              Доступ
            </TabsTrigger>
          )}
          {canAccessNotifications && (
            <TabsTrigger value="notifications" className="gap-1.5">
              <Bell className="size-4" />
              Уведомления
            </TabsTrigger>
          )}
          {canAccessStatistics && (
            <TabsTrigger value="statistics" className="gap-1.5">
              <BarChart3 className="size-4" />
              Статистика
            </TabsTrigger>
          )}
          {canAccessSettings && (
            <TabsTrigger value="settings" className="gap-1.5">
              <Settings className="size-4" />
              Настройки
            </TabsTrigger>
          )}
          <TabsTrigger value="feedback" className="gap-1.5">
            <Inbox className="size-4" />
            Запросы
          </TabsTrigger>
          {canAccessBackup && (
            <TabsTrigger value="backup" className="gap-1.5">
              <DatabaseBackup className="size-4" />
              Бэкап
            </TabsTrigger>
          )}
        </TabsList>
      </Tabs>

      {section === "orders" ? (
        <>
          <Card>
            <CardContent className="space-y-4 p-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <Tabs
                  value={filter}
                  onValueChange={(v) => setFilter(v as "all" | OrderStatus)}
                >
                  <TabsList>
                    <TabsTrigger value="all">Все</TabsTrigger>
                    <TabsTrigger value={OrderStatus.WAITING}>
                      Ожидают
                    </TabsTrigger>
                    <TabsTrigger value={OrderStatus.ASSIGNED}>
                      В работе
                    </TabsTrigger>
                    <TabsTrigger value={OrderStatus.IN_PROGRESS}>
                      В пути
                    </TabsTrigger>
                    <TabsTrigger value={OrderStatus.COMPLETED}>
                      Выполнены
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="gap-1.5">
                    <History className="size-3.5" />
                    Всего: {orders.length}
                  </Badge>
                  {canDeleteOrders && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={confirmClearOrders}
                    >
                      <Trash2 className="size-4" />
                      Очистить заказы
                    </Button>
                  )}
                </div>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Поиск по адресу, клиенту или номеру заказа"
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {filtered.length > 0 ? (
            <div className="grid gap-3">
              {filtered.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  canManage={canManageOrders}
                  canDelete={canDeleteOrders}
                  onAction={runOrderAction}
                />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={History}
              title="История пуста"
              description="Здесь появятся все оформленные заказы."
            />
          )}
        </>
      ) : section === "calls" ? (
        <CallReviews reviews={reviews} loading={reviewsLoading} />
      ) : section === "drivers" ? (
        <DriversAdmin role={adminRole} currentLogin={admin.login} />
      ) : section === "access" ? (
        canAccessAccess ? (
          <AdminsAdmin currentLogin={admin.login} role={adminRole} />
        ) : (
          <AccessDenied />
        )
      ) : section === "notifications" ? (
        canAccessNotifications ? (
          <NotificationsAdmin />
        ) : (
          <AccessDenied />
        )
      ) : section === "feedback" ? (
        <FeedbackAdmin />
      ) : section === "statistics" ? (
        canAccessStatistics ? (
          <StatisticsAdmin currentLogin={admin.login} />
        ) : (
          <AccessDenied />
        )
      ) : section === "backup" ? (
        canAccessBackup ? (
          <BackupAdmin />
        ) : (
          <AccessDenied />
        )
      ) : canAccessSettings ? (
        <>
          <SettingsAdmin />

          <SuburbanAddressesAdmin />

          <PopularPlacesAdmin />

          <ContentSettingsAdmin />

          <Card>
            <CardContent className="space-y-5 p-6">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Pencil className="size-5" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold">
                    Данные администратора
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    Измените логин и пароль для входа в панель.
                  </p>
                </div>
              </div>

              <form onSubmit={handleSaveCredentials} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="admin-login">
                    <span className="inline-flex items-center gap-1.5">
                      <UserRound className="size-4 text-primary" />
                      Логин
                    </span>
                  </Label>
                  <Input
                    id="admin-login"
                    placeholder="admin"
                    value={creds.login}
                    onChange={(e) =>
                      setCreds({ ...creds, login: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="admin-current-password">
                    <span className="inline-flex items-center gap-1.5">
                      <KeyRound className="size-4 text-primary" />
                      Текущий пароль (для подтверждения)
                    </span>
                  </Label>
                  <Input
                    id="admin-current-password"
                    type="password"
                    placeholder="••••••"
                    value={creds.currentPassword}
                    onChange={(e) =>
                      setCreds({ ...creds, currentPassword: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="admin-new-password">Новый пароль</Label>
                  <Input
                    id="admin-new-password"
                    type="password"
                    placeholder="Оставьте пустым, если не меняете"
                    value={creds.password}
                    onChange={(e) =>
                      setCreds({ ...creds, password: e.target.value })
                    }
                  />
                </div>

                <Button type="submit" className="gap-2" disabled={savingCreds}>
                  <Pencil className="size-4" />
                  {savingCreds ? "Сохраняем..." : "Сохранить изменения"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </>
      ) : (
        <AccessDenied />
      )}
    </div>
  );
}

function LoginForm({
  login: loginValue,
  password: passwordValue,
  onLogin,
  onPassword,
  onSubmit,
  busying,
}: {
  login: string;
  password: string;
  onLogin: (v: string) => void;
  onPassword: (v: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  busying: boolean;
}) {
  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold tracking-tight">
          Административная панель
        </h1>
        <p className="text-muted-foreground">
          Вход в панель доступен только авторизованному администратору.
        </p>
      </div>

      <Card className="mx-auto max-w-md">
        <CardContent className="space-y-4 p-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <ShieldCheck className="size-5" />
            </div>
            <div>
              <p className="font-semibold">Авторизация администратора</p>
              <p className="text-xs text-muted-foreground">
                Введите логин и пароль для входа в панель
              </p>
            </div>
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="admin-auth-login">
                <span className="inline-flex items-center gap-1.5">
                  <UserRound className="size-4 text-primary" />
                  Логин
                </span>
              </Label>
              <Input
                id="admin-auth-login"
                placeholder="admin"
                value={loginValue}
                onChange={(e) => onLogin(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-auth-password">
                <span className="inline-flex items-center gap-1.5">
                  <KeyRound className="size-4 text-primary" />
                  Пароль
                </span>
              </Label>
              <Input
                id="admin-auth-password"
                type="password"
                placeholder="••••••"
                value={passwordValue}
                onChange={(e) => onPassword(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full gap-2" disabled={busying}>
              <ShieldCheck className="size-4" />
              {busying ? "Входим..." : "Войти в панель"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function CallReviews({
  reviews,
  loading,
}: {
  reviews: CallReview[];
  loading: boolean;
}) {
  return (
    <section className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <MessageSquare className="size-5" />
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-semibold">Отзывы</h2>
          <p className="text-xs text-muted-foreground">
            Ответы клиентов на вопрос «Вы договорились с водителем?».
          </p>
        </div>
        <Badge variant="outline">{reviews.length}</Badge>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[0, 1].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      ) : reviews.length > 0 ? (
        <div className="grid gap-3">
          {reviews.map((review) => (
            <Card key={review.id} size="sm">
              <CardContent className="space-y-3 p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-destructive/30 bg-destructive/10 text-destructive"
                  >
                    <MessageSquare className="size-3" />
                    Не договорились
                  </Badge>
                  {review.orderId && (
                    <span className="text-xs text-muted-foreground">
                      Заказ №{formatOrderNumber(review.orderId)}
                    </span>
                  )}
                </div>

                <p className="whitespace-pre-line text-sm">{review.review}</p>

                <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <User className="size-3.5" />
                    {review.clientName ?? "Клиент"}
                  </span>
                  {review.clientPhone && (
                    <span className="inline-flex items-center gap-1.5">
                      <Phone className="size-3.5" />
                      {review.clientPhone}
                    </span>
                  )}
                  {review.driverName && (
                    <span className="inline-flex items-center gap-1.5">
                      <CarFront className="size-3.5" />
                      {review.driverName}
                    </span>
                  )}
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="size-3.5" />
                    {formatDateTime(review.createdAt)}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={MessageSquare}
          title="Отзывов пока нет"
          description="Здесь появятся ответы клиентов, которым не удалось вызвать машину по телефону."
        />
      )}
    </section>
  );
}

function OrderCard({
  order,
  canManage,
  canDelete,
  onAction,
}: {
  order: Order;
  canManage: boolean;
  canDelete: boolean;
  onAction: (action: "cancel" | "release" | "delete", order: Order) => void;
}) {
  const meta = statusMeta[order.status];
  const hasDriver = Boolean(order.driverId || order.driverName);
  const isTerminal = order.status === OrderStatus.COMPLETED;
  const isWaiting = order.status === OrderStatus.WAITING;

  function confirmAction(action: "cancel" | "release" | "delete") {
    if (action === "cancel") {
      toast("Отменить заказ?", {
        description: `Заказ №${formatOrderNumber(
          order.id
        )} получит статус «Отменён».`,
        action: {
          label: "Отменить",
          onClick: () => onAction("cancel", order),
        },
        cancel: {
          label: "Назад",
          onClick: () => {},
        },
      });
      return;
    }
    if (action === "release") {
      toast("Снять заказ с водителя?", {
        description: `Водитель будет освобождён, заказ №${formatOrderNumber(
          order.id
        )} вернётся в очередь.`,
        action: {
          label: "Снять",
          onClick: () => onAction("release", order),
        },
        cancel: {
          label: "Назад",
          onClick: () => {},
        },
      });
      return;
    }
    toast("Удалить заказ?", {
      description: `Заказ №${formatOrderNumber(
        order.id
      )} будет полностью удалён из базы. Действие необратимо.`,
      action: {
        label: "Удалить",
        onClick: () => onAction("delete", order),
      },
      cancel: {
        label: "Назад",
        onClick: () => {},
      },
    });
  }

  return (
    <Card size="sm">
      <CardContent className="flex flex-col gap-4 p-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="gap-1.5">
              <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
              {meta.label}
            </Badge>
            {order.phoneCall && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
              >
                <Phone className="size-3" />
                По звонку
              </Badge>
            )}
            {order.childSeat && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
              >
                <Baby className="size-3" />
                Детское кресло
              </Badge>
            )}
            {order.delivery && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
              >
                <Package className="size-3" />
                Доставка +350₽
              </Badge>
            )}
            {order.trunk && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
              >
                <BaggageClaim className="size-3" />
                Багажник +50₽
              </Badge>
            )}
            {order.paymentMethod === "cash" && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
              >
                <Banknote className="size-3" />
                Наличными
                {order.cashChangeFrom != null && (
                  <span className="font-semibold">
                    · с {order.cashChangeFrom}₽
                  </span>
                )}
              </Badge>
            )}
            {order.paymentMethod === "card" && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
              >
                <Banknote className="size-3" />
                Перевод
              </Badge>
            )}
            {order.suburbanPrice && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
              >
                <MapPin className="size-3" />
                {order.suburbanPrice.name} ·{" "}
                {order.suburbanPrice.direction === "from" ? "забрать" : "везти"}{" "}
                {order.suburbanPrice.price}₽
              </Badge>
            )}
            {order.popularPlacePrice && (
              <Badge
                variant="outline"
                className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
              >
                <MapPin className="size-3" />
                {order.popularPlacePrice.name} · {order.popularPlacePrice.price}
                ₽
              </Badge>
            )}
            {order.confirmResult && (
              <Badge
                variant="outline"
                className={cn(
                  "gap-1.5",
                  order.confirmResult === CallResult.PICKED_UP
                    ? "border-emerald-200 bg-emerald-500/10 text-emerald-700"
                    : "border-destructive/30 bg-destructive/10 text-destructive"
                )}
              >
                {order.confirmResult === CallResult.PICKED_UP ? (
                  <CheckCircle2 className="size-3" />
                ) : (
                  <CircleOff className="size-3" />
                )}
                {order.confirmResult === CallResult.PICKED_UP
                  ? "Увез"
                  : "Отказ"}
              </Badge>
            )}
            <span className="truncate text-xs text-muted-foreground">
              Заказ №{formatOrderNumber(order.id)}
            </span>
          </div>

          <RouteLine
            from={order.from}
            to={order.to}
            fromEntrance={order.fromEntrance}
            toEntrance={order.toEntrance}
            stops={order.stops}
          />

          {order.comment && (
            <div className="rounded-lg border bg-amber-500/10 px-3 py-2 text-xs">
              <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                <MessageSquare className="size-3.5" />
                Комментарий водителю
              </span>
              <p className="mt-0.5">{order.comment}</p>
            </div>
          )}

          <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <User className="size-3.5" />
              {order.clientName ?? "Клиент"}
            </span>
            {order.clientPhone && (
              <span className="inline-flex items-center gap-1.5">
                <Phone className="size-3.5" />
                {order.clientPhone}
              </span>
            )}
            <span className="inline-flex items-center gap-1.5">
              <Clock className="size-3.5" />
              {formatDateTime(order.createdAt)}
            </span>
          </div>

          {(order.driver || order.driverName) && (
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-lg border bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5 font-medium text-foreground">
                <CarFront className="size-3.5 text-primary" />
                {order.driver?.name ?? order.driverName}
              </span>
              {order.driver &&
                (order.driver.carMake || order.driver.carNumber) && (
                  <span className="inline-flex items-center gap-1.5">
                    <MapPin className="size-3.5" />
                    {[order.driver.carMake, order.driver.carNumber]
                      .filter(Boolean)
                      .join(", ")}
                  </span>
                )}
              {order.driver?.phone && (
                <span className="inline-flex items-center gap-1.5">
                  <Phone className="size-3.5" />
                  {order.driver.phone}
                </span>
              )}
              {order.assignedCarMake && (
                <span className="inline-flex items-center gap-1.5">
                  <CarFront className="size-3.5 text-primary" />
                  {[order.assignedCarMake, order.assignedCarNumber]
                    .filter(Boolean)
                    .join(", гос.номер ")}
                </span>
              )}
            </div>
          )}

          {canManage && !isTerminal && (
            <div className="flex flex-wrap items-center gap-2 border-t pt-3">
              {!isWaiting && hasDriver && (
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5"
                  onClick={() => confirmAction("release")}
                >
                  <Undo2 className="size-3.5" />
                  Снять с водителя
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => confirmAction("cancel")}
              >
                <XCircle className="size-3.5" />
                Отменить
              </Button>
              {canDelete && (
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={() => confirmAction("delete")}
                >
                  <Trash2 className="size-3.5" />
                  Удалить
                </Button>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function RouteLine({
  from,
  to,
  fromEntrance,
  toEntrance,
  stops,
}: {
  from: string;
  to: string;
  fromEntrance?: string;
  toEntrance?: string;
  stops?: OrderStop[];
}) {
  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 flex flex-col items-center gap-1">
        <span className="h-2 w-2 rounded-full bg-emerald-500" />
        {stops?.map((_, i) => (
          <span key={i} className="h-2 w-2 rounded-full bg-primary/70" />
        ))}
        <span className="h-3 w-0.5 border-l border-dashed border-muted-foreground/50" />
        <span className="h-2 w-2 rounded-full bg-destructive" />
      </div>
      <div className="space-y-1.5">
        <p className="flex items-center gap-1.5 text-sm font-semibold leading-tight">
          <MapPin className="size-3.5 text-emerald-500" />
          {addressWithEntrance(from, fromEntrance)}
        </p>
        {stops?.map((stop, i) => (
          <p
            key={i}
            className="flex items-center gap-1.5 text-sm font-semibold leading-tight text-muted-foreground"
          >
            <MapPin className="size-3.5 text-primary/60" />
            {addressWithEntrance(stop.address, stop.entrance)}
          </p>
        ))}
        <p className="flex items-center gap-1.5 text-sm font-semibold leading-tight">
          <MapPin className="size-3.5 text-destructive" />
          {addressWithEntrance(to, toEntrance)}
        </p>
      </div>
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Icon className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

function AccessDenied() {
  return (
    <EmptyState
      icon={ShieldCheck}
      title="Раздел недоступен"
      description="Ваша роль не имеет доступа к этому разделу админ-панели."
    />
  );
}
