"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Baby,
  BaggageClaim,
  Banknote,
  CarFront,
  ClipboardList,
  Clock,
  KeyRound,
  LogOut,
  MapPin,
  MessageSquare,
  Navigation,
  Package,
  Phone,
  ShieldCheck,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Driver,
  Order,
  OrderStatus,
  OrderStop,
  formatOrderNumber,
} from "@/lib/models";
import { addressWithEntrance } from "@/lib/address";
import { cn } from "@/lib/utils";

const PHONE_KEY = "taxi_driver_phone";

const statusMeta: Record<OrderStatus, { label: string; dot: string }> = {
  [OrderStatus.WAITING]: { label: "Ожидает водителя", dot: "bg-amber-500" },
  [OrderStatus.ASSIGNED]: { label: "Взят в работу", dot: "bg-orange-500" },
  [OrderStatus.IN_PROGRESS]: { label: "В пути", dot: "bg-amber-600" },
  [OrderStatus.COMPLETED]: { label: "Выполнен", dot: "bg-emerald-500" },
  [OrderStatus.CANCELLED]: { label: "Отменён", dot: "bg-muted-foreground" },
};

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDateTime(iso: string): string {
  const date = new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "short",
  });
  return `${date}, ${formatTime(iso)}`;
}

export function DriverPanel() {
  const [driver, setDriver] = useState<Driver | null>(null);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [available, setAvailable] = useState<Order[]>([]);
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [authLoading, setAuthLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const refreshAvailable = useCallback(async () => {
    try {
      const res = await fetch("/api/orders");
      if (res.ok) {
        const data: Order[] = await res.json();
        if (mounted.current) setAvailable(data);
      }
    } catch (error) {
      console.error("Ошибка загрузки доступных заказов:", error);
    }
  }, []);

  const refreshMy = useCallback(async (name: string) => {
    if (!name) {
      if (mounted.current) setMyOrders([]);
      return;
    }
    try {
      const res = await fetch(`/api/orders?driver=${encodeURIComponent(name)}`);
      if (res.ok) {
        const data: Order[] = await res.json();
        if (mounted.current) setMyOrders(data);
      }
    } catch (error) {
      console.error("Ошибка загрузки заказов водителя:", error);
    }
  }, []);

  const restoreSession = useCallback(async () => {
    const storedPhone = localStorage.getItem(PHONE_KEY);
    if (!storedPhone) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch("/api/drivers");
      if (res.ok) {
        const list = (await res.json()) as Driver[];
        const found = list.find((d) => d.phone === storedPhone);
        if (found) {
          if (found.isBlocked) {
            localStorage.removeItem(PHONE_KEY);
            toast.error("Водитель заблокирован. Обратитесь к администратору.");
          } else {
            setDriver(found);
            setPhone(found.phone);
            refreshAvailable();
            refreshMy(found.name);
          }
        } else {
          localStorage.removeItem(PHONE_KEY);
        }
      }
    } catch (error) {
      console.error("Ошибка восстановления сессии водителя:", error);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, [refreshAvailable, refreshMy]);

  useEffect(() => {
    restoreSession();
  }, [restoreSession]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!phone.trim()) {
      toast.error("Укажите номер телефона");
      return;
    }
    if (!password) {
      toast.error("Введите пароль");
      return;
    }
    setAuthLoading(true);
    const id = toast.loading("Входим в панель...");
    try {
      const res = await fetch("/api/drivers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.trim(), password }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось войти в панель", { id });
        return;
      }
      const found: Driver = data.driver;
      localStorage.setItem(PHONE_KEY, found.phone);
      setDriver(found);
      setAvailable([]);
      setMyOrders([]);
      refreshAvailable();
      refreshMy(found.name);
      toast.success("Вы вошли в панель водителя", { id });
    } catch (error) {
      console.error("Ошибка авторизации:", error);
      toast.error("Не удалось войти в панель", { id });
    } finally {
      setAuthLoading(false);
    }
  }

  function handleLogout() {
    localStorage.removeItem(PHONE_KEY);
    setDriver(null);
    setAvailable([]);
    setMyOrders([]);
    setPhone("");
    setPassword("");
    toast.success("Вы вышли из панели");
  }

  async function patchOrder(order: Order, status: OrderStatus) {
    setBusyId(order.id);
    const id = toast.loading("Обновляем статус...");
    try {
      const res = await fetch(`/api/orders/${order.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          driverName: driver?.name,
          driverId: driver?.id,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast.error(data?.error ?? "Не удалось обновить статус", { id });
        return;
      }
      toast.success("Статус обновлён", { id });
      await refreshAvailable();
      await refreshMy(driver?.name ?? "");
    } catch (error) {
      console.error("Ошибка обновления статуса:", error);
      toast.error("Не удалось обновить статус", { id });
    } finally {
      setBusyId(null);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64 rounded-xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }

  if (!driver) {
    return (
      <LoginForm
        phone={phone}
        password={password}
        onPhone={setPhone}
        onPassword={setPassword}
        onSubmit={handleLogin}
        busying={authLoading}
      />
    );
  }

  const availableSection =
    available.length > 0 ? (
      <div className="grid gap-3">
        {available.map((order) => (
          <Card key={order.id} size="sm">
            <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex min-w-0 items-start gap-3">
                <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600">
                  <ClipboardList className="size-4" />
                </div>
                <div className="min-w-0 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1">
                      <Badge variant="outline" className="gap-1.5 py-0">
                        <ClipboardList className="size-3.5" />№
                        {formatOrderNumber(order.id)}
                      </Badge>
                    </span>
                  </div>
                  <RouteLine
                    from={order.from}
                    to={order.to}
                    fromEntrance={order.fromEntrance}
                    toEntrance={order.toEntrance}
                    stops={order.stops}
                  />
                  {order.comment && (
                    <div className="flex items-start gap-1.5 text-xs text-amber-700">
                      <MessageSquare className="mt-0.5 size-3.5 shrink-0" />
                      <span className="min-w-0">
                        <span className="font-medium">
                          Комментарий водителю:
                        </span>{" "}
                        {order.comment}
                      </span>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    {order.clientName && (
                      <span className="inline-flex items-center gap-1">
                        <User className="size-3.5" /> {order.clientName}
                      </span>
                    )}
                    {order.clientPhone && (
                      <a
                        href={`tel:${order.clientPhone}`}
                        className="inline-flex items-center gap-1 underline-offset-2 hover:underline"
                      >
                        <Phone className="size-3.5" /> {order.clientPhone}
                      </a>
                    )}
                    {order.childSeat && (
                      <span className="inline-flex items-center gap-1 text-amber-700">
                        <Baby className="size-3.5" /> Детское кресло
                      </span>
                    )}
                    {order.delivery && (
                      <span className="inline-flex items-center gap-1 text-amber-700">
                        <Package className="size-3.5" /> Доставка +350₽
                      </span>
                    )}
                    {order.trunk && (
                      <span className="inline-flex items-center gap-1 text-amber-700">
                        <BaggageClaim className="size-3.5" /> Багажник +50₽
                      </span>
                    )}
                    {order.paymentMethod === "cash" && (
                      <span className="inline-flex items-center gap-1 text-amber-700">
                        <Banknote className="size-3.5" /> Наличными
                        {order.cashChangeFrom != null && (
                          <span className="font-semibold">
                            · с {order.cashChangeFrom}₽
                          </span>
                        )}
                      </span>
                    )}
                    {order.paymentMethod === "card" && (
                      <span className="inline-flex items-center gap-1 text-muted-foreground">
                        <Banknote className="size-3.5" /> Перевод
                      </span>
                    )}
                    {order.suburbanPrice && (
                      <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                        <MapPin className="size-3.5" />{" "}
                        {order.suburbanPrice.name} ·{" "}
                        {order.suburbanPrice.direction === "from"
                          ? "забрать"
                          : "везти"}{" "}
                        {order.suburbanPrice.price}₽
                      </span>
                    )}
                    {order.popularPlacePrice && (
                      <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                        <MapPin className="size-3.5" />{" "}
                        {order.popularPlacePrice.name} ·{" "}
                        {order.popularPlacePrice.price}₽
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1">
                      <Clock className="size-3.5" />{" "}
                      {formatDateTime(order.createdAt)}
                    </span>
                  </div>
                </div>
              </div>
              <Button
                size="lg"
                className="h-12 w-full gap-2 text-base sm:h-10 sm:w-auto sm:text-sm"
                disabled={busyId === order.id}
                onClick={() => patchOrder(order, OrderStatus.ASSIGNED)}
              >
                <CarFront className="size-5 sm:size-4" />
                Взять в работу
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    ) : (
      <EmptyState
        icon={ClipboardList}
        title="Нет доступных заказов"
        description="Новые заказы появятся здесь сразу после оформления клиентом."
      />
    );

  const mySection =
    myOrders.length > 0 ? (
      <div className="grid gap-3">
        {myOrders.map((order) => (
          <Card key={order.id} size="sm">
            <CardContent className="flex flex-col gap-3 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1">
                    <Badge variant="outline" className="gap-1.5 py-0">
                      <ClipboardList className="size-3.5" />№
                      {formatOrderNumber(order.id)}
                    </Badge>
                  </span>
                  <RouteLine
                    from={order.from}
                    to={order.to}
                    fromEntrance={order.fromEntrance}
                    toEntrance={order.toEntrance}
                    stops={order.stops}
                  />
                </div>
                <StatusBadge status={order.status} />
              </div>
              {order.comment && (
                <div className="flex items-start gap-1.5 text-xs text-amber-700">
                  <MessageSquare className="mt-0.5 size-3.5 shrink-0" />
                  <span className="min-w-0">
                    <span className="font-medium">Комментарий водителю:</span>{" "}
                    {order.comment}
                  </span>
                </div>
              )}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  {order.clientName && (
                    <span className="inline-flex items-center gap-1">
                      <User className="size-3.5" /> {order.clientName}
                    </span>
                  )}
                  {order.clientPhone && (
                    <a
                      href={`tel:${order.clientPhone}`}
                      className="inline-flex items-center gap-1 underline-offset-2 hover:underline"
                    >
                      <Phone className="size-3.5" /> {order.clientPhone}
                    </a>
                  )}
                  {order.childSeat && (
                    <span className="inline-flex items-center gap-1 text-amber-700">
                      <Baby className="size-3.5" /> Детское кресло
                    </span>
                  )}
                  {order.delivery && (
                    <span className="inline-flex items-center gap-1 text-amber-700">
                      <Package className="size-3.5" /> Доставка +350₽
                    </span>
                  )}
                  {order.trunk && (
                    <span className="inline-flex items-center gap-1 text-amber-700">
                      <BaggageClaim className="size-3.5" /> Багажник +50₽
                    </span>
                  )}
                  {order.paymentMethod === "cash" && (
                    <span className="inline-flex items-center gap-1 text-amber-700">
                      <Banknote className="size-3.5" /> Наличными
                      {order.cashChangeFrom != null && (
                        <span className="font-semibold">
                          · с {order.cashChangeFrom}₽
                        </span>
                      )}
                    </span>
                  )}
                  {order.paymentMethod === "card" && (
                    <span className="inline-flex items-center gap-1 text-muted-foreground">
                      <Banknote className="size-3.5" /> Перевод
                    </span>
                  )}
                  {order.suburbanPrice && (
                    <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                      <MapPin className="size-3.5" /> {order.suburbanPrice.name}{" "}
                      ·{" "}
                      {order.suburbanPrice.direction === "from"
                        ? "забрать"
                        : "везти"}{" "}
                      {order.suburbanPrice.price}₽
                    </span>
                  )}
                  {order.popularPlacePrice && (
                    <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                      <MapPin className="size-3.5" />{" "}
                      {order.popularPlacePrice.name} ·{" "}
                      {order.popularPlacePrice.price}₽
                    </span>
                  )}
                  <span className="inline-flex items-center gap-1">
                    <Clock className="size-3.5" />{" "}
                    {formatDateTime(order.createdAt)}
                  </span>
                </div>
                {order.status !== OrderStatus.COMPLETED &&
                  order.status !== OrderStatus.CANCELLED && (
                    <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
                      {order.status === OrderStatus.ASSIGNED && (
                        <Button
                          size="lg"
                          variant="outline"
                          className="h-12 w-full gap-2 text-base sm:h-10 sm:w-auto sm:text-sm"
                          disabled={busyId === order.id}
                          onClick={() =>
                            patchOrder(order, OrderStatus.IN_PROGRESS)
                          }
                        >
                          <Navigation className="size-5 sm:size-4" />В пути
                        </Button>
                      )}
                      <Button
                        size="lg"
                        className="h-12 w-full gap-2 text-base sm:h-10 sm:w-auto sm:text-sm"
                        disabled={busyId === order.id}
                        onClick={() => patchOrder(order, OrderStatus.COMPLETED)}
                      >
                        <MapPin className="size-5 sm:size-4" />
                        Отметить выполнен
                      </Button>
                    </div>
                  )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    ) : (
      <EmptyState
        icon={CarFront}
        title="Нет заказов в работе"
        description="Примите заказ из очереди, и он появится здесь для контроля статуса."
      />
    );

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight">Панель водителя</h1>
          <p className="text-muted-foreground">
            Очередь входящих заказов и управление их статусом.
          </p>
        </div>
        <Button
          variant="outline"
          className="h-12 gap-2 sm:h-10"
          onClick={handleLogout}
        >
          <LogOut className="size-5 sm:size-4" />
          Выйти
        </Button>
      </div>

      <Card>
        <CardContent className="flex flex-wrap items-center gap-3 p-5">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <User className="size-5" />
          </div>
          <div className="min-w-0 space-y-0.5">
            <p className="text-sm font-semibold">{driver.name}</p>
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Phone className="size-3.5" />
              {driver.phone}
            </p>
          </div>
          <Badge
            variant="outline"
            className={cn(
              "ml-auto gap-1.5",
              driver.isOnLine
                ? "border-emerald-200 bg-emerald-500/10 text-emerald-700"
                : "border-muted-foreground/30 text-muted-foreground"
            )}
          >
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full",
                driver.isOnLine ? "bg-emerald-500" : "bg-muted-foreground"
              )}
            />
            {driver.isOnLine ? "На линии" : "Не на линии"}
          </Badge>
        </CardContent>
      </Card>

      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Доступные заказы</h2>
          <Badge variant="outline">{available.length}</Badge>
        </div>
        {availableSection}
      </section>

      <Separator />

      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Мои заказы</h2>
          <Badge variant="outline">{myOrders.length}</Badge>
        </div>
        {mySection}
      </section>
    </div>
  );
}

function LoginForm({
  phone: phoneValue,
  password: passwordValue,
  onPhone,
  onPassword,
  onSubmit,
  busying,
}: {
  phone: string;
  password: string;
  onPhone: (v: string) => void;
  onPassword: (v: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  busying: boolean;
}) {
  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold tracking-tight">Панель водителя</h1>
        <p className="text-muted-foreground">
          Панель активных заказов доступна только авторизованному водителю.
        </p>
      </div>

      <Card className="mx-auto max-w-md">
        <CardContent className="space-y-4 p-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <ShieldCheck className="size-5" />
            </div>
            <div>
              <p className="font-semibold">Авторизация водителя</p>
              <p className="text-xs text-muted-foreground">
                Введите номер телефона и пароль для входа
              </p>
            </div>
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="panel-phone">
                <span className="inline-flex items-center gap-1.5">
                  <Phone className="size-4 text-primary" />
                  Телефон
                </span>
              </Label>
              <Input
                id="panel-phone"
                type="tel"
                placeholder="+7 900 000-00-00"
                className="h-12 text-base"
                value={phoneValue}
                onChange={(e) => onPhone(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="panel-password">
                <span className="inline-flex items-center gap-1.5">
                  <KeyRound className="size-4 text-primary" />
                  Пароль
                </span>
              </Label>
              <Input
                id="panel-password"
                type="password"
                placeholder="••••••"
                className="h-12 text-base"
                value={passwordValue}
                onChange={(e) => onPassword(e.target.value)}
              />
            </div>
            <Button
              type="submit"
              className="h-12 w-full gap-2 text-base"
              disabled={busying}
            >
              <ShieldCheck className="size-5" />
              {busying ? "Входим..." : "Войти в панель"}
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              Водителей добавляет администратор. Самостоятельная регистрация
              недоступна.
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const meta = statusMeta[status];
  return (
    <Badge variant="outline" className="gap-1.5">
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </Badge>
  );
}

function RouteLine({
  from,
  to,
  fromEntrance,
  toEntrance,
  stops,
}: {
  from: string;
  to: string;
  fromEntrance?: string;
  toEntrance?: string;
  stops?: OrderStop[];
}) {
  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 flex flex-col items-center gap-1">
        <span className="h-2 w-2 rounded-full bg-emerald-500" />
        {stops?.map((_, i) => (
          <span key={i} className="h-2 w-2 rounded-full bg-primary/70" />
        ))}
        <span className="h-3 w-0.5 border-l border-dashed border-muted-foreground/50" />
        <span className="h-2 w-2 rounded-full bg-destructive" />
      </div>
      <div className="space-y-1.5">
        <p className="text-sm font-semibold leading-tight">
          {addressWithEntrance(from, fromEntrance)}
        </p>
        {stops?.map((stop, i) => (
          <p
            key={i}
            className="text-sm font-medium leading-tight text-muted-foreground"
          >
            {addressWithEntrance(stop.address, stop.entrance)}
          </p>
        ))}
        <p className="text-sm font-semibold leading-tight">
          {addressWithEntrance(to, toEntrance)}
        </p>
      </div>
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Icon className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
