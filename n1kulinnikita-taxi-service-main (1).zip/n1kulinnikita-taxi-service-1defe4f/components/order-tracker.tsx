"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Baby,
  BaggageClaim,
  Ban,
  Banknote,
  CarFront,
  Clock,
  MapPin,
  MessageCircle,
  Package,
  Search,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Order,
  OrderStatus,
  carArrivalLabel,
  formatOrderNumber,
  normalizeOrderNumberInput,
} from "@/lib/models";
import { cn } from "@/lib/utils";
import { RouteCard } from "@/components/route-card";
import { OrderTimeline } from "@/components/order-timeline";
import { DriverCard } from "@/components/driver-card";
import { showBrowserNotification } from "@/lib/notifications";

const POLL_INTERVAL_MS = 5000;
const NO_DRIVER_TIMEOUT_MS = 7 * 60 * 1000;

const statusMeta: Record<OrderStatus, { label: string; dot: string }> = {
  [OrderStatus.WAITING]: { label: "Ожидает водителя", dot: "bg-amber-500" },
  [OrderStatus.ASSIGNED]: { label: "Водитель назначен", dot: "bg-orange-500" },
  [OrderStatus.IN_PROGRESS]: { label: "Водитель в пути", dot: "bg-amber-600" },
  [OrderStatus.COMPLETED]: {
    label: "Поездка выполнена",
    dot: "bg-emerald-500",
  },
  [OrderStatus.CANCELLED]: {
    label: "Заказ отменён",
    dot: "bg-muted-foreground",
  },
};

function formatDateTime(iso: string): string {
  const date = new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
  return date;
}

export function OrderTracker() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const activeId = normalizeOrderNumberInput(searchParams.get("id") ?? "");

  const [idInput, setIdInput] = useState(activeId);
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const driverNotifiedRef = useRef(false);
  const timeoutNotifiedRef = useRef(false);
  const driverWaitingNotifiedRef = useRef<string | null>(null);
  const completedNotifiedRef = useRef(false);

  useEffect(() => {
    if (!activeId) return;

    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | null = null;

    driverNotifiedRef.current = false;
    timeoutNotifiedRef.current = false;
    driverWaitingNotifiedRef.current = null;
    completedNotifiedRef.current = false;

    function handlePolledOrder(current: Order) {
      const arrived =
        (current.status === OrderStatus.ASSIGNED ||
          current.status === OrderStatus.IN_PROGRESS) &&
        (current.driver?.carMake || current.driver?.carNumber);
      if (arrived && !driverNotifiedRef.current) {
        driverNotifiedRef.current = true;
        const message = `К Вам приедет ${carArrivalLabel(current.driver)}`;
        toast.success(message);
        showBrowserNotification(message);
      }

      if (
        current.driverWaitingAt &&
        driverWaitingNotifiedRef.current !== current.driverWaitingAt
      ) {
        driverWaitingNotifiedRef.current = current.driverWaitingAt;
        toast.success("Водитель ожидает вас");
        showBrowserNotification("Водитель ожидает вас");
      }

      if (
        current.status === OrderStatus.COMPLETED &&
        !completedNotifiedRef.current
      ) {
        completedNotifiedRef.current = true;
        toast.success("Поездка выполнена");
        showBrowserNotification("Поездка выполнена");
      }

      const elapsed = Date.now() - new Date(current.createdAt).getTime();
      if (
        current.status === OrderStatus.WAITING &&
        !current.phoneCall &&
        !timeoutNotifiedRef.current &&
        elapsed >= NO_DRIVER_TIMEOUT_MS
      ) {
        timeoutNotifiedRef.current = true;
        const message =
          "К сожалению, на линии временно никого нет, попробуйте через чат ВКонтакте";
        toast.warning(message);
        showBrowserNotification(message);
      }
    }

    async function run() {
      setLoading(true);
      setNotFound(false);
      try {
        const res = await fetch(`/api/orders/${encodeURIComponent(activeId)}`);
        if (cancelled) return;
        if (res.status === 404) {
          setOrder(null);
          setNotFound(true);
          setLoading(false);
          return;
        }
        if (!res.ok) {
          setLoading(false);
          toast.error("Не удалось загрузить статус заказа");
          return;
        }
        const data: Order = await res.json();
        if (cancelled) return;
        handlePolledOrder(data);
        setOrder(data);
        setLoading(false);

        if (data.status !== OrderStatus.COMPLETED) {
          timer = setInterval(() => {
            fetch(`/api/orders/${encodeURIComponent(activeId)}`)
              .then((r) => (r.ok ? r.json() : null))
              .then((next: Order | null) => {
                if (!next || cancelled) return;
                handlePolledOrder(next);
                setOrder(next);
                if (
                  (next.status === OrderStatus.COMPLETED ||
                    next.status === OrderStatus.CANCELLED) &&
                  timer
                ) {
                  clearInterval(timer);
                  timer = null;
                }
              })
              .catch(() => {});
          }, POLL_INTERVAL_MS);
        }
      } catch {
        if (!cancelled) {
          setLoading(false);
          toast.error("Не удалось загрузить статус заказа");
        }
      }
    }

    run();

    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
    };
  }, [activeId]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const id = normalizeOrderNumberInput(idInput);
    if (!id) {
      toast.error("Введите номер заказа");
      return;
    }
    router.push(`/track?id=${encodeURIComponent(id)}`, { scroll: false });
  }

  async function handleCancel() {
    if (!order) return;
    if (cancelling) return;
    setCancelling(true);
    const id = toast.loading("Отменяем заказ...");
    try {
      const res = await fetch(
        `/api/orders/${encodeURIComponent(order.id)}/cancel`,
        {
          method: "POST",
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось отменить заказ", { id });
        return;
      }
      toast.success("Заказ отменён", { id });
      setOrder(data as Order);
    } catch (error) {
      console.error("Ошибка отмены заказа:", error);
      toast.error("Не удалось отменить заказ", { id });
    } finally {
      setCancelling(false);
    }
  }

  const canCancel =
    !!order &&
    order.status !== OrderStatus.COMPLETED &&
    order.status !== OrderStatus.CANCELLED;

  const showLookup = !activeId && !order;

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <CarFront className="size-6" />
        </span>
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight">
            Отслеживание заказа
          </h1>
          <p className="text-muted-foreground">
            Введите номер заказа, чтобы видеть его актуальный статус.
          </p>
        </div>
      </div>

      {showLookup && (
        <Card className="card-hover rounded-2xl shadow-warm-sm">
          <CardContent className="p-6">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="order-id">
                  <span className="inline-flex items-center gap-1.5">
                    <Search className="size-4 text-primary" />
                    Номер заказа
                  </span>
                </Label>
                <Input
                  id="order-id"
                  placeholder="Например, 00001"
                  value={idInput}
                  onChange={(e) => setIdInput(e.target.value)}
                />
              </div>
              <Button
                type="submit"
                className="group/btn w-full gap-2 shadow-warm-sm"
              >
                <CarFront className="size-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
                Показать статус
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {activeId && (loading || !order) && !notFound && <TrackerSkeleton />}

      {notFound && (
        <Card className="rounded-2xl">
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <MapPin className="size-6" />
            </div>
            <div className="space-y-1 px-6">
              <p className="font-medium">Заказ не найден</p>
              <p className="text-sm text-muted-foreground">
                Проверьте номер заказа и попробуйте ещё раз.
              </p>
            </div>
            <Button
              variant="outline"
              className="gap-2"
              onClick={() => router.push("/track", { scroll: false })}
            >
              <Search className="size-4" />
              Ввести другой номер
            </Button>
          </CardContent>
        </Card>
      )}

      {order && (
        <Card className="card-hover rounded-2xl shadow-warm-sm">
          <CardContent className="space-y-6 p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <CarFront className="size-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Заказ</p>
                  <p className="font-mono font-semibold">
                    №{formatOrderNumber(order.id)}
                  </p>
                </div>
              </div>
              <StatusBadge status={order.status} />
            </div>

            {canCancel && (
              <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
                <p className="text-sm text-muted-foreground">
                  Передумали? Вы можете отменить заказ. Уведомление об отмене
                  придёт водителю.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  className="mt-3 w-full gap-2 border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive sm:w-auto"
                  disabled={cancelling}
                  onClick={handleCancel}
                >
                  <Ban className="size-4" />
                  {cancelling ? "Отменяем..." : "Отменить заказ"}
                </Button>
              </div>
            )}

            <OrderTimeline status={order.status} live />

            <div className="grid gap-3 sm:grid-cols-2">
              <RouteCard
                from={order.from}
                to={order.to}
                fromEntrance={order.fromEntrance}
                toEntrance={order.toEntrance}
                stops={order.stops}
              />
              <div className="flex flex-col gap-3">
                <InfoRow
                  icon={User}
                  label="Клиент"
                  value={order.clientName ?? "—"}
                />
                <InfoRow
                  icon={Clock}
                  label="Обновлено"
                  value={formatDateTime(order.updatedAt)}
                />
              </div>
            </div>

            {(order.childSeat ||
              order.delivery ||
              order.trunk ||
              order.paymentMethod ||
              order.suburbanPrice ||
              order.popularPlacePrice) && (
              <div className="flex flex-wrap gap-2">
                {order.suburbanPrice && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
                  >
                    <MapPin className="size-3" />
                    {order.suburbanPrice.name} ·{" "}
                    {order.suburbanPrice.direction === "from"
                      ? "забрать"
                      : "везти"}{" "}
                    {order.suburbanPrice.price}₽
                  </Badge>
                )}
                {order.popularPlacePrice && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
                  >
                    <MapPin className="size-3" />
                    {order.popularPlacePrice.name} ·{" "}
                    {order.popularPlacePrice.price}₽
                  </Badge>
                )}
                {order.childSeat && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
                  >
                    <Baby className="size-3" />
                    Детское кресло
                  </Badge>
                )}
                {order.delivery && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
                  >
                    <Package className="size-3" />
                    Доставка +350₽
                  </Badge>
                )}
                {order.trunk && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
                  >
                    <BaggageClaim className="size-3" />
                    Багажник +50₽
                  </Badge>
                )}
                {order.paymentMethod === "cash" && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
                  >
                    <Banknote className="size-3" />
                    Наличными
                    {order.cashChangeFrom != null && (
                      <span className="font-semibold">
                        · с {order.cashChangeFrom}₽
                      </span>
                    )}
                  </Badge>
                )}
                {order.paymentMethod === "card" && (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-amber-200 bg-amber-500/10 text-amber-700"
                  >
                    <Banknote className="size-3" />
                    Перевод
                  </Badge>
                )}
              </div>
            )}

            {order.comment && (
              <div className="rounded-xl border bg-amber-500/10 px-4 py-3 text-sm">
                <span className="flex items-center gap-1.5 font-medium text-amber-700">
                  <MessageCircle className="size-4" />
                  Комментарий водителю
                </span>
                <p className="mt-1 text-foreground">{order.comment}</p>
              </div>
            )}

            {(order.driver || order.driverName) && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                <DriverCard order={order} />
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const meta = statusMeta[status];
  return (
    <Badge
      key={status}
      variant="outline"
      className="animate-in fade-in zoom-in-95 duration-300 gap-1.5 border-primary/25 bg-primary/5 py-1"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </Badge>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border bg-muted/40 px-4 py-3 text-sm">
      <span className="inline-flex items-center gap-1.5 text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function TrackerSkeleton() {
  return (
    <Card className="rounded-2xl">
      <CardContent className="space-y-4 p-6">
        <div className="flex items-center justify-between gap-3">
          <Skeleton className="h-10 w-40 rounded-xl" />
          <Skeleton className="h-6 w-32 rounded-full" />
        </div>
        <Skeleton className="h-40 w-full rounded-xl" />
        <div className="grid gap-3 sm:grid-cols-2">
          <Skeleton className="h-28 w-full rounded-xl" />
          <Skeleton className="h-28 w-full rounded-xl" />
        </div>
      </CardContent>
    </Card>
  );
}
