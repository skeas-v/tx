"use client";

import { useEffect } from "react";
import {
  NOTIFICATION_CHECK_INTERVAL_MS,
  maybeRequestNotificationPermission,
} from "@/lib/notifications";

export function NotificationPermission() {
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      return;
    }

    const initial = window.setTimeout(() => {
      void maybeRequestNotificationPermission();
    }, 1000);

    const interval = window.setInterval(() => {
      void maybeRequestNotificationPermission();
    }, NOTIFICATION_CHECK_INTERVAL_MS);

    return () => {
      window.clearTimeout(initial);
      window.clearInterval(interval);
    };
  }, []);

  return null;
}
