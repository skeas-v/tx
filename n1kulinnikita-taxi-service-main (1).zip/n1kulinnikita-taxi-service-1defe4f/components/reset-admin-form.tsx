"use client";

import { useState } from "react";
import { KeyRound, Lock, LockOpen } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { resetAdminPasswordSchema } from "@/lib/validation/reset-admin";

export function ResetAdminForm({ urlKey }: { urlKey: string }) {
  const [key, setKey] = useState(urlKey ?? "");
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const parsed = resetAdminPasswordSchema.safeParse({
      key: key.trim(),
      password,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Некорректные данные");
      return;
    }
    if (password !== passwordConfirm) {
      toast.error("Пароли не совпадают");
      return;
    }

    setSaving(true);
    const id = toast.loading("Сбрасываем пароль...");
    try {
      const res = await fetch("/api/admin/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сбросить пароль", { id });
        return;
      }
      toast.success("Пароль сброшен", { id });
      setDone(true);
    } catch {
      toast.error("Не удалось сбросить пароль", { id });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/80 text-primary shadow-warm-sm ring-1 ring-primary/20 backdrop-blur">
          <KeyRound className="size-5" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Сброс пароля
          </h1>
          <p className="text-sm text-muted-foreground">
            Установите новый пароль для доступа в админ-панель.
          </p>
        </div>
      </div>

      <Card>
        <CardContent className="space-y-5 p-6">
          {done ? (
            <div className="space-y-3 py-6 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <LockOpen className="size-6" />
              </div>
              <p className="font-medium">Пароль сброшен</p>
              <p className="text-sm text-muted-foreground">
                Новый пароль сохранён. Теперь вы можете войти в админ-панель с
                новым паролем.
              </p>
              <Button
                variant="outline"
                className="gap-2"
                render={<a href="/admin" />}
              >
                <Lock className="size-4" />
                Перейти ко входу
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="reset-key">
                  <span className="inline-flex items-center gap-1.5">
                    <KeyRound className="size-4 text-primary" />
                    Ключ доступа
                  </span>
                </Label>
                <Input
                  id="reset-key"
                  type="password"
                  placeholder="Секретный ключ"
                  autoComplete="off"
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Ключ указан в ссылке, по которой открыта эта страница.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="reset-password">
                  <span className="inline-flex items-center gap-1.5">
                    <Lock className="size-4 text-primary" />
                    Новый пароль
                  </span>
                </Label>
                <Input
                  id="reset-password"
                  type="password"
                  placeholder="Минимум 4 символа"
                  autoComplete="new-password"
                  minLength={4}
                  maxLength={100}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="reset-password-confirm">
                  <span className="inline-flex items-center gap-1.5">
                    <Lock className="size-4 text-primary" />
                    Подтверждение пароля
                  </span>
                </Label>
                <Input
                  id="reset-password-confirm"
                  type="password"
                  placeholder="Повторите новый пароль"
                  autoComplete="new-password"
                  minLength={4}
                  maxLength={100}
                  value={passwordConfirm}
                  onChange={(e) => setPasswordConfirm(e.target.value)}
                />
              </div>

              <Button type="submit" className="w-full gap-2" disabled={saving}>
                {saving ? "Сбрасываем..." : "Сбросить пароль"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
