"use client";

import { useCallback, useEffect, useState } from "react";
import {
  AtSign,
  Ban,
  CarFront,
  Crown,
  KeyRound,
  Pencil,
  Phone,
  Plus,
  Trash2,
  User,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { AdminRole, Driver } from "@/lib/models";
import { adminDriverSchema } from "@/lib/validation/drivers";
import { cn } from "@/lib/utils";
import { CAR_COLORS } from "@/lib/car-colors";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface FormState {
  name: string;
  phone: string;
  vkId: string;
  carMake: string;
  carNumber: string;
  carColor: string;
  isOnLine: boolean;
  password: string;
}

const emptyForm: FormState = {
  name: "",
  phone: "",
  vkId: "",
  carMake: "",
  carNumber: "",
  carColor: "",
  isOnLine: false,
  password: "",
};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function DriversAdmin({
  role,
  currentLogin,
}: {
  role: AdminRole;
  currentLogin: string;
}) {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Driver | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [busyId, setBusyId] = useState<string | null>(null);

  const isDeveloper = role === AdminRole.DEVELOPER;
  const canManage = role === AdminRole.DEVELOPER || role === AdminRole.ADMIN;
  const canEditBlock = canManage || role === AdminRole.EDITOR;

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/drivers", {
        headers: { "x-admin-login": currentLogin },
      });
      if (res.ok) {
        setDrivers((await res.json()) as Driver[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки водителей:", error);
    } finally {
      setLoading(false);
    }
  }, [currentLogin]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  }

  function openEdit(driver: Driver) {
    setEditing(driver);
    setForm({
      name: driver.name,
      phone: driver.phone,
      vkId: driver.vkId ?? "",
      carMake: driver.carMake ?? "",
      carNumber: driver.carNumber ?? "",
      carColor: driver.carColor ?? "",
      isOnLine: driver.isOnLine,
      password: "",
    });
    setOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = adminDriverSchema.safeParse({
      name: form.name,
      phone: form.phone,
      vkId: form.vkId,
      carMake: form.carMake,
      carNumber: form.carNumber,
      carColor: form.carColor,
      isOnLine: form.isOnLine,
      password: form.password || undefined,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Проверьте правильность данных");
      return;
    }
    const payload = parsed.data;

    setSaving(true);
    const id = toast.loading(
      editing ? "Сохраняем изменения..." : "Добавляем водителя..."
    );
    try {
      const url = editing
        ? `/api/admin/drivers/${encodeURIComponent(editing.id)}`
        : "/api/admin/drivers";
      const res = await fetch(url, {
        method: editing ? "PATCH" : "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-login": currentLogin,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить водителя", { id });
        return;
      }
      toast.success(editing ? "Водитель обновлён" : "Водитель добавлен", {
        id,
      });
      setOpen(false);
      setForm(emptyForm);
      refresh();
    } catch (error) {
      console.error("Ошибка сохранения водителя:", error);
      toast.error("Не удалось сохранить водителя", { id });
    } finally {
      setSaving(false);
    }
  }

  const carLabel = (driver: Driver) =>
    [driver.carMake, driver.carNumber, driver.carColor]
      .filter(Boolean)
      .join(", ") || "Не указано";

  async function toggleBlocked(driver: Driver) {
    const target = !driver.isBlocked;
    setBusyId(driver.id);
    const id = toast.loading(
      target ? "Блокируем водителя..." : "Разблокируем водителя..."
    );
    try {
      const res = await fetch(
        `/api/admin/drivers/${encodeURIComponent(driver.id)}/block`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "x-admin-login": currentLogin,
          },
          body: JSON.stringify({ isBlocked: target }),
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось изменить блокировку", { id });
        return;
      }
      toast.success(
        target ? "Водитель заблокирован" : "Водитель разблокирован",
        {
          id,
        }
      );
      refresh();
    } catch (error) {
      console.error("Ошибка изменения блокировки:", error);
      toast.error("Не удалось изменить блокировку", { id });
    } finally {
      setBusyId(null);
    }
  }

  // Включение/выключение «премиум аккаунта» водителя. Доступно только
  // разработчику.
  async function togglePremium(driver: Driver) {
    const target = !driver.isPremium;
    setBusyId(driver.id);
    const id = toast.loading(
      target ? "Включаем премиум-аккаунт..." : "Выключаем премиум-аккаунт..."
    );
    try {
      const res = await fetch(
        `/api/admin/drivers/${encodeURIComponent(driver.id)}/premium`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "x-admin-login": currentLogin,
          },
          body: JSON.stringify({ isPremium: target }),
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось изменить премиум-аккаунт", {
          id,
        });
        return;
      }
      toast.success(
        target
          ? "Премиум-аккаунт включён: все заказы достаются этому водителю"
          : "Премиум-аккаунт выключен",
        { id }
      );
      refresh();
    } catch (error) {
      console.error("Ошибка изменения премиум-аккаунта:", error);
      toast.error("Не удалось изменить премиум-аккаунт", { id });
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(driver: Driver) {
    setBusyId(driver.id);
    const id = toast.loading("Удаляем водителя...");
    try {
      const res = await fetch(
        `/api/admin/drivers/${encodeURIComponent(driver.id)}`,
        {
          method: "DELETE",
          headers: { "x-admin-login": currentLogin },
        }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось удалить водителя", { id });
        return;
      }
      toast.success("Водитель удалён", { id });
      refresh();
    } catch (error) {
      console.error("Ошибка удаления водителя:", error);
      toast.error("Не удалось удалить водителя", { id });
    } finally {
      setBusyId(null);
    }
  }

  function confirmDelete(driver: Driver) {
    toast(`Удалить водителя ${driver.name}?`, {
      description: "Действие необратимо. Данные водителя будут удалены.",
      action: {
        label: "Удалить",
        onClick: () => handleDelete(driver),
      },
      cancel: {
        label: "Отмена",
        onClick: () => {},
      },
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Водители</h2>
          <Badge variant="outline">{drivers.length}</Badge>
        </div>
        {canManage && (
          <Button className="gap-2" onClick={openCreate}>
            <Plus className="size-4" />
            Добавить водителя
          </Button>
        )}
      </div>

      {loading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      ) : drivers.length > 0 ? (
        <div className="grid gap-3">
          {drivers.map((driver) => {
            const online = driver.isOnLine;
            return (
              <Card key={driver.id} size="sm">
                <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-start gap-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <User className="size-5" />
                    </div>
                    <div className="min-w-0 space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="truncate font-medium">{driver.name}</p>
                        {driver.isPremium && (
                          <Badge
                            variant="outline"
                            className="gap-1.5 border-amber-300 bg-amber-500/10 text-amber-700"
                          >
                            <Crown className="size-3" />
                            Премиум
                          </Badge>
                        )}
                        {driver.isBlocked && (
                          <Badge
                            variant="outline"
                            className="gap-1.5 border-destructive/30 bg-destructive/10 text-destructive"
                          >
                            <Ban className="size-3" />
                            Заблокирован
                          </Badge>
                        )}
                        <Badge
                          variant="outline"
                          className={cn(
                            "gap-1.5",
                            online
                              ? "border-emerald-200 bg-emerald-500/10 text-emerald-700"
                              : "border-muted-foreground/30 text-muted-foreground"
                          )}
                        >
                          <span
                            className={cn(
                              "h-1.5 w-1.5 rounded-full",
                              online ? "bg-emerald-500" : "bg-muted-foreground"
                            )}
                          />
                          {online ? "На линии" : "Не на линии"}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1.5">
                          <Phone className="size-3.5" />
                          {driver.phone}
                        </span>
                        <span className="inline-flex items-center gap-1.5">
                          <CarFront className="size-3.5" />
                          {carLabel(driver)}
                        </span>
                        {driver.vkId && (
                          <span className="inline-flex items-center gap-1.5">
                            <AtSign className="size-3.5" />
                            VK: {driver.vkId}
                          </span>
                        )}
                        <span>{formatDate(driver.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {isDeveloper && (
                      <Button
                        variant="outline"
                        size="sm"
                        className={cn(
                          "gap-2",
                          driver.isPremium
                            ? "border-amber-300 bg-amber-500/10 text-amber-700 hover:bg-amber-500/20 hover:text-amber-700"
                            : "border-amber-200/60 text-amber-700/70 hover:text-amber-700"
                        )}
                        disabled={busyId === driver.id}
                        onClick={() => togglePremium(driver)}
                      >
                        <Crown className="size-4" />
                        {driver.isPremium ? "Премиум: вкл" : "Премиум"}
                      </Button>
                    )}
                    {canEditBlock && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        disabled={busyId === driver.id}
                        onClick={() => toggleBlocked(driver)}
                      >
                        <Ban className="size-4" />
                        {driver.isBlocked ? "Разблокировать" : "Заблокировать"}
                      </Button>
                    )}
                    {canEditBlock && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        onClick={() => openEdit(driver)}
                      >
                        <Pencil className="size-4" />
                        Редактировать
                      </Button>
                    )}
                    {canManage && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                        disabled={busyId === driver.id}
                        onClick={() => confirmDelete(driver)}
                      >
                        <Trash2 className="size-4" />
                        Удалить
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <EmptyState
          title="Список водителей пуст"
          description="Добавьте первого водителя, чтобы он появился здесь."
        />
      )}

      <Dialog open={open} onOpenChange={(v) => setOpen(v)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editing ? "Редактировать водителя" : "Добавить водителя"}
            </DialogTitle>
            <DialogDescription>
              {editing
                ? "Измените данные водителя и сохраните изменения."
                : "Заполните данные нового водителя."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="admin-driver-name">Имя</Label>
              <Input
                id="admin-driver-name"
                placeholder="Иван Петров"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-driver-phone">Телефон</Label>
              <Input
                id="admin-driver-phone"
                type="tel"
                placeholder="+7 900 000-00-00"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-driver-vk-id">VK ID</Label>
              <Input
                id="admin-driver-vk-id"
                placeholder="123456789"
                value={form.vkId}
                onChange={(e) => setForm({ ...form, vkId: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Идентификатор пользователя ВКонтакте для управления статусом «на
                линии» через беседу.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="admin-driver-make">Марка автомобиля</Label>
                <Input
                  id="admin-driver-make"
                  placeholder="Toyota Camry"
                  value={form.carMake}
                  onChange={(e) =>
                    setForm({ ...form, carMake: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="admin-driver-number">Номер</Label>
                <Input
                  id="admin-driver-number"
                  placeholder="А123ВС77"
                  value={form.carNumber}
                  onChange={(e) =>
                    setForm({ ...form, carNumber: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="admin-driver-color">Цвет автомобиля</Label>
                <Select
                  items={CAR_COLORS.map((color) => ({
                    label: color,
                    value: color,
                  }))}
                  value={form.carColor || null}
                  onValueChange={(value) =>
                    setForm({ ...form, carColor: value ?? "" })
                  }
                >
                  <SelectTrigger
                    id="admin-driver-color"
                    className="h-10 w-full"
                  >
                    <SelectValue placeholder="Выберите цвет" />
                  </SelectTrigger>
                  <SelectContent className="w-full">
                    <SelectGroup>
                      {CAR_COLORS.map((color) => (
                        <SelectItem key={color} value={color}>
                          {color}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-driver-password">
                <span className="inline-flex items-center gap-1.5">
                  <KeyRound className="size-4 text-primary" />
                  Пароль (для входа водителя)
                </span>
              </Label>
              <Input
                id="admin-driver-password"
                type="password"
                placeholder="123456"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Если оставить пустым, будет установлен пароль по умолчанию.
              </p>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div className="space-y-0.5">
                <Label htmlFor="admin-driver-online">На линии</Label>
                <p className="text-xs text-muted-foreground">
                  Статус доступности водителя для заказов
                </p>
              </div>
              <Switch
                id="admin-driver-online"
                checked={form.isOnLine}
                onCheckedChange={(v) =>
                  setForm({ ...form, isOnLine: Boolean(v) })
                }
              />
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
              >
                Отмена
              </Button>
              <Button type="submit" className="gap-2" disabled={saving}>
                {editing ? (
                  <>
                    <Pencil className="size-4" />
                    {saving ? "Сохраняем..." : "Сохранить"}
                  </>
                ) : (
                  <>
                    <Plus className="size-4" />
                    {saving ? "Добавляем..." : "Добавить"}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EmptyState({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Users className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
