"use client";

import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const FULLSCREEN_PREFIXES = ["/order"];

export function isFullscreenRoute(pathname: string | null): boolean {
  return FULLSCREEN_PREFIXES.some(
    (prefix) => pathname === prefix || pathname?.startsWith(`${prefix}/`)
  );
}

/**
 * Условная обёртка для частей каркаса сайта (шапка/подвал). На
 * полноэкранных страницах заказа (/order, /order/call) шапка и подвал
 * скрываются, чтобы карта занимала весь экран — как в отдельном приложении.
 */
export function RouteChrome({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const hidden = isFullscreenRoute(pathname);
  return <div className={cn("contents", hidden && "hidden")}>{children}</div>;
}
