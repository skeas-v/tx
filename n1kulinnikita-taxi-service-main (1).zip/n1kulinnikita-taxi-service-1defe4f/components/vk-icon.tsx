export function VkIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14C20.67 22 22 20.67 22 15.07V8.93C22 3.33 20.67 2 15.07 2zM12.2 17c-4.28 0-6.72-2.94-6.82-7.83h2.14c.07 3.58 1.65 5.1 2.9 5.41V9.17h2.02v3.09c1.23-.13 2.53-1.54 2.97-3.09h2.02c-.34 1.92-1.75 3.33-2.75 3.91 1 .47 2.61 1.7 3.22 3.92H15.6c-.48-1.51-1.66-2.67-3.24-2.83V17H12.2z" />
    </svg>
  );
}
