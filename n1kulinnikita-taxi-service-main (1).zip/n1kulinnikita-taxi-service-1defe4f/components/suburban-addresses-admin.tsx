"use client";

import { useCallback, useEffect, useState } from "react";
import {
  CarFront,
  MapPin,
  Moon,
  Pencil,
  Plus,
  Sunrise,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SuburbanAddress } from "@/lib/models";
import { suburbanAddressSchema } from "@/lib/validation/suburban-addresses";

interface FormState {
  name: string;
  priceTo: string;
  priceFrom: string;
  peakEnabled: boolean;
  peakSurcharge: string;
  nightEnabled: boolean;
  nightSurcharge: string;
}

const emptyForm: FormState = {
  name: "",
  priceTo: "",
  priceFrom: "",
  peakEnabled: false,
  peakSurcharge: "",
  nightEnabled: false,
  nightSurcharge: "",
};

export function SuburbanAddressesAdmin() {
  const [addresses, setAddresses] = useState<SuburbanAddress[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<SuburbanAddress | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [busyId, setBusyId] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/suburban-addresses");
      if (res.ok) {
        setAddresses((await res.json()) as SuburbanAddress[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки пригородных адресов:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  }

  function openEdit(address: SuburbanAddress) {
    setEditing(address);
    setForm({
      name: address.name,
      priceTo: String(address.priceTo),
      priceFrom: String(address.priceFrom),
      peakEnabled: address.peakEnabled,
      peakSurcharge: String(address.peakSurcharge || ""),
      nightEnabled: address.nightEnabled,
      nightSurcharge: String(address.nightSurcharge || ""),
    });
    setOpen(true);
  }

  const toNumber = (value: string): number =>
    value.trim() === "" ? 0 : Number(value);

  function buildPayload() {
    return {
      name: form.name,
      priceTo: toNumber(form.priceTo),
      priceFrom: toNumber(form.priceFrom),
      peakEnabled: form.peakEnabled,
      peakSurcharge: form.peakEnabled ? toNumber(form.peakSurcharge) : 0,
      nightEnabled: form.nightEnabled,
      nightSurcharge: form.nightEnabled ? toNumber(form.nightSurcharge) : 0,
    };
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = suburbanAddressSchema.safeParse(buildPayload());
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Проверьте правильность данных");
      return;
    }
    const payload = parsed.data;

    if (payload.priceTo <= 0 && payload.priceFrom <= 0) {
      toast.error("Укажите хотя бы одну цену: «везти» или «забрать»");
      return;
    }

    setSaving(true);
    const id = toast.loading(
      editing ? "Сохраняем адрес..." : "Добавляем адрес..."
    );
    try {
      const url = editing
        ? `/api/admin/suburban-addresses/${encodeURIComponent(editing.id)}`
        : "/api/admin/suburban-addresses";
      const res = await fetch(url, {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить адрес", { id });
        return;
      }
      toast.success(editing ? "Адрес обновлён" : "Адрес добавлен", { id });
      setOpen(false);
      setForm(emptyForm);
      refresh();
    } catch (error) {
      console.error("Ошибка сохранения адреса:", error);
      toast.error("Не удалось сохранить адрес", { id });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(address: SuburbanAddress) {
    setBusyId(address.id);
    const id = toast.loading("Удаляем адрес...");
    try {
      const res = await fetch(
        `/api/admin/suburban-addresses/${encodeURIComponent(address.id)}`,
        { method: "DELETE" }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось удалить адрес", { id });
        return;
      }
      toast.success("Адрес удалён", { id });
      refresh();
    } catch (error) {
      console.error("Ошибка удаления адреса:", error);
      toast.error("Не удалось удалить адрес", { id });
    } finally {
      setBusyId(null);
    }
  }

  function confirmDelete(address: SuburbanAddress) {
    toast(`Удалить адрес «${address.name}»?`, {
      description: "Адрес перестанет использоваться при расчёте цены.",
      action: {
        label: "Удалить",
        onClick: () => handleDelete(address),
      },
      cancel: {
        label: "Отмена",
        onClick: () => {},
      },
    });
  }

  const surchargeLabel = (enabled: boolean, amount: number) =>
    enabled && amount > 0 ? `+${amount}₽` : null;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">
            Пригородные и загородные адреса
          </h2>
          <Badge variant="outline">{addresses.length}</Badge>
        </div>
        <Button className="gap-2" onClick={openCreate}>
          <Plus className="size-4" />
          Добавить адрес
        </Button>
      </div>

      {loading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      ) : addresses.length > 0 ? (
        <div className="grid gap-3">
          {addresses.map((address) => (
            <Card key={address.id} size="sm">
              <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex min-w-0 items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <MapPin className="size-5" />
                  </div>
                  <div className="min-w-0 space-y-1.5">
                    <p className="truncate font-medium">{address.name}</p>
                    <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1.5">
                        <CarFront className="size-3.5" />
                        Везти — {address.priceTo}₽
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <MapPin className="size-3.5" />
                        Забрать — {address.priceFrom}₽
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Sunrise className="size-3.5" />
                        Час пик:{" "}
                        {surchargeLabel(
                          address.peakEnabled,
                          address.peakSurcharge
                        ) ?? "выкл"}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Moon className="size-3.5" />
                        Ночь:{" "}
                        {surchargeLabel(
                          address.nightEnabled,
                          address.nightSurcharge
                        ) ?? "выкл"}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    onClick={() => openEdit(address)}
                  >
                    <Pencil className="size-4" />
                    Редактировать
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                    disabled={busyId === address.id}
                    onClick={() => confirmDelete(address)}
                  >
                    <Trash2 className="size-4" />
                    Удалить
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
            <MapPin className="size-6" />
          </div>
          <div className="space-y-1 px-6">
            <p className="font-medium">Список адресов пуст</p>
            <p className="text-sm text-muted-foreground">
              Добавьте пригородный или загородный адрес с ценой «везти» и
              «забрать».
            </p>
          </div>
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => setOpen(v)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editing ? "Редактировать адрес" : "Добавить адрес"}
            </DialogTitle>
            <DialogDescription>
              {editing
                ? "Измените параметры пригородного направления."
                : "Адрес будет использоваться при оформлении заказа для расчёта цены."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="suburban-name">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="size-4 text-primary" />
                  Название адреса
                </span>
              </Label>
              <Input
                id="suburban-name"
                placeholder="Например, 5-ое садоводство"
                value={form.name}
                maxLength={200}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Точное написание используется при сопоставлении с адресом
                клиента.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="suburban-price-to">
                  <span className="inline-flex items-center gap-1.5">
                    <CarFront className="size-4 text-primary" />
                    Цена «везти», ₽
                  </span>
                </Label>
                <Input
                  id="suburban-price-to"
                  inputMode="numeric"
                  type="number"
                  min={0}
                  placeholder="250"
                  value={form.priceTo}
                  onChange={(e) =>
                    setForm({ ...form, priceTo: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="suburban-price-from">
                  <span className="inline-flex items-center gap-1.5">
                    <MapPin className="size-4 text-primary" />
                    Цена «забрать», ₽
                  </span>
                </Label>
                <Input
                  id="suburban-price-from"
                  inputMode="numeric"
                  type="number"
                  min={0}
                  placeholder="350"
                  value={form.priceFrom}
                  onChange={(e) =>
                    setForm({ ...form, priceFrom: e.target.value })
                  }
                />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              «Везти» — поездка в это направление, «забрать» — из него в город.
            </p>

            <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label
                  htmlFor="suburban-peak-enabled"
                  className="inline-flex items-center gap-1.5"
                >
                  <Sunrise className="size-4 text-primary" />
                  Час пик
                </Label>
                <p className="text-xs text-muted-foreground">
                  06:00–09:00 и 16:00–18:00. При включении к цене прибавляется
                  сумма добавки.
                </p>
              </div>
              <Switch
                id="suburban-peak-enabled"
                checked={form.peakEnabled}
                onCheckedChange={(v) =>
                  setForm({ ...form, peakEnabled: Boolean(v) })
                }
              />
            </div>

            {form.peakEnabled && (
              <div className="space-y-1.5">
                <Label htmlFor="suburban-peak-surcharge">
                  <span className="inline-flex items-center gap-1.5">
                    <Sunrise className="size-4 text-primary" />
                    Добавка «час пик», ₽
                  </span>
                </Label>
                <Input
                  id="suburban-peak-surcharge"
                  inputMode="numeric"
                  type="number"
                  min={0}
                  placeholder="30"
                  value={form.peakSurcharge}
                  onChange={(e) =>
                    setForm({ ...form, peakSurcharge: e.target.value })
                  }
                />
              </div>
            )}

            <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label
                  htmlFor="suburban-night-enabled"
                  className="inline-flex items-center gap-1.5"
                >
                  <Moon className="size-4 text-primary" />
                  Ночь
                </Label>
                <p className="text-xs text-muted-foreground">
                  22:00–05:00. При включении к цене прибавляется сумма добавки.
                </p>
              </div>
              <Switch
                id="suburban-night-enabled"
                checked={form.nightEnabled}
                onCheckedChange={(v) =>
                  setForm({ ...form, nightEnabled: Boolean(v) })
                }
              />
            </div>

            {form.nightEnabled && (
              <div className="space-y-1.5">
                <Label htmlFor="suburban-night-surcharge">
                  <span className="inline-flex items-center gap-1.5">
                    <Moon className="size-4 text-primary" />
                    Добавка «ночь», ₽
                  </span>
                </Label>
                <Input
                  id="suburban-night-surcharge"
                  inputMode="numeric"
                  type="number"
                  min={0}
                  placeholder="50"
                  value={form.nightSurcharge}
                  onChange={(e) =>
                    setForm({ ...form, nightSurcharge: e.target.value })
                  }
                />
              </div>
            )}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
              >
                Отмена
              </Button>
              <Button type="submit" className="gap-2" disabled={saving}>
                {editing ? (
                  <>
                    <Pencil className="size-4" />
                    {saving ? "Сохраняем..." : "Сохранить"}
                  </>
                ) : (
                  <>
                    <Plus className="size-4" />
                    {saving ? "Добавляем..." : "Добавить"}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
