"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";

const appName = "Твоё Новое";

export function AppLoader() {
  const [state, setState] = useState<"shown" | "leaving" | "done">("shown");

  useEffect(() => {
    const leave = window.setTimeout(() => setState("leaving"), 900);
    return () => window.clearTimeout(leave);
  }, []);

  useEffect(() => {
    if (state !== "leaving") return;
    const done = window.setTimeout(() => setState("done"), 550);
    return () => window.clearTimeout(done);
  }, [state]);

  if (state === "done") return null;

  return (
    <div
      aria-hidden
      className={cn(
        "gradient-hero-vibrant fixed inset-0 z-[100] flex flex-col items-center justify-center gap-6 transition-opacity duration-500",
        state === "leaving" ? "opacity-0" : "opacity-100"
      )}
    >
      <div className="pattern-grid absolute inset-0 opacity-25 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_72%)]" />
      <div className="relative flex flex-col items-center gap-6">
        <div className="h-24 w-24 overflow-hidden rounded-2xl shadow-warm-sm ring-1 ring-primary/20">
          <Image
            src="/assets/logo.png"
            alt="Логотип"
            width={1024}
            height={1024}
            className="h-full w-full object-cover animate-in fade-in duration-700"
            priority
          />
        </div>
        <div className="flex flex-col items-center gap-2">
          <p className="text-lg font-semibold tracking-tight text-foreground">
            {appName}
          </p>
          <div className="flex items-center gap-1.5 text-primary">
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary [animation-delay:150ms]" />
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary [animation-delay:300ms]" />
          </div>
        </div>
      </div>
    </div>
  );
}
