import { CarFront, Phone } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Order } from "@/lib/models";
import { cn } from "@/lib/utils";

export function DriverCard({ order }: { order: Order }) {
  const d = order.driver;
  const carLabel = [d?.carMake, d?.carNumber, d?.carColor]
    .filter(Boolean)
    .join(", ");

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-gradient-to-br from-card to-accent/40 p-4">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
          <CarFront className="size-5" />
        </div>
        <div className="min-w-0 space-y-0.5">
          <p className="text-sm font-semibold">{d?.name ?? order.driverName}</p>
          <p className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <CarFront className="size-3.5" />
              {carLabel || "Автомобиль не указан"}
            </span>
          </p>
        </div>
      </div>
      {d?.phone && (
        <a
          href={`tel:${d.phone}`}
          className={cn(
            buttonVariants({ variant: "outline", size: "sm" }),
            "group/btn gap-1.5"
          )}
        >
          <Phone className="size-3.5 transition-transform duration-300 group-hover/btn:-rotate-12" />
          {d.phone}
        </a>
      )}
    </div>
  );
}
