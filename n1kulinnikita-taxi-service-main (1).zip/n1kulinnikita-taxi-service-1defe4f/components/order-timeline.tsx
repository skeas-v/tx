import { Check } from "lucide-react";

import { cn } from "@/lib/utils";
import { OrderStatus, type OrderStatus as OrderStatusType } from "@/lib/models";

const stepLabels = ["Ожидает водителя", "Водитель в пути", "Поездка выполнена"];

const statusMeta: Record<OrderStatusType, { label: string }> = {
  [OrderStatus.WAITING]: { label: "Ожидает водителя" },
  [OrderStatus.ASSIGNED]: { label: "Водитель назначен" },
  [OrderStatus.IN_PROGRESS]: { label: "Водитель в пути" },
  [OrderStatus.COMPLETED]: { label: "Поездка выполнена" },
  [OrderStatus.CANCELLED]: { label: "Заказ отменён" },
};

const activeStepByStatus: Record<OrderStatusType, number> = {
  [OrderStatus.WAITING]: 0,
  [OrderStatus.ASSIGNED]: 1,
  [OrderStatus.IN_PROGRESS]: 1,
  [OrderStatus.COMPLETED]: 2,
  [OrderStatus.CANCELLED]: 0,
};

interface OrderTimelineProps {
  status: OrderStatusType;
  live?: boolean;
  className?: string;
}

export function OrderTimeline({
  status,
  live = false,
  className,
}: OrderTimelineProps) {
  const activeStep = activeStepByStatus[status];

  return (
    <div
      className={cn(
        "rounded-2xl border bg-gradient-to-br from-card to-accent/30 p-4",
        className
      )}
    >
      <ol>
        {stepLabels.map((label, idx) => {
          const done = idx < activeStep;
          const active = idx === activeStep;
          const pending = !done && !active;

          return (
            <li
              key={label}
              className={cn(
                "flex gap-3",
                idx < stepLabels.length - 1 && "pb-5"
              )}
            >
              <div className="flex flex-col items-center">
                <span
                  className={cn(
                    "relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full border transition-all duration-500",
                    done && "border-emerald-500 bg-emerald-500 text-white",
                    active &&
                      "border-primary bg-primary text-primary-foreground",
                    pending &&
                      "border-border bg-background text-muted-foreground"
                  )}
                >
                  {done ? (
                    <Check className="size-3.5" />
                  ) : active ? (
                    <>
                      {live && (
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary/40 opacity-60" />
                      )}
                      <span className="relative h-1.5 w-1.5 rounded-full bg-current" />
                    </>
                  ) : null}
                </span>
                {idx < stepLabels.length - 1 && (
                  <span
                    className={cn(
                      "h-7 w-0.5 transition-colors duration-500",
                      idx < activeStep ? "bg-emerald-500" : "bg-border"
                    )}
                  />
                )}
              </div>
              <div className="flex-1">
                <p
                  className={cn(
                    "text-sm font-medium",
                    pending && "text-muted-foreground",
                    active && "text-primary"
                  )}
                >
                  {label}
                </p>
                {active && (
                  <p
                    key={status}
                    className="mt-0.5 animate-in fade-in slide-in-from-left-2 duration-300 text-xs text-muted-foreground"
                  >
                    {statusMeta[status].label}
                  </p>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
