"use client";

import { useEffect } from "react";

function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

async function saveSubscription(subscription: PushSubscription): Promise<void> {
  const raw = subscription.toJSON();
  const endpoint = raw.endpoint ?? "";
  if (!endpoint) return;
  await fetch("/api/push/subscriptions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      endpoint,
      keys: {
        p256dh: raw.keys?.p256dh ?? "",
        auth: raw.keys?.auth ?? "",
      },
      userAgent: navigator.userAgent?.slice(0, 300) ?? undefined,
    }),
  }).catch((error) => {
    console.warn("Не удалось сохранить push-подписку:", error);
  });
}

async function removeSubscription(
  subscription: PushSubscription
): Promise<void> {
  const raw = subscription.toJSON();
  const endpoint = raw.endpoint ?? "";
  if (!endpoint) return;
  await fetch(
    `/api/push/subscriptions?endpoint=${encodeURIComponent(endpoint)}`,
    { method: "DELETE" }
  ).catch((error) => {
    console.warn("Не удалось удалить push-подписку:", error);
  });
}

async function subscribeForPush(): Promise<void> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return;
  }
  if (!("PushManager" in window)) {
    return;
  }
  if (
    typeof Notification !== "undefined" &&
    Notification.permission !== "granted"
  ) {
    return;
  }

  try {
    const configRes = await fetch("/api/push/config");
    if (!configRes.ok) return;
    const config = (await configRes.json()) as {
      publicKey?: string | null;
      configured?: boolean;
    };
    if (!config.configured || !config.publicKey) return;

    const registration = await navigator.serviceWorker.ready;
    const existing = await registration.pushManager.getSubscription();

    if (existing) {
      await saveSubscription(existing);
      return;
    }

    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(config.publicKey),
    });
    await saveSubscription(subscription);
  } catch (error) {
    console.warn("Не удалось подписаться на push-уведомления:", error);
  }
}

async function unsubscribeIfNeeded(): Promise<void> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return;
  }
  if (!("PushManager" in window)) {
    return;
  }
  if (
    typeof Notification !== "undefined" &&
    Notification.permission === "granted"
  ) {
    return;
  }
  try {
    const registration = await navigator.serviceWorker.ready;
    const existing = await registration.pushManager.getSubscription();
    if (existing) {
      await removeSubscription(existing);
      await existing.unsubscribe();
    }
  } catch (error) {
    console.warn("Не удалось отписаться от push-уведомлений:", error);
  }
}

export function PushSubscribe() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    void subscribeForPush();

    const onPermissionChange = () => {
      if (typeof Notification !== "undefined") {
        if (Notification.permission === "granted") {
          void subscribeForPush();
        } else {
          void unsubscribeIfNeeded();
        }
      }
    };
    document.addEventListener("permissionchange", onPermissionChange);

    const interval = window.setInterval(
      () => {
        if (typeof Notification !== "undefined") {
          if (Notification.permission === "granted") {
            void subscribeForPush();
          }
        }
      },
      10 * 60 * 1000
    );

    return () => {
      document.removeEventListener("permissionchange", onPermissionChange);
      window.clearInterval(interval);
    };
  }, []);

  return null;
}
