"use client";

import { useCallback, useEffect, useState } from "react";
import { Globe, Save, Wallet, Wrench } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";

interface SettingsState {
  siteName: string;
  maintenanceMode: boolean;
  commissionPerOrder: number;
}

export function SettingsAdmin() {
  const [form, setForm] = useState<SettingsState>({
    siteName: "",
    maintenanceMode: false,
    commissionPerOrder: 10,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/settings");
      if (res.ok) {
        const data = (await res.json()) as SettingsState;
        setForm({
          siteName: data.siteName ?? "",
          maintenanceMode: Boolean(data.maintenanceMode),
          commissionPerOrder: Number(data.commissionPerOrder ?? 10),
        });
      }
    } catch (error) {
      console.error("Ошибка загрузки настроек:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!form.siteName.trim()) {
      toast.error("Укажите название сайта");
      return;
    }
    const commission = Number(form.commissionPerOrder);
    if (!Number.isFinite(commission) || commission < 0) {
      toast.error("Укажите корректную комиссию с заявки");
      return;
    }
    setSaving(true);
    const id = toast.loading("Сохраняем настройки...");
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteName: form.siteName.trim(),
          maintenanceMode: form.maintenanceMode,
          commissionPerOrder: commission,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить настройки", { id });
        return;
      }
      toast.success("Настройки сохранены", { id });
      setForm({
        siteName: data.siteName ?? form.siteName,
        maintenanceMode: Boolean(data.maintenanceMode),
        commissionPerOrder: Number(data.commissionPerOrder ?? commission),
      });
    } catch (error) {
      console.error("Ошибка сохранения настроек:", error);
      toast.error("Не удалось сохранить настройки", { id });
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <Card>
      <CardContent className="space-y-5 p-6">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Globe className="size-5" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Настройки сайта</h2>
            <p className="text-xs text-muted-foreground">
              Название сайта и режим технических работ.
            </p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="site-name">
              <span className="inline-flex items-center gap-1.5">
                <Globe className="size-4 text-primary" />
                Название сайта
              </span>
            </Label>
            <Input
              id="site-name"
              placeholder="Твоё Новое"
              maxLength={100}
              value={form.siteName}
              onChange={(e) => setForm({ ...form, siteName: e.target.value })}
            />
            <p className="text-xs text-muted-foreground">
              Отображается в шапке и заголовке сайта.
            </p>
          </div>

          <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label
                htmlFor="maintenance-mode"
                className="inline-flex items-center gap-1.5"
              >
                <Wrench className="size-4 text-primary" />
                Режим технических работ
              </Label>
              <p className="text-xs text-muted-foreground">
                Когда включён, обычные посетители видят страницу «технические
                работы», а вход на сайт доступен только по аккаунту
                администратора.
              </p>
            </div>
            <Switch
              id="maintenance-mode"
              checked={form.maintenanceMode}
              onCheckedChange={(v) =>
                setForm({ ...form, maintenanceMode: Boolean(v) })
              }
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="commission-per-order">
              <span className="inline-flex items-center gap-1.5">
                <Wallet className="size-4 text-primary" />
                Комиссия с одной заявки, ₽
              </span>
            </Label>
            <Input
              id="commission-per-order"
              type="number"
              min={0}
              step={0.5}
              value={form.commissionPerOrder}
              onChange={(e) =>
                setForm({
                  ...form,
                  commissionPerOrder: Number(e.target.value),
                })
              }
            />
            <p className="text-xs text-muted-foreground">
              Используется по умолчанию при выгрузке статистики в Excel:
              итоговый заработок = количество заявок × комиссия.
            </p>
          </div>

          <Button type="submit" className="gap-2" disabled={saving}>
            <Save className="size-4" />
            {saving ? "Сохраняем..." : "Сохранить настройки"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
