"use client";

import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ADMIN_ROLE_LABELS, AdminRole } from "@/lib/models";

export function AdminRoleSelect({
  value,
  disabled,
  onValueChange,
  allowedRoles,
}: {
  value: AdminRole;
  disabled?: boolean;
  onValueChange: (value: string | null) => void;
  allowedRoles: AdminRole[];
}) {
  const roles =
    allowedRoles.length > 0 ? allowedRoles : Object.values(AdminRole);
  return (
    <Select
      items={roles.map((role) => ({
        label: ADMIN_ROLE_LABELS[role],
        value: role,
      }))}
      value={value}
      disabled={disabled}
      onValueChange={onValueChange}
    >
      <SelectTrigger className="h-9 w-auto gap-2 rounded-md text-sm">
        <SelectValue />
      </SelectTrigger>
      <SelectContent className="w-full">
        <SelectGroup>
          {roles.map((role) => (
            <SelectItem key={role} value={role}>
              {ADMIN_ROLE_LABELS[role]}
            </SelectItem>
          ))}
        </SelectGroup>
      </SelectContent>
    </Select>
  );
}
