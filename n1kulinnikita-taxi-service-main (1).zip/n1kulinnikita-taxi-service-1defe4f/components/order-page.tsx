"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  ArrowUpDown,
  Baby,
  BaggageClaim,
  Banknote,
  CarFront,
  CheckCircle2,
  Crosshair,
  MapPin,
  MessageSquare,
  Navigation,
  Package,
  Phone,
  PhoneCall,
  Plus,
  Send,
  Trash2,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { AddressInput } from "@/components/address-input";
import { RouteCard } from "@/components/route-card";
import { OrderTimeline } from "@/components/order-timeline";
import { DriverCard } from "@/components/driver-card";
import { VkIcon } from "@/components/vk-icon";
import {
  Driver,
  Order,
  OrderStatus,
  PopularPlace,
  SuburbanAddress,
  carArrivalLabel,
  formatOrderNumber,
} from "@/lib/models";
import {
  createCallOrderSchema,
  createOrderSchema,
} from "@/lib/validation/orders";
import { createCallReviewSchema } from "@/lib/validation/call-reviews";
import { looksLikeBuildingAddress } from "@/lib/address";
import type { ResolvedAddress } from "@/lib/yandex-maps";
import { loadYandexMaps, reverseGeocodeAddress } from "@/lib/yandex-maps";
import { OrderMap } from "@/components/order-map";
import { EntranceField } from "@/components/entrance-field";
import { getCityTariff, DELIVERY_PRICE, TRUNK_PRICE } from "@/lib/tariff";
import { resolveTripPrice, type TripPrice } from "@/lib/suburban";
import { resolvePopularPlacePrice } from "@/lib/popular-place";
import { VK_CHAT_URL } from "@/lib/links";
import {
  getCurrentPosition,
  getSavedPosition,
  savePosition,
} from "@/lib/geolocation";
import {
  maybeRequestNotificationPermission,
  showBrowserNotification,
} from "@/lib/notifications";

const POLL_INTERVAL_MS = 5000;
const NO_DRIVER_TIMEOUT_MS = 7 * 60 * 1000;

interface OrderPageProps {
  initialAction?: "order" | "call";
}

export function OrderPage({ initialAction = "order" }: OrderPageProps) {
  const router = useRouter();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [fromPoint, setFromPoint] = useState<ResolvedAddress | null>(null);
  const [toPoint, setToPoint] = useState<ResolvedAddress | null>(null);
  const [fromEntrance, setFromEntrance] = useState("");
  const [toEntrance, setToEntrance] = useState("");
  const [stops, setStops] = useState<string[]>([]);
  const [stopPoints, setStopPoints] = useState<(ResolvedAddress | null)[]>([]);
  const [stopEntrances, setStopEntrances] = useState<string[]>([]);
  const [locatePoint, setLocatePoint] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [comment, setComment] = useState("");
  const [childSeat, setChildSeat] = useState(false);
  const [delivery, setDelivery] = useState(false);
  const [trunk, setTrunk] = useState(false);
  const [cashPayment, setCashPayment] = useState(false);
  const [cashChangeFrom, setCashChangeFrom] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [suburbanAddresses, setSuburbanAddresses] = useState<SuburbanAddress[]>(
    []
  );
  const [popularPlaces, setPopularPlaces] = useState<PopularPlace[]>([]);
  // Вручную добавленные администратором адреса (пригородные направления и
  // популярные места) показываются клиенту в подсказках полей «Откуда»/«Куда»
  // при наборе. Популярное место с указанным адресом отображается как
  // «название, адрес» (например, «Лихолесье, Монтажная ул., 5»), при выборе
  // этот полный текст подставляется в поле и попадает в адрес заказа.
  const customAddressSuggestions = useMemo(
    () => [
      ...popularPlaces.map((p) => ({
        name: p.name,
        display: p.address ? `${p.name}, ${p.address}` : p.name,
      })),
      ...suburbanAddresses.map((a) => a.name),
    ],
    [popularPlaces, suburbanAddresses]
  );
  const [sheetStep, setSheetStep] = useState<"main" | "call" | "confirmed">(
    initialAction === "call" ? "call" : "main"
  );
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);
  const [calling, setCalling] = useState(false);
  const [callDriver, setCallDriver] = useState<Driver | null>(null);
  const [callOrderId, setCallOrderId] = useState<string | null>(null);
  const [callStep, setCallStep] = useState<
    "question" | "agreed" | "declined" | "submitted" | null
  >(null);
  const [reviewText, setReviewText] = useState("");
  const [sendingReview, setSendingReview] = useState(false);
  const driverNotifiedRef = useRef(false);
  const timeoutNotifiedRef = useRef(false);
  const driverWaitingNotifiedRef = useRef<string | null>(null);
  const completedNotifiedRef = useRef(false);

  // Пригородные/загородные направления от администратора — используются для
  // расчёта цены, когда клиент указывает совпадающий адрес «откуда»/«куда».
  useEffect(() => {
    let cancelled = false;
    fetch("/api/suburban-addresses")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: SuburbanAddress[] | null) => {
        if (!cancelled && data) setSuburbanAddresses(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  // Популярные места (например, «Лихолесье»), добавленные администратором, —
  // показываются клиенту в подсказках адресов при наборе текста.
  useEffect(() => {
    let cancelled = false;
    fetch("/api/popular-places")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: PopularPlace[] | null) => {
        if (!cancelled && data) setPopularPlaces(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  /**
   * Кнопка «Найти меня»: запрашиваем геолокацию прямо в рамках жеста
   * пользователя. На iOS (iPhone) браузер показывает запрос разрешения на
   * геолокацию только при вызове getCurrentPosition из обработчика касания —
   * через отложенный эффект запрос не сработает. Полученные координаты сразу
   * сохраняем, затем обратным геокодингом Яндекс.Карт заполняем адрес
   * «Откуда». Если геокодинг недоступен — адрес можно ввести вручную.
   */
  const handleFindMe = useCallback(async () => {
    let lat: number;
    let lng: number;
    try {
      const position = await getCurrentPosition();
      savePosition(position);
      lat = position.coords.latitude;
      lng = position.coords.longitude;
    } catch {
      const saved = getSavedPosition();
      if (!saved) {
        toast.error("Не удалось определить ваше местоположение");
        return;
      }
      lat = saved.lat;
      lng = saved.lng;
    }
    toast.success("Местоположение определено");
    setFrom("");
    setFromPoint(null);
    setFromEntrance("");
    // Передаём координаты на карту: она центрируется на текущем
    // местоположении и определяет адрес «Откуда» обратным геокодированием.
    setLocatePoint({ lat, lng });
    try {
      const ymaps = await loadYandexMaps();
      const res = await reverseGeocodeAddress(ymaps, lat, lng);
      if (res) {
        setFrom(res.address);
        setFromPoint(res);
      }
    } catch {
      // Геокодинг недоступен — адрес можно ввести вручную.
    }
  }, []);

  const handleSwap = useCallback(() => {
    setFrom(to);
    setTo(from);
    setFromPoint(toPoint);
    setToPoint(fromPoint);
    setFromEntrance(toEntrance);
    setToEntrance(fromEntrance);
  }, [from, to, fromPoint, toPoint, fromEntrance, toEntrance]);

  const addStop = useCallback(() => {
    setStops((prev) => [...prev, ""]);
    setStopPoints((prev) => [...prev, null]);
    setStopEntrances((prev) => [...prev, ""]);
  }, []);

  const removeStop = useCallback((index: number) => {
    setStops((prev) => prev.filter((_, i) => i !== index));
    setStopPoints((prev) => prev.filter((_, i) => i !== index));
    setStopEntrances((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const handleFromPick = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setFrom(res.address);
    setFromPoint(res);
    setFromEntrance("");
  }, []);

  const handleToPick = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setTo(res.address);
    setToPoint(res);
    setToEntrance("");
  }, []);

  const handleStopPick = useCallback(
    (index: number, res: ResolvedAddress | null) => {
      if (!res) return;
      setStops((prev) => {
        const next = [...prev];
        next[index] = res.address;
        return next;
      });
      setStopPoints((prev) => {
        const next = [...prev];
        next[index] = res;
        return next;
      });
      setStopEntrances((prev) => {
        const next = [...prev];
        next[index] = "";
        return next;
      });
    },
    []
  );

  const handleMapLocate = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setFrom(res.address);
    setFromPoint(res);
    setFromEntrance("");
  }, []);

  // При ручном вводе адресов «Откуда»/«Куда» карта геокодирует строки и
  // сообщает результат наверх: сохраняем его в точку маршрута, чтобы маркер
  // и время в пути учитывались и координаты передавались в заказ.
  const handleFromResolve = useCallback((res: ResolvedAddress | null) => {
    setFromPoint(res);
  }, []);

  const handleToResolve = useCallback((res: ResolvedAddress | null) => {
    setToPoint(res);
  }, []);

  const handleStopResolve = useCallback(
    (index: number, res: ResolvedAddress | null) => {
      setStopPoints((prev) => {
        const next = [...prev];
        next[index] = res;
        return next;
      });
    },
    []
  );

  const handlePickModeChange = useCallback(
    (mode: "from" | "to" | number | null) => {
      if (mode === "from") {
        setFromPoint(null);
      } else if (mode === "to") {
        setToPoint(null);
      } else if (typeof mode === "number" && mode >= 0) {
        setStopPoints((prev) => {
          const next = [...prev];
          next[mode] = null;
          return next;
        });
      }
    },
    []
  );

  async function handleSubmitOrder(e: React.FormEvent) {
    e.preventDefault();
    const stopsPayload = stops
      .map((address, i) => ({
        address: address.trim(),
        entrance: looksLikeBuildingAddress(address)
          ? (stopEntrances[i] ?? "").trim() || undefined
          : undefined,
        lat: stopPoints[i]?.lat,
        lng: stopPoints[i]?.lng,
      }))
      .filter((stop) => stop.address.length > 0);
    const parsed = createOrderSchema.safeParse({
      from,
      to,
      fromAddress: fromPoint?.address,
      toAddress: toPoint?.address,
      fromEntrance: looksLikeBuildingAddress(from)
        ? fromEntrance.trim() || undefined
        : undefined,
      toEntrance: looksLikeBuildingAddress(to)
        ? toEntrance.trim() || undefined
        : undefined,
      fromLat: fromPoint?.lat,
      fromLng: fromPoint?.lng,
      toLat: toPoint?.lat,
      toLng: toPoint?.lng,
      stops: stopsPayload.length > 0 ? stopsPayload : undefined,
      clientName,
      clientPhone,
      comment,
      childSeat,
      delivery,
      trunk,
      paymentMethod: cashPayment ? "cash" : "card",
      cashChangeFrom: cashPayment
        ? cashChangeFrom.trim()
          ? Number(cashChangeFrom.trim())
          : undefined
        : undefined,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Укажите корректные точки маршрута");
      return;
    }

    setSubmitting(true);
    const id = toast.loading("Оформляем заказ...");
    void maybeRequestNotificationPermission();
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast.error(data?.error ?? "Не удалось оформить заказ", { id });
        return;
      }
      const order: Order = await res.json();
      toast.success("Заказ оформлен", { id });
      router.push(`/track?id=${encodeURIComponent(order.id)}`);
    } catch (err) {
      console.error("Ошибка оформления заказа:", err);
      toast.error("Не удалось оформить заказ", { id });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleCallDriver() {
    const parsed = createCallOrderSchema.safeParse({
      clientName,
      clientPhone,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Укажите контактные данные");
      return;
    }
    setCalling(true);
    const id = toast.loading("Ищем свободного водителя...");
    void maybeRequestNotificationPermission();
    try {
      const res = await fetch("/api/orders/call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      const driver = data?.driver;
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось найти водителя", { id });
        return;
      }
      if (!driver?.phone) {
        toast.error("Никого нет сейчас", { id });
        return;
      }
      const orderId = data?.order?.id ?? null;
      const orderNumber = orderId
        ? ` Заказ №${formatOrderNumber(orderId)}.`
        : "";
      toast.success(`Связываем вас с свободным водителем.${orderNumber}`, {
        id,
      });
      setCallDriver(driver as Driver);
      setCallOrderId(orderId);
      setReviewText("");
      window.location.href = `tel:${driver.phone}`;
      if (orderId) {
        router.push(`/track?id=${encodeURIComponent(orderId)}`);
      } else {
        setCallStep("question");
      }
    } catch (err) {
      console.error("Ошибка вызова водителя:", err);
      toast.error("Никого нет сейчас", { id });
    } finally {
      setCalling(false);
    }
  }

  function resetCallFlow() {
    setCallDriver(null);
    setCallOrderId(null);
    setCallStep(null);
    setReviewText("");
  }

  async function handleSubmitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!callDriver) return;
    const parsed = createCallReviewSchema.safeParse({
      orderId: callOrderId ?? undefined,
      driverId: callDriver.id,
      driverName: callDriver.name,
      clientName: clientName.trim() || undefined,
      clientPhone: clientPhone.trim() || undefined,
      review: reviewText,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Опишите причину");
      return;
    }
    setSendingReview(true);
    const id = toast.loading("Отправляем отзыв...");
    try {
      const res = await fetch("/api/call-reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось отправить отзыв", { id });
        return;
      }
      toast.success("Спасибо за отзыв", { id });
      setCallStep("submitted");
    } catch (err) {
      console.error("Ошибка отправки отзыва:", err);
      toast.error("Не удалось отправить отзыв", { id });
    } finally {
      setSendingReview(false);
    }
  }

  useEffect(() => {
    if (!confirmedOrderId) return;

    const orderId = confirmedOrderId;
    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | null = null;

    async function poll() {
      try {
        const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}`);
        if (!res.ok) return;
        const next: Order = await res.json();
        if (cancelled) return;

        const arrived =
          (next.status === OrderStatus.ASSIGNED ||
            next.status === OrderStatus.IN_PROGRESS) &&
          (next.driver?.carMake || next.driver?.carNumber);
        if (arrived && !driverNotifiedRef.current) {
          driverNotifiedRef.current = true;
          const message = `К Вам приедет ${carArrivalLabel(next.driver)}`;
          toast.success(message);
          showBrowserNotification(message);
        }

        if (
          next.driverWaitingAt &&
          driverWaitingNotifiedRef.current !== next.driverWaitingAt
        ) {
          driverWaitingNotifiedRef.current = next.driverWaitingAt;
          toast.success("Водитель ожидает вас");
          showBrowserNotification("Водитель ожидает вас");
        }

        if (
          next.status === OrderStatus.COMPLETED &&
          !completedNotifiedRef.current
        ) {
          completedNotifiedRef.current = true;
          toast.success("Поездка выполнена");
          showBrowserNotification("Поездка выполнена");
        }

        const elapsed = Date.now() - new Date(next.createdAt).getTime();
        if (
          next.status === OrderStatus.WAITING &&
          !timeoutNotifiedRef.current &&
          elapsed >= NO_DRIVER_TIMEOUT_MS
        ) {
          timeoutNotifiedRef.current = true;
          const message =
            "К сожалению, на линии временно никого нет, попробуйте через чат ВКонтакте";
          toast.warning(message);
          showBrowserNotification(message);
        }

        setConfirmedOrder((prev) => (prev?.id === next.id ? next : prev));

        if (
          (next.status === OrderStatus.COMPLETED ||
            next.status === OrderStatus.CANCELLED) &&
          timer
        ) {
          clearInterval(timer);
          timer = null;
        }
      } catch {
        // Временные ошибки поллинга безопасно игнорировать
      }
    }

    poll();
    timer = setInterval(poll, POLL_INTERVAL_MS);

    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
    };
  }, [confirmedOrderId]);

  const tariff = getCityTariff();
  const hasRoute = Boolean(from.trim() && to.trim());
  // Фиксированная цена популярного места: если «откуда»/«куда» совпадает с
  // популярным местом, у которого администратор указал цену (например,
  // «Лихолесье» — 30₽), применяется ровно эта цена вместо тарифа по городу.
  const fromAddressValue = fromPoint?.address || from.trim() || undefined;
  const toAddressValue = toPoint?.address || to.trim() || undefined;
  const popularPlaceTrip: { name: string; price: number } | null =
    resolvePopularPlacePrice(popularPlaces, fromAddressValue, toAddressValue);
  const popularPlaceMode = Boolean(popularPlaceTrip);
  // Пригородный/загородный тариф: если «откуда»/«куда» совпадает с добавленным
  // администратором направлением, применяется его цена (везти/забрать) с
  // учётом включённых опций час-пик и ночь.
  const suburbanTrip: TripPrice | null = resolveTripPrice(
    suburbanAddresses,
    fromAddressValue,
    toAddressValue
  );
  const suburbanMode = Boolean(suburbanTrip);
  const tripBase = popularPlaceTrip
    ? popularPlaceTrip.price
    : suburbanTrip
      ? suburbanTrip.basePrice
      : tariff.price;
  const tripSurcharge = popularPlaceTrip
    ? 0
    : suburbanTrip
      ? suburbanTrip.surcharge
      : 0;
  const totalPrice = delivery
    ? DELIVERY_PRICE
    : tripBase + tripSurcharge + (trunk ? TRUNK_PRICE : 0);
  const callCarLabel = callDriver
    ? [callDriver.carMake, callDriver.carNumber].filter(Boolean).join(", ") ||
      "Автомобиль не указан"
    : "";

  // Страница заказа — обычная потоковая вёрстка: форма «Откуда»/«Куда»,
  // ниже компактная интерактивная карта (обычный блок с фиксированной
  // высотой, без position: absolute/fixed и без трансформаций), ниже —
  // карточка заказа. Страница скроллится как обычно, карта не может
  // «уехать вниз» за пределы окна — это просто содержимое страницы.
  return (
    <div className="mx-auto w-full max-w-lg px-3 pb-[max(env(safe-area-inset-bottom),1rem)]">
      {/* Шапка страницы: «Назад» и заголовок */}
      <div className="flex items-center gap-3 pt-[calc(env(safe-area-inset-top)+0.75rem)]">
        <Link
          href="/"
          aria-label="На главную"
          title="На главную"
          className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-white text-foreground shadow-lg ring-1 ring-black/5 transition-colors hover:bg-white"
        >
          <ArrowLeft className="size-5" />
        </Link>
        <h1 className="text-lg font-bold tracking-tight">
          {initialAction === "call" ? "Вызов водителя" : "Заказ поездки"}
        </h1>
      </div>

      {/* Форма «Откуда»/«Куда»: ручной ввод с подсказками улиц, кнопка
          «Найти меня» (определение по GPS), остановки, обмен точек местами */}
      <div className="mt-3 rounded-2xl bg-white p-3 shadow-xl ring-1 ring-black/10">
        <div className="flex items-start gap-2">
          <div className="flex flex-col items-center py-0.5">
            <span className="h-3 w-3 rounded-full bg-emerald-500" />
            <span className="my-1.5 w-0.5 flex-1 border-l-2 border-dashed border-muted-foreground/30" />
            <span className="h-3 w-3 rounded-full bg-destructive" />
          </div>

          <div className="min-w-0 flex-1 space-y-2">
            <div className="flex items-start gap-2">
              <div className="min-w-0 flex-1 space-y-1.5">
                <AddressInput
                  id="order-from"
                  label="Откуда"
                  value={from}
                  placeholder="Откуда"
                  customSuggestions={customAddressSuggestions}
                  onValueChange={(v) => {
                    setFrom(v);
                    setFromPoint(null);
                  }}
                />
                {looksLikeBuildingAddress(from) && (
                  <EntranceField
                    id="order-from-entrance"
                    value={fromEntrance}
                    onChange={setFromEntrance}
                  />
                )}
              </div>
              <Button
                type="button"
                size="sm"
                onClick={handleFindMe}
                className="shrink-0 gap-1.5 rounded-full px-3.5"
              >
                <Crosshair className="size-4" />
                Найти меня
              </Button>
            </div>

            {stops.map((stop, i) => (
              <div key={i} className="flex items-start gap-2">
                <div className="min-w-0 flex-1 space-y-1.5">
                  <AddressInput
                    id={`order-stop-${i}`}
                    label={`Остановка ${i + 1}`}
                    value={stop}
                    placeholder="Промежуточный адрес"
                    customSuggestions={customAddressSuggestions}
                    onValueChange={(v) => {
                      setStops((prev) => {
                        const next = [...prev];
                        next[i] = v;
                        return next;
                      });
                      setStopPoints((prev) => {
                        const next = [...prev];
                        next[i] = null;
                        return next;
                      });
                    }}
                  />
                  {looksLikeBuildingAddress(stop) && (
                    <EntranceField
                      id={`order-stop-${i}-entrance`}
                      value={stopEntrances[i] ?? ""}
                      onChange={(v) => {
                        setStopEntrances((prev) => {
                          const next = [...prev];
                          next[i] = v;
                          return next;
                        });
                      }}
                    />
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => removeStop(i)}
                  aria-label="Удалить остановку"
                  title="Удалить остановку"
                  className="self-center rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            ))}

            <div className="space-y-1.5">
              <AddressInput
                id="order-to"
                label="Куда"
                value={to}
                placeholder="Куда"
                customSuggestions={customAddressSuggestions}
                onValueChange={(v) => {
                  setTo(v);
                  setToPoint(null);
                }}
              />
              {looksLikeBuildingAddress(to) && (
                <EntranceField
                  id="order-to-entrance"
                  value={toEntrance}
                  onChange={setToEntrance}
                />
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={handleSwap}
            aria-label="Поменять местами"
            title="Поменять местами"
            className="self-center rounded-full bg-muted/70 p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <ArrowUpDown className="size-4" />
          </button>
        </div>

        <div className="mt-2.5 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <Navigation className="size-3.5 shrink-0 text-primary" />
            Кирово-Чепецк, Кировская область
          </span>
          <button
            type="button"
            onClick={addStop}
            className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary transition-colors hover:bg-primary/20"
          >
            <Plus className="size-3.5" />
            Добавить адрес
          </button>
        </div>
      </div>

      {/* Компактная интерактивная карта — обычный элемент потока: position:
          static/relative, width: 100%, фиксированная высота, без
          absolute/fixed и без трансформаций. Скроллится вместе со
          страницей и не может уехать за пределы окна. Точки «откуда»/
          «куда» и промежуточные остановки выбираются кликом по карте,
          адреса заполняются обратным геокодированием, на карте строится
          маршрут. */}
      <OrderMap
        from={from}
        to={to}
        stops={stops}
        height={260}
        autoPick
        showLocate
        className="mt-3 rounded-2xl shadow-lg ring-1 ring-black/10"
        onFromPick={handleFromPick}
        onToPick={handleToPick}
        onStopPick={handleStopPick}
        onLocate={handleMapLocate}
        onPickModeChange={handlePickModeChange}
        onFromResolve={handleFromResolve}
        onToResolve={handleToResolve}
        onStopResolve={handleStopResolve}
        locatePoint={locatePoint}
      />

      {/* Карточка заказа (шторка) — обычный блок в потоке ниже формы и карты */}
      <div className="mt-3 rounded-3xl bg-white p-4 shadow-xl ring-1 ring-black/10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        {sheetStep === "confirmed" && confirmedOrder ? (
          <div className="space-y-4">
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                <span className="absolute inset-0 animate-ping rounded-full bg-emerald-500/10 opacity-40" />
                <CheckCircle2 className="size-8" />
              </div>
              <h2 className="text-xl font-bold tracking-tight">
                Заказ оформлен
              </h2>
              <p className="text-sm text-muted-foreground">
                Ваш заказ отправлен в очередь для водителей. Водитель скоро его
                примет.
              </p>
            </div>

            <RouteCard
              from={confirmedOrder.from}
              to={confirmedOrder.to}
              fromEntrance={confirmedOrder.fromEntrance}
              toEntrance={confirmedOrder.toEntrance}
              stops={confirmedOrder.stops}
            />

            <OrderTimeline status={confirmedOrder.status} />

            {(confirmedOrder.driver || confirmedOrder.driverName) && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                <DriverCard order={confirmedOrder} />
              </div>
            )}

            <div className="flex items-center justify-between rounded-xl border bg-muted/40 px-4 py-3 text-sm">
              <span className="text-muted-foreground">Номер заказа</span>
              <span className="font-mono font-semibold">
                №{formatOrderNumber(confirmedOrder.id)}
              </span>
            </div>

            <div className="grid gap-2">
              <Button
                className="group/btn w-full gap-2"
                onClick={() =>
                  router.push(
                    `/track?id=${encodeURIComponent(confirmedOrder.id)}`
                  )
                }
              >
                <MapPin className="size-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
                Отслеживать статус заказа
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSheetStep("main");
                  setConfirmedOrder(null);
                  setConfirmedOrderId(null);
                  setFrom("");
                  setTo("");
                  setFromPoint(null);
                  setToPoint(null);
                  setFromEntrance("");
                  setToEntrance("");
                  setStops([]);
                  setStopPoints([]);
                  setStopEntrances([]);
                  setComment("");
                  setCashPayment(false);
                  setCashChangeFrom("");
                  driverNotifiedRef.current = false;
                  timeoutNotifiedRef.current = false;
                  driverWaitingNotifiedRef.current = null;
                  completedNotifiedRef.current = false;
                }}
              >
                Оформить ещё один заказ
              </Button>
            </div>
          </div>
        ) : sheetStep === "call" && callDriver && callStep ? (
          <div className="space-y-4">
            {callStep === "question" && (
              <>
                <div className="flex flex-col items-center gap-3 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <PhoneCall className="size-7" />
                  </div>
                  <h2 className="text-xl font-bold tracking-tight">
                    Вы договорились с водителем?
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Мы соединили вас с водителем. Подтвердите, удалось ли
                    договориться о поездке.
                  </p>
                </div>

                <div className="grid gap-2">
                  <Button
                    className="group/btn w-full gap-2"
                    onClick={() => setCallStep("agreed")}
                  >
                    <CheckCircle2 className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                    Да, договорились
                  </Button>
                  <Button
                    variant="outline"
                    className="group/btn w-full gap-2"
                    onClick={() => setCallStep("declined")}
                  >
                    <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                    Нет, не получилось
                  </Button>
                </div>
              </>
            )}

            {callStep === "agreed" && (
              <>
                <div className="flex flex-col items-center gap-3 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                    <CheckCircle2 className="size-8" />
                  </div>
                  <h2 className="text-xl font-bold tracking-tight">
                    Машина приедет
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Ожидайте автомобиль. Время ожидания — 5–7 минут.
                  </p>
                </div>

                <div className="space-y-3 rounded-2xl border bg-gradient-to-br from-card to-accent/40 p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <CarFront className="size-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-muted-foreground">
                        Какая машина приедет
                      </p>
                      <p className="truncate font-semibold">{callCarLabel}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <User className="size-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-muted-foreground">Водитель</p>
                      <p className="truncate font-semibold">
                        {callDriver.name}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Button
                    className="group/btn w-full gap-2"
                    onClick={() => {
                      window.location.href = `tel:${callDriver.phone}`;
                    }}
                  >
                    <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                    Связаться с этим водителем повторно
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      resetCallFlow();
                      setSheetStep("main");
                    }}
                  >
                    Вернуться к заказу
                  </Button>
                </div>
              </>
            )}

            {callStep === "declined" && (
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div className="flex flex-col items-center gap-3 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
                    <Phone className="size-7" />
                  </div>
                  <h2 className="text-xl font-bold tracking-tight">
                    Расскажите, почему не удалось вызвать машину?
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Ваш отзыв поможет нам улучшить сервис.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="order-review" className="sr-only">
                    Причина
                  </Label>
                  <Textarea
                    id="order-review"
                    placeholder="Например: водитель не ответил, не приехал вовремя..."
                    value={reviewText}
                    maxLength={1000}
                    onChange={(e) => setReviewText(e.target.value)}
                    required
                  />
                </div>

                <div className="grid gap-2">
                  <Button
                    type="submit"
                    className="w-full gap-2"
                    disabled={sendingReview}
                  >
                    <Send className="size-4" />
                    {sendingReview ? "Отправляем..." : "Отправить отзыв"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      resetCallFlow();
                      setSheetStep("main");
                    }}
                  >
                    Отмена
                  </Button>
                </div>
              </form>
            )}

            {callStep === "submitted" && (
              <div className="space-y-4">
                <div className="flex flex-col items-center gap-3 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                    <CheckCircle2 className="size-8" />
                  </div>
                  <h2 className="text-xl font-bold tracking-tight">
                    Спасибо за отзыв
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Мы передали ваш ответ администратору.
                  </p>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    resetCallFlow();
                    setSheetStep("main");
                  }}
                >
                  Вернуться к заказу
                </Button>
              </div>
            )}
          </div>
        ) : sheetStep === "call" ? (
          <div className="space-y-4">
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                <PhoneCall className="size-7" />
              </div>
              <h2 className="text-xl font-bold tracking-tight">
                Вызов свободного водителя
              </h2>
              <p className="text-sm text-muted-foreground">
                Свяжем вас с водителем, который сейчас на линии. Адреса не
                нужны.
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <Label htmlFor="order-call-name">Имя (необязательно)</Label>
                <Input
                  id="order-call-name"
                  placeholder="Как вас зовут?"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="order-call-phone">
                  Телефон (необязательно)
                </Label>
                <Input
                  id="order-call-phone"
                  type="tel"
                  placeholder="+7 ___ ___-__-__"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                />
              </div>
            </div>

            <Button
              type="button"
              className="group/btn w-full gap-2 shadow-warm-sm"
              size="lg"
              disabled={calling}
              onClick={handleCallDriver}
            >
              <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
              {calling ? "Ищем..." : "Найти свободного водителя"}
            </Button>

            <Button
              variant="ghost"
              className="w-full"
              onClick={() => setSheetStep("main")}
            >
              Назад к заказу
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmitOrder} className="space-y-4">
            {/* Маршрут */}
            <div className="rounded-2xl border bg-muted/40 p-3">
              <div className="flex items-center gap-2.5">
                <div className="flex flex-col items-center gap-1 py-0.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" />
                  <span className="h-6 w-0.5 border-l border-dashed border-muted-foreground/40" />
                  <span className="h-2 w-2 rounded-full bg-destructive" />
                </div>
                <div className="min-w-0 flex-1 space-y-1 text-sm">
                  <p className="truncate font-medium">
                    {from || "Откуда — не указано"}
                  </p>
                  <p className="truncate text-muted-foreground">
                    {to || "Куда — не указано"}
                  </p>
                </div>
              </div>
              {!hasRoute && (
                <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Navigation className="size-3.5 shrink-0 text-primary" />
                  Укажите точки маршрута, чтобы рассчитать стоимость поездки.
                </p>
              )}
            </div>

            {/* Тариф — актуальная стоимость выделенным шрифтом: городской,
                закреплённый администратором для пригородного направления или
                фиксированная цена популярного места */}
            <div className="rounded-xl border bg-primary/5 px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground">
                    {delivery
                      ? "Доставка по адресу"
                      : popularPlaceMode
                        ? `${popularPlaceTrip!.name} · фикс. цена`
                        : suburbanMode
                          ? `${suburbanTrip!.matchedName} · ${
                              suburbanTrip!.direction === "from"
                                ? "забрать"
                                : "везти"
                            }`
                          : "Поездка по городу"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {delivery
                      ? "Отдельная услуга, не зависит от тарифа"
                      : popularPlaceMode
                        ? "Цена закреплена администратором за этим местом"
                        : suburbanMode
                          ? suburbanTrip!.window
                          : tariff.window}
                  </p>
                  {!delivery && trunk && (
                    <p className="mt-1 text-xs font-medium text-foreground">
                      +{TRUNK_PRICE}₽ багажник
                    </p>
                  )}
                </div>
                <span className="whitespace-nowrap text-2xl font-extrabold tracking-tight text-primary">
                  {`${totalPrice}₽ ${
                    delivery || popularPlaceMode || suburbanMode
                      ? ""
                      : tariff.period
                  }`.trimEnd()}
                </span>
              </div>
              {(suburbanMode || popularPlaceMode) && (
                <p className="mt-2 border-t pt-2 text-xs text-muted-foreground">
                  {popularPlaceTrip
                    ? `${popularPlaceTrip.price}₽${
                        trunk ? ` + ${TRUNK_PRICE}₽ багажник` : ""
                      }`
                    : `${suburbanTrip!.basePrice}₽${
                        suburbanTrip!.surcharge > 0
                          ? ` + добавка ${suburbanTrip!.surcharge}₽`
                          : ""
                      }${trunk ? ` + ${TRUNK_PRICE}₽ багажник` : ""}`}
                </p>
              )}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {suburbanMode
                ? "Тариф закреплён администратором для этого направления."
                : popularPlaceMode
                  ? "Тариф закреплён администратором за этим местом."
                  : "Пригородные и загородные тарифы уточняйте у водителя"}
            </p>

            {/* Опции поездки */}
            <div className="rounded-xl border bg-primary/5 px-4 py-3">
              <div className="space-y-3">
                <label className="flex items-center gap-2.5 text-sm font-medium text-foreground">
                  <Checkbox
                    checked={childSeat}
                    onCheckedChange={setChildSeat}
                    aria-label="Детское кресло"
                  />
                  <Baby className="size-4 shrink-0 text-primary" />
                  Детское кресло
                </label>
                <label className="flex items-center justify-between gap-2.5 text-sm font-medium text-foreground">
                  <span className="flex items-center gap-2.5">
                    <Checkbox
                      checked={delivery}
                      onCheckedChange={setDelivery}
                      aria-label="Доставка"
                    />
                    <Package className="size-4 shrink-0 text-primary" />
                    Доставка
                  </span>
                  <span className="whitespace-nowrap text-sm font-semibold text-primary">
                    +{DELIVERY_PRICE}₽
                  </span>
                </label>
                <label className="flex items-center justify-between gap-2.5 text-sm font-medium text-foreground">
                  <span className="flex items-center gap-2.5">
                    <Checkbox
                      checked={trunk}
                      onCheckedChange={setTrunk}
                      aria-label="Багажник"
                    />
                    <BaggageClaim className="size-4 shrink-0 text-primary" />
                    Багажник
                  </span>
                  <span className="whitespace-nowrap text-sm font-semibold text-primary">
                    +{TRUNK_PRICE}₽
                  </span>
                </label>
              </div>
            </div>

            {/* Оплата */}
            <div className="rounded-xl border bg-primary/5 px-4 py-3">
              <div className="space-y-3">
                <label className="flex items-center gap-2.5 text-sm font-medium text-foreground">
                  <Checkbox
                    checked={cashPayment}
                    onCheckedChange={(checked) => {
                      setCashPayment(Boolean(checked));
                      if (!checked) setCashChangeFrom("");
                    }}
                    aria-label="Оплата наличными"
                  />
                  <Banknote className="size-4 shrink-0 text-primary" />
                  Оплата наличными
                </label>
                {cashPayment && (
                  <div className="animate-in fade-in slide-in-from-top-1 duration-300 space-y-1 pl-7">
                    <Label htmlFor="order-cash-change">
                      Подготовить сдачу с …
                    </Label>
                    <div className="relative">
                      <Input
                        id="order-cash-change"
                        type="number"
                        inputMode="numeric"
                        min={1}
                        placeholder="Например, 500"
                        value={cashChangeFrom}
                        onChange={(e) => setCashChangeFrom(e.target.value)}
                      />
                      <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-muted-foreground">
                        ₽
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Необязательно. Водитель подготовит сдачу с этой суммы.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Контакты */}
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <Label htmlFor="order-name">Имя (необязательно)</Label>
                <Input
                  id="order-name"
                  placeholder="Как вас зовут?"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="order-phone">Телефон (необязательно)</Label>
                <Input
                  id="order-phone"
                  type="tel"
                  placeholder="+7 ___ ___-__-__"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                />
              </div>
            </div>

            {/* Комментарий водителю */}
            <div className="space-y-1">
              <Label htmlFor="order-comment">
                <span className="inline-flex items-center gap-1.5">
                  <MessageSquare className="size-4 text-primary" />
                  Комментарий водителю
                </span>
              </Label>
              <Textarea
                id="order-comment"
                placeholder="Например: позвоните за 5 минут, подъезд со двора"
                value={comment}
                maxLength={500}
                onChange={(e) => setComment(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Необязательно. Передадим водителю вместе с заказом.
              </p>
            </div>

            <Button
              type="submit"
              className="group/btn w-full gap-2 shadow-warm-sm"
              size="lg"
              disabled={submitting || !hasRoute}
            >
              {submitting ? (
                <span className="flex items-center gap-2">
                  <MapPin className="size-4 animate-pulse" />
                  Оформляем...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Navigation className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                  Заказать {hasRoute ? `за ${totalPrice}₽` : "машину"}
                </span>
              )}
            </Button>

            <div className="grid gap-2 sm:grid-cols-2">
              <Button
                type="button"
                variant="outline"
                className="group/btn w-full gap-2"
                size="lg"
                onClick={() => setSheetStep("call")}
              >
                <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                Вызвать по телефону
              </Button>
              <a
                href={VK_CHAT_URL}
                target="_blank"
                rel="noopener noreferrer"
                className={cn(
                  buttonVariants({ variant: "outline", size: "lg" }),
                  "group/btn w-full gap-2"
                )}
              >
                <VkIcon className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                Через Чат
              </a>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
