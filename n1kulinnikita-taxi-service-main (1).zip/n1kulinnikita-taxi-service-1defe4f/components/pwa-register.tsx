"use client";

import { useEffect } from "react";

export function PwaRegister() {
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
      return;
    }
    let cancelled = false;
    const register = async () => {
      try {
        const registration = await navigator.serviceWorker.register("/sw.js");
        if (!cancelled && !registration.active) {
          await navigator.serviceWorker.ready;
        }
      } catch (error) {
        console.warn("Сервисный воркер не зарегистрирован:", error);
      }
    };
    void register();
    return () => {
      cancelled = true;
    };
  }, []);

  return null;
}
