"use client";

import { useState } from "react";
import { DoorOpen, Pencil, Plus, X } from "lucide-react";
import { Input } from "@/components/ui/input";

interface EntranceFieldProps {
  id: string;
  value: string;
  onChange: (value: string) => void;
  show?: boolean;
}

export function EntranceField({
  id,
  value,
  onChange,
  show = true,
}: EntranceFieldProps) {
  const [open, setOpen] = useState(false);

  if (!show) return null;

  const entrance = value.trim();

  if (entrance && !open) {
    return (
      <div className="flex items-center gap-1.5">
        <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
          <DoorOpen className="size-3.5" />
          Подъезд {entrance}
        </span>
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Изменить подъезд"
          title="Изменить подъезд"
          className="rounded-full p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <Pencil className="size-3.5" />
        </button>
        <button
          type="button"
          onClick={() => {
            onChange("");
            setOpen(false);
          }}
          aria-label="Убрать подъезд"
          title="Убрать подъезд"
          className="rounded-full p-1 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
        >
          <X className="size-3.5" />
        </button>
      </div>
    );
  }

  if (open) {
    return (
      <div className="flex items-center gap-1.5">
        <Input
          id={id}
          inputMode="text"
          maxLength={10}
          placeholder="Подъезд"
          className="h-9 rounded-xl pl-3 text-sm"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoFocus
        />
        <button
          type="button"
          onClick={() => {
            onChange("");
            setOpen(false);
          }}
          aria-label={entrance ? "Убрать подъезд" : "Готово"}
          title={entrance ? "Убрать подъезд" : "Готово"}
          className="shrink-0 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
        >
          <X className="size-4" />
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={() => setOpen(true)}
      className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary transition-colors hover:bg-primary/20"
    >
      <Plus className="size-3.5" />
      указать подъезд
    </button>
  );
}
