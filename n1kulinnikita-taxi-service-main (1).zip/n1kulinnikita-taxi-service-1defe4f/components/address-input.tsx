"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
  getStreetMatchLength,
  normalizeStreetQuery,
  suggestStreets,
  type StreetSuggestion,
} from "@/lib/address-data";

export interface CustomAddressSuggestion {
  /** Название (например, «Лихолесье»), по которому ищется совпадение. */
  name: string;
  /** Полный текст для подсказки и подстановки в поле (например, «Лихолесье, Монтажная ул., 5»). */
  display: string;
}

interface AddressInputProps {
  id: string;
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  label?: string;
  /** Дополнительные адреса (например, добавленные администратором направления
   *  и популярные места), которые показываются в подсказках при наборе. */
  customSuggestions?: Array<string | CustomAddressSuggestion>;
}

// Нормализация для вручную добавленных адресов: сохраняет цифры и буквы,
// убирает знаки препинания. Например, «5-ое садоводство» → «5 ое садоводство».
function normalizeCustom(value: string): string {
  return value
    .toLowerCase()
    .replace(/[ёЁ]/g, "е")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

export function AddressInput({
  id,
  value,
  onValueChange,
  placeholder,
  required,
  label,
  customSuggestions,
}: AddressInputProps) {
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const suggestions = useMemo(() => {
    const streets = suggestStreets(value);
    const query = normalizeCustom(value);
    const seen = new Set<string>();
    const custom: StreetSuggestion[] = (customSuggestions ?? [])
      .map((suggestion) => {
        const name =
          typeof suggestion === "string" ? suggestion : suggestion.name.trim();
        const display =
          typeof suggestion === "string"
            ? suggestion.trim()
            : suggestion.display.trim() || suggestion.name.trim();
        return { name, display };
      })
      .filter(({ name }) => {
        if (!name) return false;
        const norm = normalizeCustom(name);
        if (!norm) return false;
        if (seen.has(norm)) return false;
        seen.add(norm);
        if (!query) return true;
        // Место показывается, когда набранный текст совпадает с началом
        // названия (например, «лихо...» → «Лихолесье») или когда клиент
        // вводит более длинный адрес, содержащий добавленное название целиком.
        return norm.startsWith(query) || query.includes(norm);
      })
      .map(({ name, display }) => ({
        kind: "улица",
        name,
        display,
      }));
    return [...custom, ...streets];
  }, [value, customSuggestions]);

  useEffect(() => {
    function onPointerDown(e: MouseEvent | TouchEvent) {
      if (
        containerRef.current &&
        e.target instanceof Node &&
        !containerRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("touchstart", onPointerDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("touchstart", onPointerDown);
    };
  }, []);

  function handleChange(next: string) {
    onValueChange(next);
    setOpen(true);
    setActiveIndex(0);
  }

  function handleSelect(suggestion: StreetSuggestion) {
    onValueChange(suggestion.display);
    setOpen(false);
    inputRef.current?.focus();
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (!open || suggestions.length === 0) {
      if (e.key === "ArrowDown" && suggestions.length > 0) {
        e.preventDefault();
        setOpen(true);
      }
      return;
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((prev) => (prev + 1) % suggestions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((prev) => (prev <= 0 ? suggestions.length - 1 : prev - 1));
    } else if (e.key === "Enter") {
      const index =
        activeIndex >= 0 && activeIndex < suggestions.length ? activeIndex : 0;
      const active = suggestions[index];
      if (active) {
        e.preventDefault();
        handleSelect(active);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  }

  const showDropdown =
    open &&
    suggestions.length > 0 &&
    !suggestions.some(
      (s) =>
        normalizeStreetQuery(value) === normalizeStreetQuery(s.name) ||
        (normalizeCustom(value).length > 0 &&
          normalizeCustom(value) === normalizeCustom(s.display))
    );

  return (
    <div ref={containerRef} className="relative">
      {label ? (
        <label className="sr-only" htmlFor={id}>
          {label}
        </label>
      ) : null}
      <MapPin className="pointer-events-none absolute left-3 top-1/2 z-10 size-4 -translate-y-1/2 text-primary/70" />
      <Input
        ref={inputRef}
        id={id}
        placeholder={placeholder}
        value={value}
        required={required}
        autoComplete="off"
        role="combobox"
        aria-expanded={showDropdown}
        aria-autocomplete="list"
        aria-controls={showDropdown ? `${id}-listbox` : undefined}
        aria-haspopup="listbox"
        className="pl-9 transition-shadow duration-200 focus-visible:ring-primary/40"
        onChange={(e) => handleChange(e.target.value)}
        onFocus={() => {
          setOpen(true);
          setActiveIndex(0);
        }}
        onKeyDown={handleKeyDown}
        onBlur={() => setActiveIndex(-1)}
      />

      {showDropdown ? (
        <ul
          id={`${id}-listbox`}
          role="listbox"
          className="absolute z-30 mt-1.5 max-h-72 w-full overflow-auto rounded-xl border bg-popover p-1.5 shadow-lg shadow-primary/5 animate-in fade-in zoom-in-95 duration-150"
        >
          {suggestions.map((suggestion, idx) => {
            const query = normalizeStreetQuery(value);
            const nameIndex = suggestion.display.indexOf(suggestion.name);
            const matchLength =
              nameIndex >= 0 ? getStreetMatchLength(suggestion.name, query) : 0;
            const matchStart = nameIndex >= 0 ? nameIndex : 0;
            const before =
              matchLength > 0 ? suggestion.display.slice(0, matchStart) : "";
            const matched =
              matchLength > 0
                ? suggestion.display.slice(matchStart, matchStart + matchLength)
                : "";
            const after =
              matchLength > 0
                ? suggestion.display.slice(matchStart + matchLength)
                : suggestion.display;

            return (
              <li key={suggestion.display}>
                <button
                  type="button"
                  role="option"
                  aria-selected={idx === activeIndex}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm transition-colors",
                    idx === activeIndex
                      ? "bg-primary/10 text-primary"
                      : "text-foreground hover:bg-muted"
                  )}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => handleSelect(suggestion)}
                  onMouseEnter={() => setActiveIndex(idx)}
                >
                  <span
                    className={cn(
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-colors",
                      idx === activeIndex
                        ? "bg-primary text-primary-foreground"
                        : "bg-primary/10 text-primary"
                    )}
                  >
                    <MapPin className="size-3.5" />
                  </span>
                  <span className="truncate">
                    {before}
                    {matched && (
                      <strong
                        className={cn(
                          "font-semibold",
                          idx === activeIndex
                            ? "text-primary"
                            : "text-foreground"
                        )}
                      >
                        {matched}
                      </strong>
                    )}
                    {after}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}
