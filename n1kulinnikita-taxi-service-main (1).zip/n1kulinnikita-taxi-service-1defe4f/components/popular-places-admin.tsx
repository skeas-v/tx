"use client";

import { useCallback, useEffect, useState } from "react";
import { MapPinned, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PopularPlace } from "@/lib/models";
import { popularPlaceSchema } from "@/lib/validation/popular-places";

interface FormState {
  name: string;
  address: string;
  price: string;
}

const emptyForm: FormState = { name: "", address: "", price: "" };

export function PopularPlacesAdmin() {
  const [places, setPlaces] = useState<PopularPlace[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<PopularPlace | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [busyId, setBusyId] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/popular-places");
      if (res.ok) {
        setPlaces((await res.json()) as PopularPlace[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки популярных мест:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  }

  function openEdit(place: PopularPlace) {
    setEditing(place);
    setForm({
      name: place.name,
      address: place.address ?? "",
      price: place.price != null ? String(place.price) : "",
    });
    setOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = popularPlaceSchema.safeParse({
      name: form.name,
      address: form.address,
      price: form.price.trim() === "" ? null : Number(form.price),
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Проверьте правильность данных");
      return;
    }
    const payload = parsed.data;

    setSaving(true);
    const id = toast.loading(
      editing ? "Сохраняем место..." : "Добавляем место..."
    );
    try {
      const url = editing
        ? `/api/admin/popular-places/${encodeURIComponent(editing.id)}`
        : "/api/admin/popular-places";
      const res = await fetch(url, {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить место", { id });
        return;
      }
      toast.success(editing ? "Место обновлено" : "Место добавлено", { id });
      setOpen(false);
      setForm(emptyForm);
      refresh();
    } catch (error) {
      console.error("Ошибка сохранения места:", error);
      toast.error("Не удалось сохранить место", { id });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(place: PopularPlace) {
    setBusyId(place.id);
    const id = toast.loading("Удаляем место...");
    try {
      const res = await fetch(
        `/api/admin/popular-places/${encodeURIComponent(place.id)}`,
        { method: "DELETE" }
      );
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось удалить место", { id });
        return;
      }
      toast.success("Место удалено", { id });
      refresh();
    } catch (error) {
      console.error("Ошибка удаления места:", error);
      toast.error("Не удалось удалить место", { id });
    } finally {
      setBusyId(null);
    }
  }

  function confirmDelete(place: PopularPlace) {
    toast(`Удалить место «${place.name}»?`, {
      description: "Место исчезнет из подсказок адресов в форме заказа.",
      action: {
        label: "Удалить",
        onClick: () => handleDelete(place),
      },
      cancel: {
        label: "Отмена",
        onClick: () => {},
      },
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Популярные места</h2>
          <Badge variant="outline">{places.length}</Badge>
        </div>
        <Button className="gap-2" onClick={openCreate}>
          <Plus className="size-4" />
          Добавить место
        </Button>
      </div>

      {loading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      ) : places.length > 0 ? (
        <div className="grid gap-3">
          {places.map((place) => (
            <Card key={place.id} size="sm">
              <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex min-w-0 items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <MapPinned className="size-5" />
                  </div>
                  <div className="min-w-0 space-y-1">
                    <p className="truncate font-medium">
                      {place.name}
                      {place.address ? (
                        <span className="text-muted-foreground">
                          , {place.address}
                        </span>
                      ) : null}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {place.price != null
                        ? `Фиксированная цена поездки: ${place.price}₽.`
                        : place.address
                          ? "Показывается в подсказках как «название, адрес»."
                          : "Показывается в подсказках адресов при наборе."}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    onClick={() => openEdit(place)}
                  >
                    <Pencil className="size-4" />
                    Редактировать
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2 border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                    disabled={busyId === place.id}
                    onClick={() => confirmDelete(place)}
                  >
                    <Trash2 className="size-4" />
                    Удалить
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
            <MapPinned className="size-6" />
          </div>
          <div className="space-y-1 px-6">
            <p className="font-medium">Список мест пуст</p>
            <p className="text-sm text-muted-foreground">
              Добавьте популярное место, чтобы оно появлялось в подсказках
              адресов у клиентов.
            </p>
          </div>
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => setOpen(v)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editing ? "Редактировать место" : "Добавить место"}
            </DialogTitle>
            <DialogDescription>
              {editing
                ? "Измените название, адрес и цену популярного места."
                : "Место будет показываться клиенту в подсказках адресов при наборе."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="popular-place-name">
                <span className="inline-flex items-center gap-1.5">
                  <MapPinned className="size-4 text-primary" />
                  Название места
                </span>
              </Label>
              <Input
                id="popular-place-name"
                placeholder="Например, Лихолесье"
                value={form.name}
                maxLength={200}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Место появится в подсказках, когда клиент начнёт набирать
                название (например, «лихо...» → «Лихолесье»).
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="popular-place-address">
                <span className="inline-flex items-center gap-1.5">
                  <MapPinned className="size-4 text-primary" />
                  Адрес (необязательно)
                </span>
              </Label>
              <Input
                id="popular-place-address"
                placeholder="Например, Монтажная ул., 5"
                value={form.address}
                maxLength={300}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Если указан, в подсказке и в заказе место отображается как
                «название, адрес».
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="popular-place-price">
                <span className="inline-flex items-center gap-1.5">
                  <MapPinned className="size-4 text-primary" />
                  Цена поездки, ₽ (необязательно)
                </span>
              </Label>
              <Input
                id="popular-place-price"
                inputMode="numeric"
                type="number"
                min={0}
                placeholder="Например, 30"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Если указана, при выборе этого места стоимость поездки станет
                ровно этой суммой вместо тарифа по городу. Если не указана —
                применяется обычный тариф.
              </p>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
              >
                Отмена
              </Button>
              <Button type="submit" className="gap-2" disabled={saving}>
                {editing ? (
                  <>
                    <Pencil className="size-4" />
                    {saving ? "Сохраняем..." : "Сохранить"}
                  </>
                ) : (
                  <>
                    <Plus className="size-4" />
                    {saving ? "Добавляем..." : "Добавить"}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
