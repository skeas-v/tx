import { BookOpenText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export function ContentPage({
  title,
  siteName,
  text,
  emptyText,
}: {
  title: string;
  siteName: string;
  text: string;
  emptyText: string;
}) {
  const hasText = Boolean(text.trim());

  return (
    <div className="relative mx-auto max-w-3xl px-4 py-10">
      <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/80 text-primary shadow-warm-sm ring-1 ring-primary/20 backdrop-blur">
            <BookOpenText className="size-5" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
              {title}
            </h1>
            <p className="text-sm text-muted-foreground">{siteName}</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6">
            {hasText ? (
              <div className="whitespace-pre-line text-sm leading-relaxed text-foreground/90 [&_a]:text-primary [&_a]:underline">
                {text}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">{emptyText}</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
