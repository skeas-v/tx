"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import {
  ArrowUpDown,
  CarFront,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Crosshair,
  MapPin,
  Maximize2,
  Minimize2,
  Navigation,
  Phone,
  PhoneCall,
  Plus,
  Send,
  Trash2,
  User,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { LiveMap, type PickSlot } from "@/components/live-map";
import { AddressInput } from "@/components/address-input";
import { RouteCard } from "@/components/route-card";
import { OrderTimeline } from "@/components/order-timeline";
import { DriverCard } from "@/components/driver-card";
import { VkIcon } from "@/components/vk-icon";
import {
  Driver,
  Order,
  OrderStatus,
  carArrivalLabel,
  formatOrderNumber,
} from "@/lib/models";
import {
  createCallOrderSchema,
  createOrderSchema,
} from "@/lib/validation/orders";
import { createCallReviewSchema } from "@/lib/validation/call-reviews";
import { looksLikeBuildingAddress } from "@/lib/address";
import type { ResolvedAddress } from "@/lib/yandex-maps";
import { getCityTariff } from "@/lib/tariff";
import { VK_CHAT_URL } from "@/lib/links";
import {
  getCurrentPosition,
  getSavedPosition,
  savePosition,
} from "@/lib/geolocation";
import {
  maybeRequestNotificationPermission,
  showBrowserNotification,
} from "@/lib/notifications";

const POLL_INTERVAL_MS = 5000;
const NO_DRIVER_TIMEOUT_MS = 7 * 60 * 1000;
const AVERAGE_SPEED_KMH = 32;

interface OrderWindowProps {
  open: boolean;
  onClose: () => void;
  initialAction?: "order" | "call";
}

function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): number {
  const toRad = (v: number) => (v * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

function estimateTrip(
  from: ResolvedAddress | null,
  to: ResolvedAddress | null
): number | null {
  if (!from || !to) return null;
  const km = Math.max(1, haversineKm(from, to));
  return Math.max(3, Math.round((km / AVERAGE_SPEED_KMH) * 60));
}

export function OrderWindow({
  open,
  onClose,
  initialAction = "order",
}: OrderWindowProps) {
  const router = useRouter();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [fromPoint, setFromPoint] = useState<ResolvedAddress | null>(null);
  const [toPoint, setToPoint] = useState<ResolvedAddress | null>(null);
  const [fromEntrance, setFromEntrance] = useState("");
  const [toEntrance, setToEntrance] = useState("");
  const [stops, setStops] = useState<string[]>([]);
  const [stopPoints, setStopPoints] = useState<(ResolvedAddress | null)[]>([]);
  const [sheetOpen, setSheetOpen] = useState(true);
  const [mapExpanded, setMapExpanded] = useState(true);
  const [fitSignal, setFitSignal] = useState(0);
  const [activeSlot, setActiveSlot] = useState<PickSlot>("from");
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [locateSignal, setLocateSignal] = useState(0);
  const [sheetStep, setSheetStep] = useState<"main" | "call" | "confirmed">(
    "main"
  );
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);
  const [calling, setCalling] = useState(false);
  const [callDriver, setCallDriver] = useState<Driver | null>(null);
  const [callOrderId, setCallOrderId] = useState<string | null>(null);
  const [callStep, setCallStep] = useState<
    "question" | "agreed" | "declined" | "submitted" | null
  >(null);
  const [reviewText, setReviewText] = useState("");
  const [sendingReview, setSendingReview] = useState(false);
  const driverNotifiedRef = useRef(false);
  const timeoutNotifiedRef = useRef(false);
  const driverWaitingNotifiedRef = useRef<string | null>(null);
  const completedNotifiedRef = useRef(false);

  useEffect(() => {
    if (!open) return;
    setSheetStep(initialAction === "call" ? "call" : "main");
    setMapExpanded(true);
    setFitSignal((s) => s + 1);
    const settle = setTimeout(() => setFitSignal((s) => s + 1), 400);
    // Полностью запираем прокрутку страницы на время работы окна: и на
    // корне документа (html), и на body. На iOS Safari `overflow: hidden` на
    // body не останавливает прокрутку корня, и если страница прокручена,
    // fixed-слой окна (привязанный к initial containing block выше видимой
    // области) уезжает вниз вместе с картой. `overscroll-behavior: none` не
    // даёт цепочке прокрутки перекидываться на корень, а attempted scroll —
    // увести слой. Все значения возвращаются при закрытии окна.
    const prevOverflow = document.documentElement.style.overflow;
    const prevOverscroll = document.documentElement.style.overscrollBehavior;
    const prevBodyOverflow = document.body.style.overflow;
    const prevBodyOverscroll = document.body.style.overscrollBehavior;
    document.documentElement.style.overflow = "hidden";
    document.documentElement.style.overscrollBehavior = "none";
    document.body.style.overflow = "hidden";
    document.body.style.overscrollBehavior = "none";
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => {
      document.documentElement.style.overflow = prevOverflow;
      document.documentElement.style.overscrollBehavior = prevOverscroll;
      document.body.style.overflow = prevBodyOverflow;
      document.body.style.overscrollBehavior = prevBodyOverscroll;
      window.removeEventListener("keydown", onKey);
      clearTimeout(settle);
    };
  }, [open, initialAction, onClose]);

  const handleSlotChange = useCallback((slot: PickSlot) => {
    setActiveSlot(slot);
  }, []);

  const handleSlotPick = useCallback(
    (slot: PickSlot, res: ResolvedAddress | null) => {
      if (!res) return;
      if (slot === "from") {
        setFrom(res.address);
        setFromPoint(res);
      } else if (slot === "to") {
        setTo(res.address);
        setToPoint(res);
      } else {
        const idx = Number(slot.split(":")[1]);
        setStops((prev) => {
          const next = [...prev];
          next[idx] = res.address;
          return next;
        });
        setStopPoints((prev) => {
          const next = [...prev];
          next[idx] = res;
          return next;
        });
      }
    },
    []
  );

  const handleLocate = useCallback((res: ResolvedAddress | null) => {
    if (!res) return;
    setFrom(res.address);
    setFromPoint(res);
  }, []);

  /**
   * Кнопка «Найти меня»: запрашиваем геолокацию прямо в рамках жеста
   * пользователя. На iOS (iPhone) браузер показывает запрос разрешения на
   * геолокацию только при вызове getCurrentPosition из обработчика касания —
   * через отложенный эффект запрос не сработает. Полученные координаты сразу
   * сохраняем, чтобы LiveMap мог отцентрировать карту и заполнить адрес
   * «Откуда» даже если повторный запрос координат мгновенно не вернётся.
   */
  const handleFindMe = useCallback(async () => {
    try {
      const position = await getCurrentPosition();
      savePosition(position);
      setLocateSignal((s) => s + 1);
    } catch {
      if (getSavedPosition()) {
        setLocateSignal((s) => s + 1);
      } else {
        toast.error("Не удалось определить ваше местоположение");
      }
    }
  }, []);

  const handleStopPick = useCallback(
    (index: number, res: ResolvedAddress | null) => {
      handleSlotPick(`stop:${index}`, res);
    },
    [handleSlotPick]
  );

  const addStop = useCallback(() => {
    setStops((prev) => [...prev, ""]);
    setStopPoints((prev) => [...prev, null]);
    setActiveSlot(`stop:${stops.length}`);
  }, [stops.length]);

  const removeStop = useCallback((index: number) => {
    setStops((prev) => prev.filter((_, i) => i !== index));
    setStopPoints((prev) => prev.filter((_, i) => i !== index));
    setActiveSlot((prev) => {
      const prevIdx = Number((prev as string).split(":")[1]);
      if (prev === `stop:${index}`) return "from";
      if (prev.startsWith("stop:") && prevIdx > index) {
        return `stop:${prevIdx - 1}`;
      }
      return prev;
    });
  }, []);

  const handleFromResolve = useCallback((res: ResolvedAddress | null) => {
    setFromPoint(res);
  }, []);

  const handleToResolve = useCallback((res: ResolvedAddress | null) => {
    setToPoint(res);
  }, []);

  const handleSwap = useCallback(() => {
    setFrom(to);
    setTo(from);
    setFromPoint(toPoint);
    setToPoint(fromPoint);
  }, [from, to, fromPoint, toPoint]);

  async function handleSubmitOrder(e: React.FormEvent) {
    e.preventDefault();
    const stopsPayload = stops
      .map((address, i) => ({
        address: address.trim(),
        lat: stopPoints[i]?.lat,
        lng: stopPoints[i]?.lng,
      }))
      .filter((stop) => stop.address.length > 0);
    const parsed = createOrderSchema.safeParse({
      from,
      to,
      fromAddress: fromPoint?.address,
      toAddress: toPoint?.address,
      fromEntrance: looksLikeBuildingAddress(from)
        ? fromEntrance.trim() || undefined
        : undefined,
      toEntrance: looksLikeBuildingAddress(to)
        ? toEntrance.trim() || undefined
        : undefined,
      fromLat: fromPoint?.lat,
      fromLng: fromPoint?.lng,
      toLat: toPoint?.lat,
      toLng: toPoint?.lng,
      stops: stopsPayload.length > 0 ? stopsPayload : undefined,
      clientName,
      clientPhone,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Укажите корректные точки маршрута");
      return;
    }

    setSubmitting(true);
    const id = toast.loading("Оформляем заказ...");
    void maybeRequestNotificationPermission();
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast.error(data?.error ?? "Не удалось оформить заказ", { id });
        return;
      }
      const order: Order = await res.json();
      toast.success("Заказ оформлен", { id });
      router.push(`/track?id=${encodeURIComponent(order.id)}`);
    } catch (err) {
      console.error("Ошибка оформления заказа:", err);
      toast.error("Не удалось оформить заказ", { id });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleCallDriver() {
    const parsed = createCallOrderSchema.safeParse({
      clientName,
      clientPhone,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Укажите контактные данные");
      return;
    }
    setCalling(true);
    const id = toast.loading("Ищем свободного водителя...");
    void maybeRequestNotificationPermission();
    try {
      const res = await fetch("/api/orders/call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      const driver = data?.driver;
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось найти водителя", { id });
        return;
      }
      if (!driver?.phone) {
        toast.error("Никого нет сейчас", { id });
        return;
      }
      const orderId = data?.order?.id ?? null;
      const orderNumber = orderId
        ? ` Заказ №${formatOrderNumber(orderId)}.`
        : "";
      toast.success(`Связываем вас с свободным водителем.${orderNumber}`, {
        id,
      });
      setCallDriver(driver as Driver);
      setCallOrderId(orderId);
      setReviewText("");
      window.location.href = `tel:${driver.phone}`;
      if (orderId) {
        router.push(`/track?id=${encodeURIComponent(orderId)}`);
      } else {
        setCallStep("question");
      }
    } catch (err) {
      console.error("Ошибка вызова водителя:", err);
      toast.error("Никого нет сейчас", { id });
    } finally {
      setCalling(false);
    }
  }

  function resetCallFlow() {
    setCallDriver(null);
    setCallOrderId(null);
    setCallStep(null);
    setReviewText("");
  }

  async function handleSubmitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!callDriver) return;
    const parsed = createCallReviewSchema.safeParse({
      orderId: callOrderId ?? undefined,
      driverId: callDriver.id,
      driverName: callDriver.name,
      clientName: clientName.trim() || undefined,
      clientPhone: clientPhone.trim() || undefined,
      review: reviewText,
    });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast.error(first?.message ?? "Опишите причину");
      return;
    }
    setSendingReview(true);
    const id = toast.loading("Отправляем отзыв...");
    try {
      const res = await fetch("/api/call-reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось отправить отзыв", { id });
        return;
      }
      toast.success("Спасибо за отзыв", { id });
      setCallStep("submitted");
    } catch (err) {
      console.error("Ошибка отправки отзыва:", err);
      toast.error("Не удалось отправить отзыв", { id });
    } finally {
      setSendingReview(false);
    }
  }

  useEffect(() => {
    if (!confirmedOrderId) return;

    const orderId = confirmedOrderId;
    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | null = null;

    async function poll() {
      try {
        const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}`);
        if (!res.ok) return;
        const next: Order = await res.json();
        if (cancelled) return;

        const arrived =
          (next.status === OrderStatus.ASSIGNED ||
            next.status === OrderStatus.IN_PROGRESS) &&
          (next.driver?.carMake || next.driver?.carNumber);
        if (arrived && !driverNotifiedRef.current) {
          driverNotifiedRef.current = true;
          const message = `К Вам приедет ${carArrivalLabel(next.driver)}`;
          toast.success(message);
          showBrowserNotification(message);
        }

        if (
          next.driverWaitingAt &&
          driverWaitingNotifiedRef.current !== next.driverWaitingAt
        ) {
          driverWaitingNotifiedRef.current = next.driverWaitingAt;
          toast.success("Водитель ожидает вас");
          showBrowserNotification("Водитель ожидает вас");
        }

        if (
          next.status === OrderStatus.COMPLETED &&
          !completedNotifiedRef.current
        ) {
          completedNotifiedRef.current = true;
          toast.success("Поездка выполнена");
          showBrowserNotification("Поездка выполнена");
        }

        const elapsed = Date.now() - new Date(next.createdAt).getTime();
        if (
          next.status === OrderStatus.WAITING &&
          !timeoutNotifiedRef.current &&
          elapsed >= NO_DRIVER_TIMEOUT_MS
        ) {
          timeoutNotifiedRef.current = true;
          const message =
            "К сожалению, на линии временно никого нет, попробуйте через чат ВКонтакте";
          toast.warning(message);
          showBrowserNotification(message);
        }

        setConfirmedOrder((prev) => (prev?.id === next.id ? next : prev));

        if (
          (next.status === OrderStatus.COMPLETED ||
            next.status === OrderStatus.CANCELLED) &&
          timer
        ) {
          clearInterval(timer);
          timer = null;
        }
      } catch {
        // Временные ошибки поллинга безопасно игнорировать
      }
    }

    poll();
    timer = setInterval(poll, POLL_INTERVAL_MS);

    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
    };
  }, [confirmedOrderId]);

  const estimate = estimateTrip(fromPoint, toPoint);
  const tariff = getCityTariff();
  const hasRoute = Boolean(from.trim() && to.trim());
  const callCarLabel = callDriver
    ? [callDriver.carMake, callDriver.carNumber].filter(Boolean).join(", ") ||
      "Автомобиль не указан"
    : "";

  if (!open) return null;

  // Полноэкранное окно рендерится в портал на document.body: на iOS (iPhone)
  // так устраняются сбои `position: fixed` от предков/изменения масштаба
  // страницы. Пока окно открыто, прокрутка корня/body запирается (см. эффект
  // выше), а html/body имеют высоту окна — поэтому fixed-слой всегда стоит
  // на месте и не уезжает вниз.
  // Раскладка — слой слоёв с картой-фоном на весь экран:
  //  1) карта — абсолютный слой на весь экран (фон); при разворачивании
  //     пересоздаётся/пересчитывается на полный экран, при сворачивании
  //     просто отключается (она никогда не уничтожается, поэтому повторное
  //     разворачивание не роняет карту — LiveMap восстанавливает её по
  //     fitSignal);
  //  2) верхняя панель — форма ручного ввода «Откуда»/«Куда», поверх карты;
  //  3) нижняя шторка — карточка заказа, поверх карты.
  const overlay = (
    <div className="overlay-fullscreen z-[60] flex touch-manipulation flex-col overflow-hidden bg-muted">
      {/* Карта — фон на весь экран. При сворачивании (mapExpanded=false) слой
          прячется на весь экран, а не уничтожается: повторное разворачивание
          той же кнопкой снова показывает карту на весь экран, LiveMap сам
          пересоздаёт/пересчитывает проекцию по fitSignal. */}
      <div
        className={cn(
          "absolute inset-0 z-0 transition-opacity duration-300 ease-out",
          !mapExpanded && "pointer-events-none opacity-0"
        )}
      >
        <LiveMap
          from={from}
          to={to}
          stops={stops}
          carClass="econom"
          activeSlot={activeSlot}
          locateSignal={locateSignal}
          fitSignal={fitSignal}
          onSlotChange={handleSlotChange}
          onFromResolve={handleFromResolve}
          onToResolve={handleToResolve}
          onFromPick={(res) => handleSlotPick("from", res)}
          onToPick={(res) => handleSlotPick("to", res)}
          onStopPick={handleStopPick}
          onLocate={handleLocate}
        />
      </div>

      {/* Строка поиска / маршрут — верхняя панель поверх карты */}
      <div className="relative z-20 shrink-0 px-3 pt-[calc(env(safe-area-inset-top)+0.75rem)] sm:mx-auto sm:w-full sm:max-w-lg sm:px-0">
        <div className="rounded-2xl bg-white p-3 shadow-xl ring-1 ring-black/10 animate-in fade-in slide-in-from-top-6 duration-500">
          <div className="flex items-start gap-2">
            <div className="min-w-0 flex-1">
              <div className="flex items-start gap-2">
                <div className="flex flex-col items-center py-0.5">
                  <span className="h-3 w-3 rounded-full bg-emerald-500" />
                  <span className="my-1.5 w-0.5 flex-1 border-l-2 border-dashed border-muted-foreground/30" />
                  <span className="h-3 w-3 rounded-full bg-destructive" />
                </div>

                <div className="min-w-0 flex-1 space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="min-w-0 flex-1">
                      <AddressInput
                        id="window-from"
                        label="Откуда"
                        value={from}
                        placeholder="Откуда"
                        onValueChange={(v) => {
                          setFrom(v);
                          setFromPoint(null);
                        }}
                      />
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleFindMe}
                      className="shrink-0 gap-1.5 rounded-full px-3.5"
                    >
                      <Crosshair className="size-4" />
                      Найти меня
                    </Button>
                  </div>

                  {stops.map((stop, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <div className="min-w-0 flex-1">
                        <AddressInput
                          id={`window-stop-${i}`}
                          label={`Остановка ${i + 1}`}
                          value={stop}
                          placeholder="Промежуточный адрес"
                          onValueChange={(v) => {
                            setStops((prev) => {
                              const next = [...prev];
                              next[i] = v;
                              return next;
                            });
                          }}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeStop(i)}
                        aria-label="Удалить остановку"
                        title="Удалить остановку"
                        className="self-center rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  ))}

                  <AddressInput
                    id="window-to"
                    label="Куда"
                    value={to}
                    placeholder="Куда"
                    onValueChange={(v) => {
                      setTo(v);
                      setToPoint(null);
                    }}
                  />
                </div>

                <button
                  type="button"
                  onClick={handleSwap}
                  aria-label="Поменять местами"
                  title="Поменять местами"
                  className="self-center rounded-full bg-muted/70 p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                >
                  <ArrowUpDown className="size-4" />
                </button>
              </div>

              <div className="mt-2.5 flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Navigation className="size-3.5 shrink-0 text-primary" />
                  Кликните по карте: точка
                </span>
                <div className="flex flex-wrap items-center gap-1 rounded-full bg-muted/70 p-0.5">
                  <button
                    type="button"
                    onClick={() => handleSlotChange("from")}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition-colors",
                      activeSlot === "from"
                        ? "bg-emerald-600 text-white"
                        : "text-foreground hover:bg-muted"
                    )}
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-current" />
                    Откуда
                  </button>
                  {stops.map((_, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleSlotChange(`stop:${i}`)}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition-colors",
                        activeSlot === `stop:${i}`
                          ? "bg-primary text-white"
                          : "text-foreground hover:bg-muted"
                      )}
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-current" />
                      {i + 1}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => handleSlotChange("to")}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition-colors",
                      activeSlot === "to"
                        ? "bg-destructive text-white"
                        : "text-foreground hover:bg-muted"
                    )}
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-current" />
                    Куда
                  </button>
                </div>
                <button
                  type="button"
                  onClick={addStop}
                  className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary transition-colors hover:bg-primary/20"
                >
                  <Plus className="size-3.5" />
                  Добавить адрес
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Кнопка сворачивания/разворачивания карты — заметная, в потоке сразу
          под формой «Откуда»/«Куда», поэтому никогда не перекрывается шторкой
          и не мешает вводу. При сворачивании карта прячется с экрана, а форма
          и шторка остаются доступными; при разворачивании карта снова
          занимает весь экран как фон. */}
      <div className="relative z-20 -mt-2.5 flex justify-center px-3 sm:px-0">
        <button
          type="button"
          onClick={() => {
            setMapExpanded((m) => !m);
            setFitSignal((s) => s + 1);
          }}
          aria-expanded={mapExpanded}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/95 px-4 py-1.5 text-sm font-semibold text-foreground shadow-xl ring-1 ring-black/10 backdrop-blur transition-colors hover:bg-white"
        >
          {mapExpanded ? (
            <Minimize2 className="size-4 text-primary" />
          ) : (
            <Maximize2 className="size-4 text-primary" />
          )}
          {mapExpanded ? "Свернуть карту" : "Развернуть карту"}
        </button>
      </div>

      {/* Нижняя шторка — карточка заказа, поверх карты (в потоке внизу по
          факту визуально перекрывается, но раскладка управляет её площадью:
          развёрнутая карта — фон за всей шторкой). */}
      <div className="relative z-20 mx-auto mt-auto w-full max-w-lg shrink-0 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] sm:px-0 sm:pb-[max(env(safe-area-inset-bottom),0.75rem)]">
        <div
          className={cn(
            "rounded-t-3xl rounded-b-xl bg-white shadow-2xl ring-1 ring-black/10 animate-in fade-in slide-in-from-bottom-8 duration-500",
            sheetOpen
              ? "max-h-[62vh] max-h-[62dvh] overflow-y-auto p-4 sm:p-5"
              : "p-2"
          )}
        >
          <button
            type="button"
            onClick={() => {
              setSheetOpen((o) => !o);
              setFitSignal((s) => s + 1);
            }}
            className="mx-auto flex items-center gap-1.5 rounded-full bg-muted/70 px-3.5 py-1 text-xs font-medium text-foreground transition-colors hover:bg-muted"
            aria-expanded={sheetOpen}
          >
            {sheetOpen ? (
              <ChevronDown className="size-4" />
            ) : (
              <ChevronUp className="size-4" />
            )}
            {sheetOpen ? "Свернуть карточку" : "Развернуть карточку"}
          </button>

          {!sheetOpen ? (
            <div className="mt-2 flex items-center justify-between gap-2 px-1 text-sm">
              <div className="min-w-0 flex-1 truncate">
                <span className="font-medium">{from || "Откуда"}</span>
                {stops.length > 0 && (
                  <span className="text-muted-foreground">
                    {" "}
                    · {stops.length} ост.
                  </span>
                )}
                <span className="mx-1.5 text-muted-foreground">→</span>
                <span className="font-medium">{to || "Куда"}</span>
              </div>
              <span className="shrink-0 whitespace-nowrap font-semibold text-primary">
                {`${tariff.price}₽ ${tariff.period}`}
              </span>
            </div>
          ) : (
            <div className="pt-3">
              {sheetStep === "confirmed" && confirmedOrder ? (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-3 text-center">
                    <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                      <span className="absolute inset-0 rounded-full bg-emerald-500/10 animate-ping opacity-40" />
                      <CheckCircle2 className="size-8" />
                    </div>
                    <h2 className="text-xl font-bold tracking-tight">
                      Заказ оформлен
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Ваш заказ отправлен в очередь для водителей. Водитель
                      скоро его примет.
                    </p>
                  </div>

                  <RouteCard
                    from={confirmedOrder.from}
                    to={confirmedOrder.to}
                    fromEntrance={confirmedOrder.fromEntrance}
                    toEntrance={confirmedOrder.toEntrance}
                    stops={confirmedOrder.stops}
                  />

                  <OrderTimeline status={confirmedOrder.status} />

                  {(confirmedOrder.driver || confirmedOrder.driverName) && (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                      <DriverCard order={confirmedOrder} />
                    </div>
                  )}

                  <div className="flex items-center justify-between rounded-xl border bg-muted/40 px-4 py-3 text-sm">
                    <span className="text-muted-foreground">Номер заказа</span>
                    <span className="font-mono font-semibold">
                      №{formatOrderNumber(confirmedOrder.id)}
                    </span>
                  </div>

                  <div className="grid gap-2">
                    <Button
                      className="group/btn w-full gap-2"
                      onClick={() =>
                        router.push(
                          `/track?id=${encodeURIComponent(confirmedOrder.id)}`
                        )
                      }
                    >
                      <MapPin className="size-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
                      Отслеживать статус заказа
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setSheetStep("main");
                        setConfirmedOrder(null);
                        setConfirmedOrderId(null);
                        setFrom("");
                        setTo("");
                        setFromPoint(null);
                        setToPoint(null);
                        setStops([]);
                        setStopPoints([]);
                        setActiveSlot("from");
                        driverNotifiedRef.current = false;
                        timeoutNotifiedRef.current = false;
                        driverWaitingNotifiedRef.current = null;
                        completedNotifiedRef.current = false;
                      }}
                    >
                      Оформить ещё один заказ
                    </Button>
                  </div>
                </div>
              ) : sheetStep === "call" && callDriver && callStep ? (
                <div className="space-y-4">
                  {callStep === "question" && (
                    <>
                      <div className="flex flex-col items-center gap-3 text-center">
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                          <PhoneCall className="size-7" />
                        </div>
                        <h2 className="text-xl font-bold tracking-tight">
                          Вы договорились с водителем?
                        </h2>
                        <p className="text-sm text-muted-foreground">
                          Мы соединили вас с водителем. Подтвердите, удалось ли
                          договориться о поездке.
                        </p>
                      </div>

                      <div className="grid gap-2">
                        <Button
                          className="group/btn w-full gap-2"
                          onClick={() => setCallStep("agreed")}
                        >
                          <CheckCircle2 className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                          Да, договорились
                        </Button>
                        <Button
                          variant="outline"
                          className="group/btn w-full gap-2"
                          onClick={() => setCallStep("declined")}
                        >
                          <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                          Нет, не получилось
                        </Button>
                      </div>
                    </>
                  )}

                  {callStep === "agreed" && (
                    <>
                      <div className="flex flex-col items-center gap-3 text-center">
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                          <CheckCircle2 className="size-8" />
                        </div>
                        <h2 className="text-xl font-bold tracking-tight">
                          Машина приедет
                        </h2>
                        <p className="text-sm text-muted-foreground">
                          Ожидайте автомобиль. Время ожидания — 5–7 минут.
                        </p>
                      </div>

                      <div className="space-y-3 rounded-2xl border bg-gradient-to-br from-card to-accent/40 p-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                            <CarFront className="size-5" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs text-muted-foreground">
                              Какая машина приедет
                            </p>
                            <p className="truncate font-semibold">
                              {callCarLabel}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                            <User className="size-5" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs text-muted-foreground">
                              Водитель
                            </p>
                            <p className="truncate font-semibold">
                              {callDriver.name}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="grid gap-2">
                        <Button
                          className="group/btn w-full gap-2"
                          onClick={() => {
                            window.location.href = `tel:${callDriver.phone}`;
                          }}
                        >
                          <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                          Связаться с этим водителем повторно
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            resetCallFlow();
                            setSheetStep("main");
                          }}
                        >
                          Вернуться к заказу
                        </Button>
                      </div>
                    </>
                  )}

                  {callStep === "declined" && (
                    <form onSubmit={handleSubmitReview} className="space-y-4">
                      <div className="flex flex-col items-center gap-3 text-center">
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
                          <Phone className="size-7" />
                        </div>
                        <h2 className="text-xl font-bold tracking-tight">
                          Расскажите, почему не удалось вызвать машину?
                        </h2>
                        <p className="text-sm text-muted-foreground">
                          Ваш отзыв поможет нам улучшить сервис.
                        </p>
                      </div>

                      <div className="space-y-1.5">
                        <Label htmlFor="window-review" className="sr-only">
                          Причина
                        </Label>
                        <Textarea
                          id="window-review"
                          placeholder="Например: водитель не ответил, не приехал вовремя..."
                          value={reviewText}
                          maxLength={1000}
                          onChange={(e) => setReviewText(e.target.value)}
                          required
                        />
                      </div>

                      <div className="grid gap-2">
                        <Button
                          type="submit"
                          className="w-full gap-2"
                          disabled={sendingReview}
                        >
                          <Send className="size-4" />
                          {sendingReview ? "Отправляем..." : "Отправить отзыв"}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            resetCallFlow();
                            setSheetStep("main");
                          }}
                        >
                          Отмена
                        </Button>
                      </div>
                    </form>
                  )}

                  {callStep === "submitted" && (
                    <div className="space-y-4">
                      <div className="flex flex-col items-center gap-3 text-center">
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                          <CheckCircle2 className="size-8" />
                        </div>
                        <h2 className="text-xl font-bold tracking-tight">
                          Спасибо за отзыв
                        </h2>
                        <p className="text-sm text-muted-foreground">
                          Мы передали ваш ответ администратору.
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                          resetCallFlow();
                          setSheetStep("main");
                        }}
                      >
                        Вернуться к заказу
                      </Button>
                    </div>
                  )}
                </div>
              ) : sheetStep === "call" ? (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-3 text-center">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <PhoneCall className="size-7" />
                    </div>
                    <h2 className="text-xl font-bold tracking-tight">
                      Вызов свободного водителя
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Свяжем вас с водителем, который сейчас на линии. Адреса не
                      нужны.
                    </p>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="space-y-1">
                      <Label htmlFor="window-call-name">
                        Имя (необязательно)
                      </Label>
                      <Input
                        id="window-call-name"
                        placeholder="Как вас зовут?"
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="window-call-phone">
                        Телефон (необязательно)
                      </Label>
                      <Input
                        id="window-call-phone"
                        type="tel"
                        placeholder="+7 ___ ___-__-__"
                        value={clientPhone}
                        onChange={(e) => setClientPhone(e.target.value)}
                      />
                    </div>
                  </div>

                  <Button
                    type="button"
                    className="group/btn w-full gap-2 shadow-warm-sm"
                    size="lg"
                    disabled={calling}
                    onClick={handleCallDriver}
                  >
                    <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                    {calling ? "Ищем..." : "Найти свободного водителя"}
                  </Button>

                  <Button
                    variant="ghost"
                    className="w-full"
                    onClick={() => setSheetStep("main")}
                  >
                    Назад к заказу
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmitOrder} className="space-y-4">
                  {/* Маршрут */}
                  <div className="rounded-2xl border bg-muted/40 p-3">
                    <div className="flex items-center gap-2.5">
                      <div className="flex flex-col items-center gap-1 py-0.5">
                        <span className="h-2 w-2 rounded-full bg-emerald-500" />
                        <span className="h-6 w-0.5 border-l border-dashed border-muted-foreground/40" />
                        <span className="h-2 w-2 rounded-full bg-destructive" />
                      </div>
                      <div className="min-w-0 flex-1 space-y-1 text-sm">
                        <p className="truncate font-medium">
                          {from || "Откуда — не указано"}
                        </p>
                        <p className="truncate text-muted-foreground">
                          {to || "Куда — не указано"}
                        </p>
                      </div>
                    </div>
                    {!hasRoute && (
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Navigation className="size-3.5 shrink-0 text-primary" />
                        Укажите точки маршрута, чтобы увидеть время поездки.
                      </p>
                    )}
                  </div>

                  {/* Тариф по городу — актуальная стоимость выделенным шрифтом */}
                  <div className="rounded-xl border bg-primary/5 px-4 py-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground">
                          Поездка по городу
                          {estimate ? ` · ~${estimate} мин` : ""}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {tariff.window}
                        </p>
                      </div>
                      <span className="whitespace-nowrap text-2xl font-extrabold tracking-tight text-primary">
                        {`${tariff.price}₽ ${tariff.period}`}
                      </span>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Пригородные и загородные тарифы уточняйте у водителя
                  </p>
                  <p className="mt-1 text-xs font-medium text-foreground">
                    Доставка 350₽
                  </p>

                  {/* Контакты */}
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="space-y-1">
                      <Label htmlFor="window-name">Имя (необязательно)</Label>
                      <Input
                        id="window-name"
                        placeholder="Как вас зовут?"
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="window-phone">
                        Телефон (необязательно)
                      </Label>
                      <Input
                        id="window-phone"
                        type="tel"
                        placeholder="+7 ___ ___-__-__"
                        value={clientPhone}
                        onChange={(e) => setClientPhone(e.target.value)}
                      />
                    </div>
                  </div>

                  {looksLikeBuildingAddress(from) && (
                    <div className="space-y-1">
                      <Label htmlFor="window-from-entrance">
                        Подъезд (если есть)
                      </Label>
                      <Input
                        id="window-from-entrance"
                        inputMode="text"
                        maxLength={10}
                        placeholder="Подъезд у точки «откуда»"
                        value={fromEntrance}
                        onChange={(e) => setFromEntrance(e.target.value)}
                      />
                    </div>
                  )}
                  {looksLikeBuildingAddress(to) && (
                    <div className="space-y-1">
                      <Label htmlFor="window-to-entrance">
                        Подъезд (если есть)
                      </Label>
                      <Input
                        id="window-to-entrance"
                        inputMode="text"
                        maxLength={10}
                        placeholder="Подъезд у точки «куда»"
                        value={toEntrance}
                        onChange={(e) => setToEntrance(e.target.value)}
                      />
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="group/btn w-full gap-2 shadow-warm-sm"
                    size="lg"
                    disabled={submitting || !hasRoute}
                  >
                    {submitting ? (
                      <span className="flex items-center gap-2">
                        <MapPin className="size-4 animate-pulse" />
                        Оформляем...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Navigation className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                        Заказать {estimate ? `за ${tariff.price}₽` : "машину"}
                      </span>
                    )}
                  </Button>

                  <div className="grid gap-2 sm:grid-cols-2">
                    <Button
                      type="button"
                      variant="outline"
                      className="group/btn w-full gap-2"
                      size="lg"
                      onClick={() => setSheetStep("call")}
                    >
                      <Phone className="size-4 transition-transform duration-300 group-hover/btn:-rotate-12" />
                      Вызвать по телефону
                    </Button>
                    <a
                      href={VK_CHAT_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={cn(
                        buttonVariants({ variant: "outline", size: "lg" }),
                        "group/btn w-full gap-2"
                      )}
                    >
                      <VkIcon className="size-4 transition-transform duration-300 group-hover/btn:scale-110" />
                      Через Чат
                    </a>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Кнопка закрытия — поверх карты, не перекрывает верхнюю панель */}
      <button
        type="button"
        onClick={onClose}
        aria-label="Закрыть"
        className="absolute right-3 top-[calc(env(safe-area-inset-top)+0.75rem)] z-30 inline-flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-foreground shadow-lg ring-1 ring-black/5 backdrop-blur transition-colors hover:bg-white"
      >
        <X className="size-5" />
      </button>
    </div>
  );

  return typeof document === "undefined"
    ? null
    : createPortal(overlay, document.body);
}
