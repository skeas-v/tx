"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CarFront, Phone } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { VkIcon } from "@/components/vk-icon";
import { VK_CHAT_URL } from "@/lib/links";
import { cn } from "@/lib/utils";

export function HomeScreen() {
  const router = useRouter();

  return (
    <div className="relative overflow-hidden">
      <div className="gradient-hero-vibrant absolute inset-0" />
      <div className="pattern-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_top,black_25%,transparent_70%)]" />

      <div className="relative container mx-auto flex min-h-[calc(100dvh-3.5rem)] flex-col items-center justify-center gap-8 px-4 py-12 text-center">
        <div className="flex flex-col items-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl bg-white/80 shadow-warm-sm ring-1 ring-primary/20 backdrop-blur">
            <Image
              src="/assets/logo.png"
              alt="Логотип сервиса поездок"
              width={256}
              height={256}
              className="h-full w-full object-cover"
            />
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Твоё Новое
            </h1>
            <p className="mx-auto max-w-md text-sm text-muted-foreground sm:text-base">
              Быстрый заказ поездки в Кирово-Чепецке: свободные машины рядом с
              вами — на карте в реальном времени.
            </p>
          </div>
        </div>

        <div className="flex w-full max-w-sm flex-col gap-3 animate-in fade-in slide-in-from-bottom-6 duration-700">
          <Link
            href="/order"
            className={cn(
              buttonVariants({ size: "lg" }),
              "group/btn w-full gap-2 py-6 text-base shadow-warm"
            )}
          >
            <CarFront className="size-5 transition-transform duration-300 group-hover/btn:-translate-y-0.5" />
            Заказать
          </Link>

          <div className="grid grid-cols-2 gap-3">
            <a
              href={VK_CHAT_URL}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                buttonVariants({ variant: "outline", size: "lg" }),
                "group/btn w-full gap-2 py-5 bg-white/70 backdrop-blur"
              )}
            >
              <VkIcon className="size-5 transition-transform duration-300 group-hover/btn:scale-110" />
              Чат ВК
            </a>
            <Button
              variant="outline"
              size="lg"
              className="group/btn w-full gap-2 py-5 bg-white/70 backdrop-blur"
              onClick={() => router.push("/order/call")}
            >
              <Phone className="size-5 transition-transform duration-300 group-hover/btn:-rotate-12" />
              Позвонить
            </Button>
          </div>

          <p className="pt-2 text-xs text-muted-foreground">
            Отследить заказ можно на странице «Отследить заказ» в шапке сайта.
          </p>
        </div>
      </div>
    </div>
  );
}
