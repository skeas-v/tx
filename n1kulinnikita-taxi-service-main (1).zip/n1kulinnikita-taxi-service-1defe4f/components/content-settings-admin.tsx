"use client";

import { useCallback, useEffect, useState } from "react";
import { BookOpenText, Save, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";

interface ContentSettings {
  rulesText: string;
  privacyText: string;
}

export function ContentSettingsAdmin() {
  const [form, setForm] = useState<ContentSettings>({
    rulesText: "",
    privacyText: "",
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/content");
      if (res.ok) {
        const data = (await res.json()) as ContentSettings;
        setForm({
          rulesText: data.rulesText ?? "",
          privacyText: data.privacyText ?? "",
        });
      }
    } catch (error) {
      console.error("Ошибка загрузки текстов правил и политики:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const id = toast.loading("Сохраняем тексты...");
    try {
      const res = await fetch("/api/admin/content", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rulesText: form.rulesText,
          privacyText: form.privacyText,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось сохранить тексты", { id });
        return;
      }
      toast.success("Тексты правил и политики сохранены", { id });
    } catch (error) {
      console.error("Ошибка сохранения текстов:", error);
      toast.error("Не удалось сохранить тексты", { id });
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-2xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <form onSubmit={handleSave} className="space-y-4">
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <BookOpenText className="size-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">Правила пользования</h2>
              <p className="text-xs text-muted-foreground">
                Текст отображается на странице «Правила пользования».
              </p>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rules-text">Текст правил</Label>
            <Textarea
              id="rules-text"
              rows={10}
              maxLength={50_000}
              placeholder="Введите правила пользования..."
              value={form.rulesText}
              onChange={(e) => setForm({ ...form, rulesText: e.target.value })}
            />
            <p className="text-xs text-muted-foreground">
              Поддерживается обычный текст с переносами строк.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <ShieldCheck className="size-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">
                Политика конфиденциальности
              </h2>
              <p className="text-xs text-muted-foreground">
                Текст отображается на странице «Политика конфиденциальности».
              </p>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="privacy-text">Текст политики</Label>
            <Textarea
              id="privacy-text"
              rows={10}
              maxLength={50_000}
              placeholder="Введите политику конфиденциальности..."
              value={form.privacyText}
              onChange={(e) =>
                setForm({ ...form, privacyText: e.target.value })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Button type="submit" className="gap-2" disabled={saving}>
        <Save className="size-4" />
        {saving ? "Сохраняем..." : "Сохранить тексты"}
      </Button>
    </form>
  );
}
