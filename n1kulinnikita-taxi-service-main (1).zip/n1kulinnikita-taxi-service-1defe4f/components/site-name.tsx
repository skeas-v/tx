"use client";

import { useEffect, useState } from "react";

interface PublicSettings {
  siteName?: string;
  maintenanceMode?: boolean;
}

export function SiteName({ fallback = "Твоё Новое" }: { fallback?: string }) {
  const [name, setName] = useState(fallback);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/settings")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: PublicSettings | null) => {
        if (!cancelled && data?.siteName) {
          setName(data.siteName);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  return <>{name}</>;
}
