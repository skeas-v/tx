"use client";

import { useState } from "react";
import {
  AtSign,
  Mail,
  MessageSquareText,
  Phone,
  Send,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const PHONE_RE = /^[+0-9][0-9()\-\s]{5,}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function FeedbackForm() {
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  function validateContact(value: string): string {
    if (!value.trim()) return "Укажите номер телефона или почту";
    if (value.includes("@")) {
      if (!EMAIL_RE.test(value.trim())) return "Проверьте правильность почты";
    } else if (!PHONE_RE.test(value.trim())) {
      return "Проверьте правильность номера телефона";
    }
    return "";
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const contactError = validateContact(contact);
    if (contactError) {
      toast.error(contactError);
      return;
    }
    if (!message.trim()) {
      toast.error("Опишите ваш вопрос или предложение");
      return;
    }

    setSending(true);
    const id = toast.loading("Отправляем обращение...");
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim() || undefined,
          contact: contact.trim(),
          message: message.trim(),
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось отправить обращение", { id });
        return;
      }
      toast.success("Обращение отправлено. Спасибо!", { id });
      setName("");
      setContact("");
      setMessage("");
      setSent(true);
    } catch (error) {
      console.error("Ошибка отправки обращения:", error);
      toast.error("Не удалось отправить обращение", { id });
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/80 text-primary shadow-warm-sm ring-1 ring-primary/20 backdrop-blur">
          <MessageSquareText className="size-5" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Обратная связь
          </h1>
          <p className="text-sm text-muted-foreground">
            Оставьте вопрос, замечание или предложение — мы ответим вам.
          </p>
        </div>
      </div>

      <Card>
        <CardContent className="space-y-5 p-6">
          {sent ? (
            <div className="space-y-3 py-6 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Send className="size-6" />
              </div>
              <p className="font-medium">Ваше обращение отправлено</p>
              <p className="text-sm text-muted-foreground">
                Мы обязательно рассмотрим его и ответим вам в ближайшее время.
              </p>
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => setSent(false)}
              >
                <MessageSquareText className="size-4" />
                Отправить ещё одно обращение
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="feedback-name">
                  <span className="inline-flex items-center gap-1.5">
                    <User className="size-4 text-primary" />
                    Ваше имя
                  </span>
                </Label>
                <Input
                  id="feedback-name"
                  placeholder="Как к вам обращаться"
                  maxLength={100}
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="feedback-contact" className="font-semibold">
                  <span className="inline-flex items-center gap-1.5">
                    <AtSign className="size-4 text-primary" />
                    Телефон или почта{" "}
                    <span className="font-normal text-destructive">*</span>
                  </span>
                </Label>
                <Input
                  id="feedback-contact"
                  placeholder="+7 900 000-00-00 или name@example.com"
                  maxLength={100}
                  autoComplete="email"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Поле обязательно для заполнения — на него придёт наш ответ.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="feedback-message" className="font-semibold">
                  <span className="inline-flex items-center gap-1.5">
                    <MessageSquareText className="size-4 text-primary" />
                    Сообщение{" "}
                    <span className="font-normal text-destructive">*</span>
                  </span>
                </Label>
                <Textarea
                  id="feedback-message"
                  placeholder="Напишите ваш вопрос, замечание или предложение"
                  maxLength={5000}
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
              </div>

              <Button type="submit" className="w-full gap-2" disabled={sending}>
                <Send className="size-4" />
                {sending ? "Отправляем..." : "Отправить обращение"}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                Нажимая кнопку, вы соглашаетесь на обработку указанных данных в
                соответствии с политикой конфиденциальности.
              </p>
            </form>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Card size="sm">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Phone className="size-4" />
            </div>
            <div>
              <p className="text-sm font-medium">Позвонить</p>
              <p className="text-xs text-muted-foreground">
                Быстрый вызов водителя по телефону
              </p>
            </div>
          </CardContent>
        </Card>
        <Card size="sm">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Mail className="size-4" />
            </div>
            <div>
              <p className="text-sm font-medium">Ответим на почту</p>
              <p className="text-xs text-muted-foreground">
                Если указали почту — напишем на неё
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
