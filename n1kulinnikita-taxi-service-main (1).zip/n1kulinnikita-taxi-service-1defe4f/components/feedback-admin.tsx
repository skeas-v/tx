"use client";

import { useCallback, useEffect, useState } from "react";
import {
  AtSign,
  Clock,
  Inbox,
  MessageSquareText,
  Trash2,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface FeedbackItem {
  id: string;
  name?: string;
  contact: string;
  message: string;
  createdAt: string;
}

function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function EmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Icon className="size-6" />
      </div>
      <div className="space-y-1 px-6">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

export function FeedbackAdmin() {
  const [items, setItems] = useState<FeedbackItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/feedback");
      if (res.ok) {
        setItems((await res.json()) as FeedbackItem[]);
      }
    } catch (error) {
      console.error("Ошибка загрузки запросов обратной связи:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function handleDelete(id: string) {
    setDeleting(id);
    const toastId = toast.loading("Удаляем запрос...");
    try {
      const res = await fetch(`/api/feedback?id=${encodeURIComponent(id)}`, {
        method: "DELETE",
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error ?? "Не удалось удалить запрос", {
          id: toastId,
        });
        return;
      }
      setItems((prev) => prev.filter((item) => item.id !== id));
      toast.success("Запрос удалён", { id: toastId });
    } catch (error) {
      console.error("Ошибка удаления запроса:", error);
      toast.error("Не удалось удалить запрос", { id: toastId });
    } finally {
      setDeleting(null);
    }
  }

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Inbox className="size-5" />
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-semibold">Запросы</h2>
          <p className="text-xs text-muted-foreground">
            Сообщения клиентов, присланные через форму обратной связи.
          </p>
        </div>
        <Badge variant="outline">{items.length}</Badge>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[0, 1].map((i) => (
            <Skeleton key={i} className="h-28 w-full rounded-xl" />
          ))}
        </div>
      ) : items.length > 0 ? (
        <div className="grid gap-3">
          {items.map((item) => (
            <Card key={item.id} size="sm">
              <CardContent className="space-y-3 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    {item.name && (
                      <Badge variant="outline" className="gap-1.5">
                        <User className="size-3" />
                        {item.name}
                      </Badge>
                    )}
                    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-foreground">
                      <AtSign className="size-3.5 text-primary" />
                      {item.contact}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                    disabled={deleting === item.id}
                    onClick={() => handleDelete(item.id)}
                    aria-label="Удалить запрос"
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>

                <p className="whitespace-pre-line text-sm">{item.message}</p>

                <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="size-3.5" />
                    {formatDateTime(item.createdAt)}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={MessageSquareText}
          title="Запросов пока нет"
          description="Здесь появятся сообщения клиентов из формы обратной связи."
        />
      )}
    </section>
  );
}
