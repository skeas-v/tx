import { z } from "zod";

export const createFeedbackSchema = z.object({
  name: z.string().trim().max(100, "Имя слишком длинное").optional(),
  contact: z
    .string()
    .trim()
    .min(3, "Укажите номер телефона или почту")
    .max(100, "Контакт слишком длинный"),
  message: z
    .string()
    .trim()
    .min(1, "Опишите ваш вопрос или предложение")
    .max(5000, "Сообщение слишком длинное"),
});

export type CreateFeedbackInput = z.infer<typeof createFeedbackSchema>;
