import { z } from "zod";

export const updateSettingsSchema = z.object({
  siteName: z
    .string()
    .trim()
    .min(1, "Укажите название сайта")
    .max(100, "Название сайта слишком длинное"),
  maintenanceMode: z.boolean(),
  rulesText: z.string().max(50_000, "Текст правил слишком длинный").optional(),
  privacyText: z
    .string()
    .max(50_000, "Текст политики слишком длинный")
    .optional(),
  commissionPerOrder: z
    .number()
    .min(0, "Комиссия не может быть отрицательной")
    .max(1_000_000, "Комиссия слишком большая")
    .optional(),
});

export type UpdateSettingsInput = z.infer<typeof updateSettingsSchema>;
