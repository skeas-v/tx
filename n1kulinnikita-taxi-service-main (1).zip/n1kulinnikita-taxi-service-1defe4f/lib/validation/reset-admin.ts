import { z } from "zod";

export const resetAdminPasswordSchema = z.object({
  key: z.string().min(1, "Отсутствует ключ доступа"),
  password: z
    .string()
    .min(4, "Пароль должен быть не короче 4 символов")
    .max(100, "Пароль слишком длинный"),
});

export type ResetAdminPasswordInput = z.infer<typeof resetAdminPasswordSchema>;
