import { z } from "zod";

export const updateContentSettingsSchema = z.object({
  rulesText: z.string().max(50_000, "Текст правил слишком длинный").optional(),
  privacyText: z
    .string()
    .max(50_000, "Текст политики слишком длинный")
    .optional(),
});

export type UpdateContentSettingsInput = z.infer<
  typeof updateContentSettingsSchema
>;
