import { z } from "zod";

export const savePushSubscriptionSchema = z.object({
  endpoint: z.string().url().min(1, "Некорректный endpoint подписки"),
  keys: z.object({
    p256dh: z.string().min(1, "Некорректный ключ p256dh"),
    auth: z.string().min(1, "Некорректный ключ auth"),
  }),
  userAgent: z.string().trim().max(300).optional(),
});

export type SavePushSubscriptionInput = z.infer<
  typeof savePushSubscriptionSchema
>;

export const sendPushSchema = z.object({
  title: z.string().trim().max(100, "Заголовок слишком длинный").optional(),
  body: z
    .string()
    .trim()
    .min(1, "Введите текст уведомления")
    .max(2000, "Текст уведомления слишком длинный"),
});

export type SendPushInput = z.infer<typeof sendPushSchema>;
