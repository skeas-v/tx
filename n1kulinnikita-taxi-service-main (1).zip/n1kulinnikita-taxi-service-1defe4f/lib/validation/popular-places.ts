import { z } from "zod";

export const popularPlaceSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, "Укажите название места")
    .max(200, "Название места слишком длинное"),
  address: z
    .string()
    .trim()
    .max(300, "Адрес места слишком длинный")
    .optional()
    .transform((value) => (value ? value : undefined)),
  price: z
    .number()
    .int("Цена должна быть целым числом")
    .min(0, "Цена не может быть отрицательной")
    .max(1_000_000, "Цена слишком большая")
    .nullable()
    .optional(),
});

export type PopularPlaceInput = z.infer<typeof popularPlaceSchema>;
