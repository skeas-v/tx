import { z } from "zod";

export const createCallReviewSchema = z.object({
  orderId: z.string().trim().max(100).optional(),
  driverId: z.string().trim().max(100).optional(),
  driverName: z.string().trim().max(100).optional(),
  clientName: z.string().trim().max(100).optional(),
  clientPhone: z.string().trim().max(30).optional(),
  review: z.string().trim().min(1, "Опишите причину").max(1000),
});

export type CreateCallReviewInput = z.infer<typeof createCallReviewSchema>;
