import { z } from "zod";

// Действия над заказом в админ-панели:
// - cancel — «Отменить»: статус заказа становится cancelled;
// - release — «Снять с водителя»: driverId/driverName очищаются, заказ
//   возвращается в очередь (status: waiting), водитель больше не занят;
// - delete — «Удалить»: полное удаление заказа из БД (только разработчик).
export const AdminOrderAction = {
  CANCEL: "cancel",
  RELEASE: "release",
  DELETE: "delete",
} as const;

export type AdminOrderAction =
  (typeof AdminOrderAction)[keyof typeof AdminOrderAction];

export const adminOrderActionSchema = z.object({
  action: z.enum(["cancel", "release", "delete"]),
});

export type AdminOrderActionInput = z.infer<typeof adminOrderActionSchema>;

// Очистка заказов в админ-панели (только разработчик): удаляются все заказы
// либо только выбранные (ids). Массовая очистка пачками — сервер удаляет по
// 25 заказов за запрос и возвращает фактическое количество удалённых заказов.
export const clearOrdersSchema = z.object({
  ids: z.array(z.string().trim().min(1).max(100)).max(1000).optional(),
});

export type ClearOrdersInput = z.infer<typeof clearOrdersSchema>;
