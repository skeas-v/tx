import { z } from "zod";
import { AdminRole } from "@/lib/models";

const loginSchema = z
  .string()
  .trim()
  .min(1, "Введите логин")
  .max(50, "Логин слишком длинный");

const passwordSchema = z
  .string()
  .min(4, "Пароль должен быть не короче 4 символов")
  .max(100, "Пароль слишком длинный");

export const adminRoleSchema = z.enum([
  AdminRole.DEVELOPER,
  AdminRole.ADMIN,
  AdminRole.EDITOR,
]);

export const adminAuthSchema = z.object({
  login: loginSchema,
  password: z.string().min(1, "Введите пароль").max(100),
});

export type AdminAuthInput = z.infer<typeof adminAuthSchema>;

export const updateAdminCredentialsSchema = z.object({
  currentPassword: z.string().min(1, "Введите текущий пароль").max(100),
  login: loginSchema,
  password: passwordSchema.optional(),
  role: adminRoleSchema.optional(),
});

export type UpdateAdminCredentialsInput = z.infer<
  typeof updateAdminCredentialsSchema
>;

export const createAdminSchema = z.object({
  login: loginSchema,
  password: passwordSchema,
  role: z.union([adminRoleSchema, z.undefined()]),
});

export type CreateAdminInput = z.infer<typeof createAdminSchema>;

export const updateAdminSchema = z.object({
  role: z.union([adminRoleSchema, z.undefined()]),
  password: passwordSchema.optional(),
});

export type UpdateAdminInput = z.infer<typeof updateAdminSchema>;

export const premiumDriverSchema = z.object({
  isPremium: z.boolean(),
});

export type PremiumDriverInput = z.infer<typeof premiumDriverSchema>;
