import { z } from "zod";

const pushKeysSchema = z.object({
  p256dh: z.string().min(1),
  auth: z.string().min(1),
});

const pushSubscriptionSchema = z.object({
  endpoint: z.string().min(1),
  keys: pushKeysSchema,
  userAgent: z.string().optional(),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
});

const settingsSchema = z.object({
  admin: z.unknown().nullable().optional(),
  admins: z
    .array(
      z
        .object({
          id: z.string().optional(),
          login: z.string().optional(),
          role: z.string().optional(),
          password: z.string().optional(),
          createdAt: z.string().optional(),
          updatedAt: z.string().optional(),
        })
        .passthrough()
    )
    .optional(),
  app: z
    .object({
      siteName: z.string().optional(),
      maintenanceMode: z.boolean().optional(),
      rulesText: z.string().optional(),
      privacyText: z.string().optional(),
      vapidPublicKey: z.string().optional(),
      vapidPrivateKey: z.string().optional(),
      vapidSubject: z.string().optional(),
    })
    .nullable()
    .optional(),
});

export const backupImportSchema = z.object({
  payload: z.object({
    version: z.number().optional(),
    app: z.string().optional(),
    exportedAt: z.string().optional(),
    orders: z.array(z.record(z.string(), z.unknown())).optional(),
    drivers: z.array(z.record(z.string(), z.unknown())).optional(),
    subscriptions: z.array(pushSubscriptionSchema).optional(),
    pushMessages: z.array(z.record(z.string(), z.unknown())).optional(),
    reviews: z.array(z.record(z.string(), z.unknown())).optional(),
    feedback: z.array(z.record(z.string(), z.unknown())).optional(),
    suburbanAddresses: z.array(z.record(z.string(), z.unknown())).optional(),
    popularPlaces: z.array(z.record(z.string(), z.unknown())).optional(),
    settings: settingsSchema.optional(),
  }),
});

export type BackupImportInput = z.infer<typeof backupImportSchema>;
