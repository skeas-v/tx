import { z } from "zod";

export const statisticsPeriodSchema = z.enum(["day", "week", "month", "year"]);

export type StatisticsPeriodInput = z.infer<typeof statisticsPeriodSchema>;

// Схема произвольных дат «от»/«до» при выгрузке (YYYY-MM-DD).
export const customPeriodSchema = z.object({
  fromDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Дата «от» указана неверно"),
  toDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Дата «до» указана неверно"),
});

export type CustomPeriodInput = z.infer<typeof customPeriodSchema>;

const commissionSchema = z
  .number()
  .min(0, "Комиссия не может быть отрицательной")
  .max(1_000_000, "Комиссия слишком большая");

export const statisticsExportSchema = z
  .object({
    period: statisticsPeriodSchema,
    fromDate: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Дата «от» указана неверно")
      .optional()
      .or(z.literal("")),
    toDate: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Дата «до» указана неверно")
      .optional()
      .or(z.literal("")),
    commissionPerOrder: commissionSchema.optional(),
  })
  .refine(
    (data) => {
      const hasCustom = Boolean(data.fromDate || data.toDate);
      if (!hasCustom) return true;
      return Boolean(data.fromDate && data.toDate);
    },
    { message: "Для произвольного периода укажите обе даты" }
  );

export type StatisticsExportInput = z.infer<typeof statisticsExportSchema>;
