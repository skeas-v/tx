import { z } from "zod";

const priceSchema = z
  .number()
  .int("Цена должна быть целым числом")
  .min(0, "Цена не может быть отрицательной")
  .max(1_000_000, "Цена слишком большая");

export const suburbanAddressSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, "Укажите название адреса")
    .max(200, "Название адреса слишком длинное"),
  priceTo: priceSchema,
  priceFrom: priceSchema,
  peakEnabled: z.boolean(),
  peakSurcharge: priceSchema,
  nightEnabled: z.boolean(),
  nightSurcharge: priceSchema,
});

export type SuburbanAddressInput = z.infer<typeof suburbanAddressSchema>;
