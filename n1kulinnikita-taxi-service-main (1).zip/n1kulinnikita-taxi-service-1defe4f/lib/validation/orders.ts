import { z } from "zod";

export const coordinateSchema = z.number().min(-90).max(90).optional();

const entranceSchema = z
  .string()
  .trim()
  .max(10, "Подъезд указан некорректно")
  .regex(/^[0-9A-Za-zА-Яа-я-]{1,10}$/, "Подъезд указан некорректно")
  .optional();

export const createOrderSchema = z.object({
  from: z
    .string()
    .trim()
    .min(1, "Укажите точку «откуда»")
    .max(500, "Адрес слишком длинный"),
  to: z
    .string()
    .trim()
    .min(1, "Укажите точку «куда»")
    .max(500, "Адрес слишком длинный"),
  fromAddress: z.string().trim().max(300).optional(),
  toAddress: z.string().trim().max(300).optional(),
  fromEntrance: entranceSchema,
  toEntrance: entranceSchema,
  fromLat: coordinateSchema,
  fromLng: z.number().min(-180).max(180).optional(),
  toLat: coordinateSchema,
  toLng: z.number().min(-180).max(180).optional(),
  stops: z
    .array(
      z.object({
        address: z
          .string()
          .trim()
          .min(1, "Укажите адрес")
          .max(500, "Адрес слишком длинный"),
        entrance: entranceSchema,
        lat: coordinateSchema,
        lng: z.number().min(-180).max(180).optional(),
      })
    )
    .max(10)
    .optional(),
  clientName: z.string().trim().max(100).optional(),
  clientPhone: z.string().trim().max(30).optional(),
  comment: z.string().trim().max(500).optional(),
  childSeat: z.boolean().optional(),
  delivery: z.boolean().optional(),
  trunk: z.boolean().optional(),
  paymentMethod: z.enum(["cash", "card"]).default("card"),
  cashChangeFrom: z
    .number()
    .int("Сумма для сдачи указана некорректно")
    .min(1, "Сумма для сдачи указана некорректно")
    .max(1_000_000, "Сумма для сдачи указана некорректно")
    .optional(),
});

export const createCallOrderSchema = z.object({
  clientName: z.string().trim().max(100).optional(),
  clientPhone: z.string().trim().max(30).optional(),
});

export type CreateCallOrderInput = z.infer<typeof createCallOrderSchema>;

export type CreateOrderInput = z.infer<typeof createOrderSchema>;

export const orderStatusSchema = z.enum([
  "waiting",
  "assigned",
  "in_progress",
  "completed",
  "cancelled",
]);

export const updateOrderStatusSchema = z.object({
  status: orderStatusSchema,
  driverName: z.string().trim().max(100).optional(),
  driverId: z.string().trim().max(100).optional(),
});

export type UpdateOrderStatusInput = z.infer<typeof updateOrderStatusSchema>;

export const confirmOrderSchema = z.object({
  confirmResult: z.enum(["picked_up", "declined"]),
});

export type ConfirmOrderInput = z.infer<typeof confirmOrderSchema>;
