import { z } from "zod";

export const driverAuthSchema = z.object({
  phone: z.string().trim().min(5, "Укажите номер телефона").max(30),
  password: z.string().min(1, "Введите пароль").max(100),
});

export type DriverAuthInput = z.infer<typeof driverAuthSchema>;

export const updateDriverOnlineSchema = z.object({
  isOnLine: z.boolean(),
});

export type UpdateDriverOnlineInput = z.infer<typeof updateDriverOnlineSchema>;

export const updateDriverProfileSchema = z
  .object({
    currentPassword: z.string().min(1, "Введите текущий пароль").max(100),
    name: z.string().trim().min(1, "Укажите имя").max(100).optional(),
    phone: z
      .string()
      .trim()
      .min(5, "Укажите номер телефона")
      .max(30, "Номер телефона слишком длинный")
      .optional(),
    vkId: z.string().trim().max(50, "VK ID слишком длинный").optional(),
    carMake: z.string().trim().max(100, "Марка слишком длинная").optional(),
    carNumber: z.string().trim().max(20, "Номер слишком длинный").optional(),
    carColor: z.string().trim().max(30, "Цвет слишком длинный").optional(),
    password: z
      .string()
      .min(4, "Пароль должен быть не короче 4 символов")
      .max(100, "Пароль слишком длинный")
      .optional(),
  })
  .refine((data) => data.password === undefined || data.password !== "", {
    message: "Пароль не может быть пустым",
  });

export type UpdateDriverProfileInput = z.infer<
  typeof updateDriverProfileSchema
>;

export const adminDriverSchema = z.object({
  name: z.string().trim().min(1, "Укажите имя водителя").max(100),
  phone: z
    .string()
    .trim()
    .min(5, "Укажите номер телефона")
    .max(30, "Номер телефона слишком длинный"),
  vkId: z.string().trim().max(50, "VK ID слишком длинный").optional(),
  carMake: z.string().trim().max(100, "Марка слишком длинная").optional(),
  carNumber: z.string().trim().max(20, "Номер слишком длинный").optional(),
  carColor: z.string().trim().max(30, "Цвет слишком длинный").optional(),
  isOnLine: z.boolean().optional(),
  password: z
    .string()
    .min(4, "Пароль должен быть не короче 4 символов")
    .max(100, "Пароль слишком длинный")
    .optional(),
});

export type AdminDriverInput = z.infer<typeof adminDriverSchema>;

export const blockDriverSchema = z.object({
  isBlocked: z.boolean(),
});

export type BlockDriverInput = z.infer<typeof blockDriverSchema>;
