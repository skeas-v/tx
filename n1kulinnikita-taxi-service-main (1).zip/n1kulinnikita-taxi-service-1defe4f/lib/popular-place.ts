// Ценообразование популярных мест.
// Администратор добавляет популярное место (например, «Лихолесье: Монтажная
// ул., 5») и может указать фиксированную цену поездки (например, 30₽).
// Когда клиент выбирает это популярное место при оформлении заказа (поля
// «Откуда»/«Куда»), цена за поездку становится ровно указанной суммой вместо
// тарифа по городу. Если цена не указана — применяется обычный тариф.
//
// Соответствие ищется по «откуда» и «куда»: поле может содержать название
// места целиком («Лихолесье»), название с адресом («Лихолесье, Монтажная
// ул., 5») или более длинный адрес, содержащий название места.

import type { PopularPlace } from "./models";

export interface PopularPlacePrice {
  name: string;
  price: number;
}

function normalizeAddress(value: string): string {
  return value
    .toLowerCase()
    .replace(/[ёЁ]/g, "е")
    .replace(/\s+/g, " ")
    .replace(/^\s+|\s+$/g, "");
}

function normalizeName(value: string): string {
  return value
    .toLowerCase()
    .replace(/[ёЁ]/g, "е")
    .replace(/\s+/g, " ")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function placeMatches(
  address: string | undefined,
  candidate: PopularPlace
): boolean {
  const raw = (address ?? "").trim();
  if (!raw) return false;
  if (candidate.price == null || candidate.price <= 0) return false;

  const addressNorm = normalizeAddress(raw);
  const nameNorm = normalizeName(candidate.name);
  const displayNorm = candidate.address
    ? normalizeAddress(`${candidate.name}, ${candidate.address}`)
    : nameNorm;
  if (!nameNorm && !displayNorm) return false;

  if (addressNorm === nameNorm) return true;
  if (addressNorm === displayNorm) return true;
  if (addressNorm.includes(nameNorm)) return true;
  if (displayNorm && addressNorm.includes(displayNorm)) return true;
  return false;
}

// Фиксированная цена популярного места, если один из адресов «откуда»/«куда»
// совпадает с популярным местом, у которого администратор указал цену.
// Если совпадают оба — берётся максимальная цена, чтобы не занизить стоимость.
export function resolvePopularPlacePrice(
  places: PopularPlace[],
  from: string | undefined,
  to: string | undefined
): PopularPlacePrice | null {
  const fromHit = places.find((p) => placeMatches(from, p));
  const toHit = places.find((p) => placeMatches(to, p));

  if (!fromHit && !toHit) {
    return null;
  }

  const chosen =
    fromHit && toHit
      ? fromHit.price! >= toHit.price!
        ? fromHit
        : toHit
      : (fromHit ?? toHit);

  if (!chosen || chosen.price == null || chosen.price <= 0) {
    return null;
  }

  return { name: chosen.name, price: chosen.price };
}
