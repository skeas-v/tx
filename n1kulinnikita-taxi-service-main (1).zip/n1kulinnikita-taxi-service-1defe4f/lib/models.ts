import { docClient, isDatabaseAvailable } from "./db";
import {
  GetCommand,
  PutCommand,
  DeleteCommand,
  QueryCommand,
  ScanCommand,
  UpdateCommand,
  BatchWriteCommand,
} from "@aws-sdk/lib-dynamodb";
import { TableName, IndexName } from "./schema";
import { DEFAULT_PASSWORD, hashPassword, verifyPassword } from "./password";

export const DRIVER_NOT_FOUND = "DRIVER_NOT_FOUND";
export const DRIVER_WRONG_PASSWORD = "DRIVER_WRONG_PASSWORD";
export const DRIVER_BLOCKED = "DRIVER_BLOCKED";

export const ADMIN_DEFAULT_LOGIN = "admin";
export const ADMIN_DEFAULT_PASSWORD = "admin";
export const ADMIN_NOT_FOUND = "ADMIN_NOT_FOUND";
export const ADMIN_WRONG_PASSWORD = "ADMIN_WRONG_PASSWORD";

// Роли администраторов админ-панели:
// - developer — Разработчик: доступны все функции, включая управление ролями
//   и включение «премиум аккаунта» водителям.
// - admin — Администратор: доступны все функции, включая добавление
//   администраторов и редакторов (управление ролями ему не доступно).
// - editor — Редактор: видит заказы и может редактировать и блокировать
//   водителей.
export const AdminRole = {
  DEVELOPER: "developer",
  ADMIN: "admin",
  EDITOR: "editor",
} as const;

export type AdminRole = (typeof AdminRole)[keyof typeof AdminRole];

export const ADMIN_ROLE_LABELS: Record<AdminRole, string> = {
  [AdminRole.DEVELOPER]: "Разработчик",
  [AdminRole.ADMIN]: "Администратор",
  [AdminRole.EDITOR]: "Редактор",
};

export const DEFAULT_ADMIN_ROLE: AdminRole = AdminRole.DEVELOPER;

export const OrderStatus = {
  WAITING: "waiting",
  ASSIGNED: "assigned",
  IN_PROGRESS: "in_progress",
  COMPLETED: "completed",
  CANCELLED: "cancelled",
} as const;

// Номера заказов — только цифры с ведущими нулями (например, «00001»).
// Форматированный номер показывается клиентам как «Заказ №00001».
export function formatOrderNumber(id: string): string {
  const digits = id.replace(/\D/g, "").slice(0, 5);
  return digits ? digits.padStart(5, "0") : id.slice(0, 5);
}

// Приводит введённый пользователем номер заказа к каноническому виду
// (только цифры), чтобы поиск на странице /track не зависел от «№»,
// пробелов или другого оформления.
export function normalizeOrderNumberInput(value: string): string {
  return value.replace(/\D/g, "").slice(0, 5).padStart(5, "0");
}

export async function nextOrderId(): Promise<string> {
  const orders = await getAllOrders();
  let max = 0;
  for (const order of orders) {
    if (!/^[0-9]+$/.test(order.id)) continue;
    const num = parseInt(order.id, 10);
    if (Number.isFinite(num)) {
      max = Math.max(max, num);
    }
  }
  return String(max + 1).padStart(5, "0");
}

export function carArrivalLabel(
  driver:
    Pick<DriverInfo, "carMake" | "carNumber" | "carColor"> | null | undefined
): string {
  if (!driver) return "";
  return [driver.carMake, driver.carNumber, driver.carColor]
    .filter(Boolean)
    .join(", ");
}

export type OrderStatus = (typeof OrderStatus)[keyof typeof OrderStatus];

export const CallResult = {
  PICKED_UP: "picked_up",
  DECLINED: "declined",
} as const;

export type CallResult = (typeof CallResult)[keyof typeof CallResult];

export interface DriverInfo {
  id: string;
  name: string;
  phone: string;
  carMake?: string;
  carNumber?: string;
  carColor?: string;
}

export interface OrderStop {
  address: string;
  entrance?: string;
  lat?: number;
  lng?: number;
}

export interface Order {
  id: string;
  from: string;
  to: string;
  fromAddress?: string;
  toAddress?: string;
  fromEntrance?: string;
  toEntrance?: string;
  fromLat?: number;
  fromLng?: number;
  toLat?: number;
  toLng?: number;
  stops?: OrderStop[];
  clientName?: string;
  clientPhone?: string;
  comment?: string;
  childSeat?: boolean;
  delivery?: boolean;
  trunk?: boolean;
  /** Способ оплаты: «cash» — наличными (клиент выбрал «Оплата наличными»),
   *  «card» — переводом/безналичная (по умолчанию). Передаётся при
   *  оформлении заказа (POST /api/orders), сохраняется в заказе и
   *  отображается в карточках и уведомлении ВК. */
  paymentMethod?: "cash" | "card";
  /** Сумма, с которой водителю нужно подготовить сдачу (например, «с 500 ₽»).
   *  Необязательное поле, указывается клиентом только при оплате наличными. */
  cashChangeFrom?: number;
  conversationMessageId?: number;
  driverWaitingAt?: string;
  driverId?: string;
  driverName?: string;
  driver?: DriverInfo | null;
  assignedCarMake?: string;
  assignedCarNumber?: string;
  phoneCall?: boolean;
  confirmResult?: CallResult | null;
  suburbanPrice?: {
    name: string;
    price: number;
    basePrice: number;
    surcharge: number;
    direction: "to" | "from";
    peakEnabled: boolean;
    peakSurcharge: number;
    nightEnabled: boolean;
    nightSurcharge: number;
  } | null;
  /** Снапшот цены популярного места: когда клиент выбрал в форме заказа
   *  популярное место с заданной администратором ценой, фиксируется эта цена
   *  (price), название места (name) и отображается в карточках заказа и в
   *  уведомлении в беседе ВКонтакте. Если цена не указана — поле отсутствует
   *  и применяется обычный тариф по городу. */
  popularPlacePrice?: {
    name: string;
    price: number;
  } | null;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export async function getOrdersByStatus(status: string): Promise<Order[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.ORDERS,
      IndexName: IndexName.ORDERS_STATUS,
      KeyConditionExpression: "#status = :status",
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ExpressionAttributeValues: {
        ":status": status,
      },
      ScanIndexForward: false,
    })
  );
  return (result.Items as Order[]) ?? [];
}

export async function getAllOrders(): Promise<Order[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.ORDERS,
    })
  );
  return (result.Items as Order[]) ?? [];
}

export async function getOrderById(id: string): Promise<Order | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.ORDERS,
      Key: { id },
    })
  );
  return (result.Item as Order) ?? null;
}

export async function findOrderByConversationMessageId(
  cmid: number | string
): Promise<Order | null> {
  const normalized = String(cmid);
  if (!normalized) return null;
  const orders = await getAllOrders();
  return (
    orders.find(
      (order) =>
        order.conversationMessageId != null &&
        String(order.conversationMessageId) === normalized
    ) ?? null
  );
}

export async function updateOrderConversationMessageId(
  id: string,
  conversationMessageId: number
): Promise<Order | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression:
        "set conversationMessageId = :cmid, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":cmid": conversationMessageId,
        ":updatedAt": new Date().toISOString(),
      },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes as Order) ?? null;
}

export async function markDriverWaiting(id: string): Promise<Order | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression:
        "set driverWaitingAt = :driverWaitingAt, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":driverWaitingAt": new Date().toISOString(),
        ":updatedAt": new Date().toISOString(),
      },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes as Order) ?? null;
}

export async function releaseOrder(id: string): Promise<Order | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression:
        "set #status = :status, updatedAt = :updatedAt remove driverId, driverName, driverWaitingAt",
      ExpressionAttributeValues: {
        ":status": OrderStatus.WAITING,
        ":updatedAt": new Date().toISOString(),
      },
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes as Order) ?? null;
}

export async function updateOrderAssignedCar(
  id: string,
  assignedCarMake: string,
  assignedCarNumber: string
): Promise<Order | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression:
        "set assignedCarMake = :make, assignedCarNumber = :number, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":make": assignedCarMake,
        ":number": assignedCarNumber,
        ":updatedAt": new Date().toISOString(),
      },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes as Order) ?? null;
}

// Отмена заказа клиентом со страницы /track: заказ получает статус «отменён»,
// отметки о действиях водителя (ожидание, назначенная машина) очищаются, заказ
// больше не активен в очереди и не «занимает» водителя. Водитель (driverId/
// driverName) сохраняется, чтобы отменённый заказ оставался виден в панели
// водителя и отображал полные данные: номер, адреса маршрута, имя клиента.
export async function cancelOrder(id: string): Promise<Order | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression:
        "set #status = :status, updatedAt = :updatedAt remove driverWaitingAt, assignedCarMake, assignedCarNumber",
      ExpressionAttributeValues: {
        ":status": OrderStatus.CANCELLED,
        ":updatedAt": new Date().toISOString(),
      },
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes as Order) ?? null;
}

// Максимальное время ожидания водителя для заказа из очереди. Если заказ
// находится в статусе waiting (никто не взял) дольше этого времени с момента
// создания — он автоматически отменяется и уходит из очереди водителей.
export const ORDER_AUTO_CANCEL_TIMEOUT_MS = 15 * 60 * 1000;

// Автоматическая отмена заказов, которые никто не взял дольше 15 минут:
// заказ в статусе waiting, которому не назначен водитель и который не создан
// по звонку (заказы по звонку не попадают в общую очередь), атомарно
// переводится в статус cancelled. Атомарность по статусу waiting исключает
// гонку с водителем, который в этот момент взял заказ. Возвращает список
// отменённых заказов.
export async function cancelExpiredWaitingOrders(): Promise<Order[]> {
  const waitingOrders = await getOrdersByStatus(OrderStatus.WAITING);
  const cutoff = new Date(Date.now() - ORDER_AUTO_CANCEL_TIMEOUT_MS).getTime();
  const expired = waitingOrders.filter((order) => {
    if (order.phoneCall) return false;
    if (order.driverId || order.driverName) return false;
    const createdAt = order.createdAt
      ? new Date(order.createdAt).getTime()
      : NaN;
    return Number.isFinite(createdAt) && createdAt <= cutoff;
  });

  const cancelled: Order[] = [];
  for (const order of expired) {
    try {
      const updated = await updateOrderStatus(
        order.id,
        { status: OrderStatus.CANCELLED },
        OrderStatus.WAITING
      );
      if (updated) cancelled.push(updated);
    } catch (error) {
      if (
        (error as { name?: string })?.name === "ConditionalCheckFailedException"
      ) {
        // Заказ уже взят или изменён другим запросом в момент отмены —
        // пропускаем без ошибки.
        continue;
      }
      console.warn(`Ошибка автоотмены заказа ${order.id}:`, error);
    }
  }
  return cancelled;
}

// Полное удаление заказа из БД. Используется в админ-панели разделом заказов
// (действие «Удалить»). Доступно только разработчику — защита на уровне API.
export async function deleteOrder(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.ORDERS,
      Key: { id },
    })
  );
}

// Массовое удаление заказов из БД пачками. Используется в админ-панели
// действием «Очистить заказы» (только разработчик). Удаление выполняется
// через BatchWrite (до 25 элементов за запрос), поэтому список режется на
// пачки по 25 заказов.
export async function deleteOrdersByIds(ids: string[]): Promise<void> {
  const uniqueIds = [...new Set(ids)].filter(Boolean);
  for (let i = 0; i < uniqueIds.length; i += 25) {
    const chunk = uniqueIds.slice(i, i + 25);
    const result = await docClient.send(
      new BatchWriteCommand({
        RequestItems: {
          [TableName.ORDERS]: chunk.map((id) => ({
            DeleteRequest: { Key: { id } },
          })),
        },
      })
    );
    const unprocessed = result.UnprocessedItems?.[TableName.ORDERS] ?? [];
    if (unprocessed.length > 0) {
      const retryIds = unprocessed
        .map((item) => item.DeleteRequest?.Key?.id)
        .filter((id): id is string => typeof id === "string");
      if (retryIds.length > 0) {
        await deleteOrdersByIds(retryIds);
      }
    }
  }
}

export async function getOrdersByDriver(driverName: string): Promise<Order[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.ORDERS,
    })
  );
  return ((result.Items as Order[]) ?? []).filter(
    (order) => order.driverName === driverName
  );
}

export async function createOrder(
  data: Omit<Order, "createdAt" | "updatedAt">
): Promise<Order> {
  const now = new Date().toISOString();
  const order: Order = {
    ...data,
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.ORDERS,
      Item: order,
    })
  );

  return order;
}

export async function updateOrderStatus(
  id: string,
  data: { status: OrderStatus; driverName?: string; driverId?: string },
  expectedStatus?: OrderStatus
): Promise<Order | null> {
  const updateExpr = ["#status = :status", "updatedAt = :updatedAt"];
  const exprValues: Record<string, unknown> = {
    ":status": data.status,
    ":updatedAt": new Date().toISOString(),
  };
  const exprNames: Record<string, string> = { "#status": "status" };

  if (data.driverName !== undefined) {
    updateExpr.push("#driverName = :driverName");
    exprValues[":driverName"] = data.driverName;
    exprNames["#driverName"] = "driverName";
  }

  if (data.driverId !== undefined) {
    updateExpr.push("driverId = :driverId");
    exprValues[":driverId"] = data.driverId;
  }

  if (expectedStatus !== undefined) {
    exprValues[":expectedStatus"] = expectedStatus;
  }

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression: `set ${updateExpr.join(", ")}`,
      ConditionExpression:
        expectedStatus !== undefined ? "#status = :expectedStatus" : undefined,
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames: exprNames,
      ReturnValues: "ALL_NEW",
    })
  );

  return (result.Attributes as Order) ?? null;
}

export async function updateOrderConfirmResult(
  id: string,
  confirmResult: CallResult
): Promise<Order | null> {
  const updateExpr = [
    "confirmResult = :confirmResult",
    "updatedAt = :updatedAt",
  ];
  const exprValues: Record<string, unknown> = {
    ":confirmResult": confirmResult,
    ":updatedAt": new Date().toISOString(),
  };
  const exprNames: Record<string, string> = {};

  if (confirmResult === CallResult.PICKED_UP) {
    updateExpr.push("#status = :status");
    exprValues[":status"] = OrderStatus.COMPLETED;
    exprNames["#status"] = "status";
  }

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.ORDERS,
      Key: { id },
      UpdateExpression: `set ${updateExpr.join(", ")}`,
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames:
        Object.keys(exprNames).length > 0 ? exprNames : undefined,
      ReturnValues: "ALL_NEW",
    })
  );

  return (result.Attributes as Order) ?? null;
}

export function withDriverInfo(orders: Order[], drivers: Driver[]): Order[] {
  if (orders.length === 0 || drivers.length === 0) {
    return orders.map((order) => ({ ...order, driver: null }));
  }

  const byId = new Map(drivers.map((d) => [d.id, d]));
  const byName = new Map(drivers.map((d) => [d.name, d]));

  return orders.map((order) => {
    const matched =
      (order.driverId ? byId.get(order.driverId) : undefined) ??
      (order.driverName ? byName.get(order.driverName) : undefined);

    if (!matched) {
      return { ...order, driver: null };
    }

    return {
      ...order,
      driverId: order.driverId ?? matched.id,
      driverName: order.driverName ?? matched.name,
      driver: {
        id: matched.id,
        name: matched.name,
        phone: matched.phone,
        carMake: matched.carMake,
        carNumber: matched.carNumber,
        carColor: matched.carColor,
      },
    };
  });
}

export async function attachDriverInfo(orders: Order[]): Promise<Order[]> {
  if (orders.length === 0) return [];
  const drivers = await getAllDrivers();
  return withDriverInfo(orders, drivers);
}

export interface CallReview {
  id: string;
  orderId?: string;
  driverId?: string;
  driverName?: string;
  clientName?: string;
  clientPhone?: string;
  review: string;
  createdAt: string;
}

export async function getAllCallReviews(): Promise<CallReview[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.CALL_REVIEWS,
    })
  );
  return ((result.Items as CallReview[]) ?? []).sort((a, b) =>
    b.createdAt.localeCompare(a.createdAt)
  );
}

export async function createCallReview(
  data: Omit<CallReview, "id" | "createdAt">
): Promise<CallReview> {
  const review: CallReview = {
    ...data,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.CALL_REVIEWS,
      Item: review,
    })
  );

  return review;
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  vkId?: string;
  carMake?: string;
  carNumber?: string;
  carColor?: string;
  assignedCarMake?: string;
  assignedCarNumber?: string;
  isOnLine: boolean;
  isBlocked?: boolean;
  isPremium?: boolean;
  password?: string;
  createdAt: string;
  updatedAt: string;
}

export function publicDriver(driver: Driver): Driver {
  const copy = { ...driver };
  delete copy.password;
  return copy;
}

// Приводит VK ID водителя к каноническому виду: оставляет только цифры,
// отбрасывая префиксы вида id..., vk.com/..., https://vk.com/..., @ и пробелы.
// Используется и при сохранении, и при поиске водителя по from_id, чтобы
// исключить проблемы с типом/пробелами/форматом ввода.
export function normalizeVkId(value?: string): string {
  const raw = (value ?? "").trim();
  if (!raw) return "";
  return raw
    .replace(/^https?:\/\/(?:www\.|m\.|new\.)?vk\.com\//i, "")
    .replace(/^vk\.com\//i, "")
    .replace(/^id/i, "")
    .replace(/^@/, "")
    .replace(/^club/i, "")
    .replace(/[^0-9]/g, "")
    .trim();
}

export async function getDriverById(id: string): Promise<Driver | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.DRIVERS,
      Key: { id },
    })
  );
  return (result.Item as Driver) ?? null;
}

export async function getDriverByVkId(vkId: string): Promise<Driver | null> {
  const drivers = await getAllDrivers();
  const normalized = normalizeVkId(vkId);
  if (!normalized) return null;
  return drivers.find((d) => normalizeVkId(d.vkId) === normalized) ?? null;
}

export async function getAllDrivers(): Promise<Driver[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.DRIVERS,
    })
  );
  return (result.Items as Driver[]) ?? [];
}

export async function createDriver(
  data: Omit<Driver, "createdAt" | "updatedAt">
): Promise<Driver> {
  const now = new Date().toISOString();
  const driver: Driver = {
    ...data,
    vkId: data.vkId ? normalizeVkId(data.vkId) || undefined : undefined,
    password: hashPassword(data.password ?? DEFAULT_PASSWORD),
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.DRIVERS,
      Item: driver,
    })
  );

  return driver;
}

export async function findAvailableDriver(): Promise<Driver | null> {
  const [drivers, orders] = await Promise.all([
    getAllDrivers(),
    getAllOrders(),
  ]);

  const activeOrders = orders.filter(
    (order) =>
      order.driverName &&
      order.status !== OrderStatus.COMPLETED &&
      order.status !== OrderStatus.CANCELLED &&
      !order.confirmResult
  );

  const isBusy = (driver: Driver) =>
    activeOrders.some(
      (order) =>
        order.driverName === driver.name || order.driverName === driver.id
    );

  return (
    drivers.find(
      (driver) =>
        driver.isOnLine &&
        !driver.isBlocked &&
        !!driver.phone?.trim() &&
        !isBusy(driver)
    ) ?? null
  );
}

// Поиск свободного водителя с включённым «премиум аккаунтом». Если такой
// водитель есть на линии и не занят другим активным заказом — он получает
// входящий заказ первым (все заказы достаются премиум-водителю).
export async function findPremiumAvailableDriver(): Promise<Driver | null> {
  const [drivers, orders] = await Promise.all([
    getAllDrivers(),
    getAllOrders(),
  ]);

  const activeOrders = orders.filter(
    (order) =>
      order.driverName &&
      order.status !== OrderStatus.COMPLETED &&
      order.status !== OrderStatus.CANCELLED &&
      !order.confirmResult
  );

  const isBusy = (driver: Driver) =>
    activeOrders.some(
      (order) =>
        order.driverName === driver.name || order.driverName === driver.id
    );

  return (
    drivers.find(
      (driver) =>
        driver.isPremium &&
        driver.isOnLine &&
        !driver.isBlocked &&
        !!driver.phone?.trim() &&
        !isBusy(driver)
    ) ?? null
  );
}

export async function updateDriverOnline(
  id: string,
  isOnLine: boolean
): Promise<Driver | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.DRIVERS,
      Key: { id },
      UpdateExpression: "set #isOnLine = :isOnLine, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":isOnLine": isOnLine,
        ":updatedAt": new Date().toISOString(),
      },
      ExpressionAttributeNames: {
        "#isOnLine": "isOnLine",
      },
      ReturnValues: "ALL_NEW",
    })
  );

  return (result.Attributes as Driver) ?? null;
}

export async function updateDriverAssignedCar(
  id: string,
  assignedCarMake: string,
  assignedCarNumber: string
): Promise<Driver | null> {
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.DRIVERS,
      Key: { id },
      UpdateExpression:
        "set assignedCarMake = :make, assignedCarNumber = :number, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":make": assignedCarMake,
        ":number": assignedCarNumber,
        ":updatedAt": new Date().toISOString(),
      },
      ReturnValues: "ALL_NEW",
    })
  );

  return (result.Attributes as Driver) ?? null;
}

export async function updateDriver(
  id: string,
  data: Partial<
    Pick<
      Driver,
      | "name"
      | "phone"
      | "vkId"
      | "carMake"
      | "carNumber"
      | "carColor"
      | "isOnLine"
      | "password"
    >
  >
): Promise<Driver> {
  const existing = await getDriverById(id);
  if (!existing) {
    throw new Error("DRIVER_NOT_FOUND");
  }

  const phone = data.phone?.trim() || existing.phone;
  const nextId = phone !== existing.phone ? phone : id;
  const merged: Driver = {
    ...existing,
    name: data.name ?? existing.name,
    phone,
    vkId:
      data.vkId !== undefined
        ? normalizeVkId(data.vkId) || undefined
        : existing.vkId,
    carMake: data.carMake ?? existing.carMake,
    carNumber: data.carNumber ?? existing.carNumber,
    carColor: data.carColor ?? existing.carColor,
    isOnLine: data.isOnLine ?? existing.isOnLine,
    password:
      data.password !== undefined
        ? hashPassword(data.password)
        : existing.password,
    id: nextId,
    updatedAt: new Date().toISOString(),
  };

  if (nextId !== id) {
    const clash = await getDriverById(nextId);
    if (clash && clash.id !== id) {
      throw new Error("DRIVER_PHONE_CONFLICT");
    }
    await docClient.send(
      new DeleteCommand({
        TableName: TableName.DRIVERS,
        Key: { id },
      })
    );
  }

  await docClient.send(
    new PutCommand({
      TableName: TableName.DRIVERS,
      Item: merged,
    })
  );

  return merged;
}

export async function updateDriverBlocked(
  id: string,
  isBlocked: boolean
): Promise<Driver> {
  const existing = await getDriverById(id);
  if (!existing) {
    throw new Error(DRIVER_NOT_FOUND);
  }

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.DRIVERS,
      Key: { id },
      UpdateExpression:
        "set isBlocked = :isBlocked, #isOnLine = :isOnLine, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":isBlocked": isBlocked,
        ":isOnLine": isBlocked ? false : existing.isOnLine,
        ":updatedAt": new Date().toISOString(),
      },
      ExpressionAttributeNames: {
        "#isOnLine": "isOnLine",
      },
      ReturnValues: "ALL_NEW",
    })
  );

  return result.Attributes as Driver;
}

// Включение/выключение «премиум аккаунта» водителя. Функция доступна только
// разработчику: когда она включена, все входящие заказы (если водитель не на
// заказе) достаются этому водителю.
export async function updateDriverPremium(
  id: string,
  isPremium: boolean
): Promise<Driver> {
  const existing = await getDriverById(id);
  if (!existing) {
    throw new Error(DRIVER_NOT_FOUND);
  }

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.DRIVERS,
      Key: { id },
      UpdateExpression: "set isPremium = :isPremium, updatedAt = :updatedAt",
      ExpressionAttributeValues: {
        ":isPremium": isPremium,
        ":updatedAt": new Date().toISOString(),
      },
      ReturnValues: "ALL_NEW",
    })
  );

  return result.Attributes as Driver;
}

export async function deleteDriver(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.DRIVERS,
      Key: { id },
    })
  );
}

export async function authenticateDriver(
  phone: string,
  password: string
): Promise<Driver> {
  const driver = await getDriverById(phone);
  if (!driver) {
    throw new Error(DRIVER_NOT_FOUND);
  }
  if (driver.isBlocked) {
    throw new Error(DRIVER_BLOCKED);
  }
  if (!driver.password || !verifyPassword(password, driver.password)) {
    throw new Error(DRIVER_WRONG_PASSWORD);
  }
  return driver;
}

export async function getCompletedOrdersByDriver(
  driverName: string
): Promise<Order[]> {
  const orders = await getAllOrders();
  return orders.filter(
    (order) =>
      order.driverName === driverName && order.status === OrderStatus.COMPLETED
  );
}

export interface Admin {
  id: string;
  login: string;
  role: AdminRole;
  password?: string;
  createdAt: string;
  updatedAt: string;
}

export function publicAdmin(admin: Admin): Admin {
  const copy = { ...admin };
  delete copy.password;
  return copy;
}

export async function getAllAdmins(): Promise<Admin[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.ADMINS,
    })
  );
  return ((result.Items as Admin[]) ?? []).sort((a, b) =>
    a.login.localeCompare(b.login, "ru")
  );
}

export async function getAdminByLogin(login: string): Promise<Admin | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.ADMINS,
      Key: { id: login },
    })
  );
  return (result.Item as Admin) ?? null;
}

export async function getSingleAdmin(): Promise<Admin | null> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.ADMINS,
    })
  );
  const items = (result.Items as Admin[]) ?? [];
  return items[0] ?? null;
}

export async function ensureDefaultAdmin(): Promise<Admin> {
  const existing = await getSingleAdmin();
  if (existing) {
    if (!existing.role) {
      existing.role = DEFAULT_ADMIN_ROLE;
      await docClient.send(
        new PutCommand({
          TableName: TableName.ADMINS,
          Item: existing,
        })
      );
    }
    return existing;
  }

  const now = new Date().toISOString();
  const admin: Admin = {
    id: ADMIN_DEFAULT_LOGIN,
    login: ADMIN_DEFAULT_LOGIN,
    role: DEFAULT_ADMIN_ROLE,
    password: hashPassword(ADMIN_DEFAULT_PASSWORD),
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.ADMINS,
      Item: admin,
    })
  );

  return admin;
}

export async function authenticateAdmin(
  login: string,
  password: string
): Promise<Admin> {
  const admin = await getAdminByLogin(login);
  if (!admin) {
    throw new Error(ADMIN_NOT_FOUND);
  }
  if (!admin.password || !verifyPassword(password, admin.password)) {
    throw new Error(ADMIN_WRONG_PASSWORD);
  }
  return admin;
}

// Создание нового администратора/редактора. Доступно администратору и
// разработчику. При роли admin создаётся администратор, при editor —
// редактор (видит заказы и может редактировать/блокировать водителей).
export async function createAdmin(data: {
  login: string;
  password: string;
  role: AdminRole;
}): Promise<Admin> {
  const existing = await getAdminByLogin(data.login);
  if (existing) {
    throw new Error("ADMIN_LOGIN_CONFLICT");
  }

  const now = new Date().toISOString();
  const admin: Admin = {
    id: data.login,
    login: data.login,
    role: data.role,
    password: hashPassword(data.password),
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.ADMINS,
      Item: admin,
    })
  );

  return admin;
}

// Обновление собственных данных администратора/редактора (логин, роль,
// пароль) для конкретного пользователя по текущему логину. Для смены логина
// текущий пароль подтверждается.
export async function updateAdminCredentials(
  currentLogin: string,
  currentPassword: string,
  data: { login: string; password?: string; role?: AdminRole }
): Promise<Admin> {
  const existing = await getAdminByLogin(currentLogin);
  if (!existing) {
    throw new Error(ADMIN_NOT_FOUND);
  }
  if (
    !existing.password ||
    !verifyPassword(currentPassword, existing.password)
  ) {
    throw new Error(ADMIN_WRONG_PASSWORD);
  }

  const login = data.login.trim();
  const nextId = login !== existing.login ? login : existing.id;
  const merged: Admin = {
    ...existing,
    login,
    role: data.role ?? existing.role,
    password:
      data.password !== undefined
        ? hashPassword(data.password)
        : existing.password,
    id: nextId,
    updatedAt: new Date().toISOString(),
  };

  if (nextId !== existing.id) {
    const clash = await getAdminByLogin(nextId);
    if (clash && clash.id !== existing.id) {
      throw new Error("ADMIN_LOGIN_CONFLICT");
    }
    await docClient.send(
      new DeleteCommand({
        TableName: TableName.ADMINS,
        Key: { id: existing.id },
      })
    );
  }

  await docClient.send(
    new PutCommand({
      TableName: TableName.ADMINS,
      Item: merged,
    })
  );

  return merged;
}

// Обновление администратора по id (управление ролями из раздела «Доступ»):
// смена роли и/или пароля. Нельзя удалить/сменить роль последнего
// разработчика, чтобы нельзя было потерять полный доступ к панели.
export async function updateAdminById(
  id: string,
  data: { role?: AdminRole; password?: string }
): Promise<Admin> {
  const existing = await getAdminByLogin(id);
  if (!existing) {
    throw new Error(ADMIN_NOT_FOUND);
  }

  if (data.role !== undefined && data.role !== existing.role) {
    if (existing.role === AdminRole.DEVELOPER) {
      const developers = (await getAllAdmins()).filter(
        (a) => a.role === AdminRole.DEVELOPER
      );
      if (developers.length <= 1) {
        throw new Error("ADMIN_LAST_DEVELOPER");
      }
    }
  }

  const merged: Admin = {
    ...existing,
    role: data.role ?? existing.role,
    password:
      data.password !== undefined
        ? hashPassword(data.password)
        : existing.password,
    updatedAt: new Date().toISOString(),
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.ADMINS,
      Item: merged,
    })
  );

  return merged;
}

// Сброс пароля администратора/разработчика со скрытой страницы /reset-admin.
// Сбрасывает пароль первому аккаунту разработчика (если таких несколько —
// первому из списка), иначе — первому администратору; если в БД нет ни одного
// аккаунта — создаёт администратора по умолчанию (admin) с ролью разработчика
// и заданным паролем. Доступ сама функция не проверяет: её вызывает серверный
// эндпоинт после проверки секретного ключа.
export async function resetDefaultDeveloperPassword(
  newPassword: string
): Promise<Admin> {
  const developers = (await getAllAdmins()).filter(
    (a) => a.role === AdminRole.DEVELOPER
  );
  const target = developers[0] ?? (await getSingleAdmin());
  if (!target) {
    return ensureDefaultAdminQuiet(newPassword);
  }
  return updateAdminById(target.id, { password: newPassword });
}

// Создаёт администратора по умолчанию (admin) с заданным паролем, если в БД
// не оказалось ни одного аккаунта. Используется при сбросе пароля со скрытой
// страницы, когда все данные администраторов отсутствуют.
async function ensureDefaultAdminQuiet(newPassword: string): Promise<Admin> {
  const now = new Date().toISOString();
  const admin: Admin = {
    id: ADMIN_DEFAULT_LOGIN,
    login: ADMIN_DEFAULT_LOGIN,
    role: DEFAULT_ADMIN_ROLE,
    password: hashPassword(newPassword),
    createdAt: now,
    updatedAt: now,
  };
  await docClient.send(
    new PutCommand({
      TableName: TableName.ADMINS,
      Item: admin,
    })
  );
  return admin;
}

// Удаление администратора/редактора. Нельзя удалить последнего разработчика
// и самого себя (текущую сессию).
export async function deleteAdminById(
  id: string,
  currentLogin: string
): Promise<void> {
  const existing = await getAdminByLogin(id);
  if (!existing) {
    throw new Error(ADMIN_NOT_FOUND);
  }
  if (existing.login === currentLogin) {
    throw new Error("ADMIN_DELETE_SELF");
  }
  if (existing.role === AdminRole.DEVELOPER) {
    const developers = (await getAllAdmins()).filter(
      (a) => a.role === AdminRole.DEVELOPER
    );
    if (developers.length <= 1) {
      throw new Error("ADMIN_LAST_DEVELOPER");
    }
  }

  await docClient.send(
    new DeleteCommand({
      TableName: TableName.ADMINS,
      Key: { id },
    })
  );
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  status: "active" | "inactive" | "deploying";
  url?: string;
  createdAt: string;
  updatedAt: string;
}

export async function getServiceById(id: string): Promise<Service | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
  return (result.Item as Service) ?? null;
}

export async function getServicesByStatus(status: string): Promise<Service[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.SERVICES,
      IndexName: IndexName.SERVICES_STATUS,
      KeyConditionExpression: "#status = :status",
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ExpressionAttributeValues: {
        ":status": status,
      },
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function getAllServices(): Promise<Service[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.SERVICES,
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function createService(
  data: Omit<Service, "createdAt" | "updatedAt">
): Promise<Service> {
  const now = new Date().toISOString();
  const service: Service = {
    ...data,
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.SERVICES,
      Item: service,
    })
  );

  return service;
}

export async function updateService(
  id: string,
  data: Partial<Pick<Service, "name" | "description" | "status" | "url">>
): Promise<Service> {
  const updateExpr = [];
  const exprValues: Record<string, unknown> = {};
  const exprNames: Record<string, string> = {};

  if (data.name !== undefined) {
    updateExpr.push("#name = :name");
    exprValues[":name"] = data.name;
    exprNames["#name"] = "name";
  }

  if (data.description !== undefined) {
    updateExpr.push("#description = :description");
    exprValues[":description"] = data.description;
    exprNames["#description"] = "description";
  }

  if (data.status !== undefined) {
    updateExpr.push("#status = :status");
    exprValues[":status"] = data.status;
    exprNames["#status"] = "status";
  }

  if (data.url !== undefined) {
    updateExpr.push("#url = :url");
    exprValues[":url"] = data.url;
    exprNames["#url"] = "url";
  }

  updateExpr.push("updatedAt = :updatedAt");
  exprValues[":updatedAt"] = new Date().toISOString();

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.SERVICES,
      Key: { id },
      UpdateExpression: `set ${updateExpr.join(", ")}`,
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames:
        Object.keys(exprNames).length > 0 ? exprNames : undefined,
      ReturnValues: "ALL_NEW",
    })
  );

  return result.Attributes as Service;
}

export async function deleteService(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
}

export const SETTINGS_ID = "app";

export interface AppSettings {
  id: string;
  siteName: string;
  maintenanceMode: boolean;
  rulesText?: string;
  privacyText?: string;
  vapidPublicKey?: string;
  vapidPrivateKey?: string;
  vapidSubject?: string;
  /** Комиссия сервиса с одной заявки (₽). Используется при выгрузке
   *  статистики в Excel: итоговый заработок = количество заявок × комиссия.
   *  Задаётся администратором в настройках и/или прямо при выгрузке. */
  commissionPerOrder?: number;
  updatedAt: string;
}

export const DEFAULT_APP_SETTINGS: AppSettings = {
  id: SETTINGS_ID,
  siteName: "Твоё Новое",
  maintenanceMode: false,
  commissionPerOrder: 10,
  updatedAt: "2024-06-01T08:00:00.000Z",
};

export const DEFAULT_PRIVACY_TEXT = `# Политика конфиденциальности сервиса «Твоё Новое»

## 1. Общие положения

1.1. Настоящая Политика описывает, какие данные обрабатывает Сервис «Твоё Новое» (далее — Сервис), как они используются и защищаются.
1.2. Используя Сервис (заказывая поездку, оставляя обратную связь), вы соглашаетесь с обработкой данных на условиях настоящей Политики.
1.3. Сервис является информационно-посредническим: он предоставляет возможность оформить заказ поездки и передаёт его водителям-партнёрам.

## 2. Какие данные мы обрабатываем

2.1. Данные заказа: адреса «откуда» и «куда», промежуточные остановки, подъезды, комментарий водителю, выбранные опции (детское кресло, доставка, багажник).
2.2. Контактные данные: имя и номер телефона (при оформлении заказа), телефон или адрес электронной почты (в форме обратной связи).
2.3. Данные местоположения: координаты точки «откуда», полученные по GPS, — только для заполнения адреса и построения маршрута.
2.4. Технические данные: IP-адрес, данные об устройстве и браузере, файлы cookie — для обеспечения работы Сервиса и защиты от спама.
2.5. Данные водителей: имя, телефон, VK ID, данные автомобиля — для организации перевозок.

## 3. Как мы используем данные

3.1. Для оформления и выполнения заказа (передача адресов и контактов водителю, уведомление о статусе поездки).
3.2. Для отправки уведомлений о заказе (в беседу мессенджера, push-уведомления, звонок при вызове водителя).
3.3. Для улучшения работы Сервиса и защиты от злоупотреблений (например, ограничение частоты заказов с одного IP).
3.4. Для ответа на обращения через форму обратной связи.

## 4. Хранение и защита данных

4.1. Данные хранятся в защищённой базе данных (облачный сервис Яндекс Облако) и не передаются третьим лицам, кроме случаев, необходимых для выполнения заказа (передача контактов водителю) или предусмотренных законом.
4.2. Мы применяем разумные технические меры защиты (HTTPS, ограничение доступа, секретные ключи).

## 5. Передача данных

5.1. Для выполнения заказа данные могут передаваться водителю-партнёру (имя, телефон, адреса).
5.2. При вызове водителя по телефону номера сторон связываются через сервис связи без раскрытия личных номеров (маскировка, если используется).
5.3. Данные не продаются и не передаются в рекламных целях.

## 6. Файлы cookie и локальное хранилище

6.1. Сервис использует cookie и локальное хранилище (localStorage) для корректной работы (например, запоминание закрытия баннера установки приложения, сохранённой геопозиции).

## 7. Ваши права

7.1. Вы вправе запросить информацию об обрабатываемых данных, их исправление или удаление, направив обращение через форму обратной связи.
7.2. Вы можете отключить push-уведомления и геолокацию в настройках браузера/устройства.

## 8. Заключительные положения

8.1. Политика может обновляться. Актуальная версия доступна на этой странице.
8.2. Контакты для обращений: через форму «Обратная связь» внизу сайта.`;

export const DEFAULT_RULES_TEXT = `# Правила пользования сервисом «Твоё Новое»

## 1. Общие положения

1.1. Настоящие Правила регулируют использование сайта/приложения «Твоё Новое» (далее — Сервис), предназначенного для заказа поездок на автомобиле.
1.2. Используя Сервис (заказывая поездку, оставляя обратную связь), вы соглашаетесь с настоящими Правилами. Если вы не согласны — пожалуйста, не используйте Сервис.
1.3. Сервис является информационно-посредническим: он предоставляет возможность оформить заказ поездки и передаёт его водителям-партнёрам. Стороны поездки (клиент и водитель) заключают договор фрахтования непосредственно между собой.

## 2. Условия заказа поездки

2.1. Для заказа поездки авторизация не требуется. Вы можете указать адреса «откуда» и «куда» вручную, выбрать их на карте или определить местоположение по GPS.
2.2. Оформляя заказ, вы подтверждаете, что указанные адреса и контактные данные корректны.
2.3. Стоимость поездки по городу фиксированная и зависит от времени суток: 150 ₽ днём (05:00–22:00), 180 ₽ в час пик (06:00–09:00 и 16:00–18:00), 200 ₽ ночью (22:00–05:00). Пригородные и загородные тарифы уточняются у водителя. Для отдельных адресов может действовать особый тариф, установленный администратором.
2.4. Дополнительные услуги: детское кресло (без изменения цены), доставка (350 ₽, отдельная услуга), багажник (+50 ₽ к тарифу).
2.5. Заказ принимает первый свободный водитель. Если в течение 15 минут водитель не найден, заказ автоматически отменяется.

## 3. Расчёты и платежи

3.1. Все расчёты и платежи между клиентом и водителем производятся непосредственно водителем с клиентом — наличными или иным согласованным сторонами способом. Сервис не принимает оплату за поездки и не является платёжным агентом.
3.2. Стоимость поездки и дополнительные услуги оплачиваются клиентом водителю напрямую.

## 4. Права и обязанности клиента

4.1. Клиент обязуется не передавать Сервису недостоверные данные и не создавать заказы без намерения их совершить.
4.2. Клиент вправе отменить заказ до его выполнения.
4.3. Клиент может оставить комментарий водителю, указать подъезд и другую уточняющую информацию.

## 5. Права и обязанности водителя

5.1. Водитель, принявший заказ по договору фрахтования, обязан соблюдать действующее законодательство Российской Федерации, включая правила дорожного движения и требования к перевозке пассажиров.
5.2. Водитель должен быть самозанятым или индивидуальным предпринимателем (ИП) и самостоятельно оплачивать соответствующие налоговые пошлины и налоги в соответствии с законодательством РФ.
5.3. Водитель несёт ответственность за безопасность перевозки в соответствии с законодательством Российской Федерации.
5.4. Водитель вправе вносить добровольные взносы Сервису для поддержания его работы в сети. Добровольные взносы не являются обязательными платежами и не заменяют оплату налогов.

## 6. Ответственность Сервиса

6.1. Сервис не является перевозчиком и не несёт ответственности за действия водителей и клиентов в рамках исполнения поездки.
6.2. Сервис прилагает разумные усилия для стабильной работы, но не гарантирует отсутствие технических сбоев.

## 7. Запрещённое использование

7.1. Запрещается использовать Сервис для противоправных целей, для автоматических/ботовых заказов с целью спама, а также любым способом, нарушающим права третьих лиц.

## 8. Заключительные положения

8.1. Администрация вправе изменять настоящие Правила. Актуальная версия всегда доступна на этой странице.
8.2. Контакты для обращений: через форму «Обратная связь» внизу сайта.`;

export async function getAppSettings(): Promise<AppSettings> {
  if (!(await isDatabaseAvailable())) {
    return { ...DEFAULT_APP_SETTINGS };
  }
  try {
    const result = await docClient.send(
      new GetCommand({
        TableName: TableName.SETTINGS,
        Key: { id: SETTINGS_ID },
      })
    );
    return (result.Item as AppSettings) ?? { ...DEFAULT_APP_SETTINGS };
  } catch (error) {
    console.warn("Не удалось получить настройки приложения:", error);
    return { ...DEFAULT_APP_SETTINGS };
  }
}

export async function updateAppSettings(
  data: Partial<
    Pick<
      AppSettings,
      | "siteName"
      | "maintenanceMode"
      | "rulesText"
      | "privacyText"
      | "vapidPublicKey"
      | "vapidPrivateKey"
      | "vapidSubject"
      | "commissionPerOrder"
    >
  >
): Promise<AppSettings> {
  const current = await getAppSettings();
  // Применяем только переданные поля: undefined означает «не менять», чтобы
  // сохранение одной группы настроек (например, «Настройки сайта» без полей
  // rulesText/privacyText) не затирало тексты правил и политики.
  const merged: AppSettings = {
    ...current,
    siteName: data.siteName ?? current.siteName,
    maintenanceMode: data.maintenanceMode ?? current.maintenanceMode,
    id: SETTINGS_ID,
    updatedAt: new Date().toISOString(),
  };
  if (data.rulesText !== undefined) merged.rulesText = data.rulesText;
  if (data.privacyText !== undefined) merged.privacyText = data.privacyText;
  if (data.commissionPerOrder !== undefined)
    merged.commissionPerOrder = data.commissionPerOrder;
  if (data.vapidPublicKey !== undefined)
    merged.vapidPublicKey = data.vapidPublicKey;
  if (data.vapidPrivateKey !== undefined)
    merged.vapidPrivateKey = data.vapidPrivateKey;
  if (data.vapidSubject !== undefined) merged.vapidSubject = data.vapidSubject;
  await docClient.send(
    new PutCommand({
      TableName: TableName.SETTINGS,
      Item: merged,
    })
  );
  return merged;
}

export interface PushSubscriptionDoc {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
  userAgent?: string;
  createdAt: string;
  updatedAt: string;
}

export async function getAllPushSubscriptions(): Promise<
  PushSubscriptionDoc[]
> {
  if (!(await isDatabaseAvailable())) return [];
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.PUSH_SUBSCRIPTIONS,
    })
  );
  return ((result.Items as PushSubscriptionDoc[]) ?? []).sort((a, b) =>
    (b.createdAt ?? "").localeCompare(a.createdAt ?? "")
  );
}

export async function savePushSubscription(
  data: Pick<PushSubscriptionDoc, "endpoint" | "keys" | "userAgent">
): Promise<PushSubscriptionDoc> {
  const now = new Date().toISOString();
  const doc: PushSubscriptionDoc = {
    endpoint: data.endpoint,
    keys: {
      p256dh: data.keys.p256dh,
      auth: data.keys.auth,
    },
    userAgent: data.userAgent,
    createdAt: now,
    updatedAt: now,
  };
  await docClient.send(
    new PutCommand({
      TableName: TableName.PUSH_SUBSCRIPTIONS,
      Item: doc,
    })
  );
  return doc;
}

export async function deletePushSubscription(endpoint: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.PUSH_SUBSCRIPTIONS,
      Key: { endpoint },
    })
  );
}

export interface PushMessageDoc {
  id: string;
  title?: string;
  body: string;
  sentAt: string;
  recipients: number;
  sent: number;
  failed: number;
}

export async function getAllPushMessages(): Promise<PushMessageDoc[]> {
  if (!(await isDatabaseAvailable())) return [];
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.PUSH_MESSAGES,
    })
  );
  return ((result.Items as PushMessageDoc[]) ?? []).sort((a, b) =>
    (b.sentAt ?? "").localeCompare(a.sentAt ?? "")
  );
}

export async function createPushMessage(
  data: Omit<PushMessageDoc, "id">
): Promise<PushMessageDoc> {
  const doc: PushMessageDoc = {
    ...data,
    id: crypto.randomUUID(),
  };
  await docClient.send(
    new PutCommand({
      TableName: TableName.PUSH_MESSAGES,
      Item: doc,
    })
  );
  return doc;
}

export interface Feedback {
  id: string;
  name?: string;
  contact: string;
  message: string;
  createdAt: string;
}

export async function getAllFeedback(): Promise<Feedback[]> {
  if (!(await isDatabaseAvailable())) return [];
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.FEEDBACK,
    })
  );
  return ((result.Items as Feedback[]) ?? []).sort((a, b) =>
    (b.createdAt ?? "").localeCompare(a.createdAt ?? "")
  );
}

export async function createFeedback(
  data: Omit<Feedback, "id" | "createdAt">
): Promise<Feedback> {
  const doc: Feedback = {
    ...data,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };
  await docClient.send(
    new PutCommand({
      TableName: TableName.FEEDBACK,
      Item: doc,
    })
  );
  return doc;
}

export async function deleteFeedback(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.FEEDBACK,
      Key: { id },
    })
  );
}

// Пригородные/загородные направления (адреса), которые администратор добавляет
// в настройках админ-панели. Для каждого задаётся цена «везти» и «забрать»,
// а также опции добавки «час-пик» и «ночь» (включается и сумма редактируется).
export interface SuburbanAddress {
  id: string;
  name: string;
  priceTo: number;
  priceFrom: number;
  peakEnabled: boolean;
  peakSurcharge: number;
  nightEnabled: boolean;
  nightSurcharge: number;
  createdAt: string;
  updatedAt: string;
}

export async function getAllSuburbanAddresses(): Promise<SuburbanAddress[]> {
  if (!(await isDatabaseAvailable())) return [];
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.SUBURBAN_ADDRESSES,
    })
  );
  return ((result.Items as SuburbanAddress[]) ?? []).sort((a, b) =>
    (a.name ?? "").localeCompare(b.name ?? "", "ru")
  );
}

export async function getSuburbanAddressById(
  id: string
): Promise<SuburbanAddress | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.SUBURBAN_ADDRESSES,
      Key: { id },
    })
  );
  return (result.Item as SuburbanAddress) ?? null;
}

export async function createSuburbanAddress(
  data: Omit<SuburbanAddress, "id" | "createdAt" | "updatedAt">
): Promise<SuburbanAddress> {
  const now = new Date().toISOString();
  const address: SuburbanAddress = {
    ...data,
    id: crypto.randomUUID(),
    createdAt: now,
    updatedAt: now,
  };
  await docClient.send(
    new PutCommand({
      TableName: TableName.SUBURBAN_ADDRESSES,
      Item: address,
    })
  );
  return address;
}

export async function updateSuburbanAddress(
  id: string,
  data: Partial<Omit<SuburbanAddress, "id" | "createdAt" | "updatedAt">>
): Promise<SuburbanAddress> {
  const existing = await getSuburbanAddressById(id);
  if (!existing) {
    throw new Error("SUBURBAN_ADDRESS_NOT_FOUND");
  }
  const merged: SuburbanAddress = {
    ...existing,
    ...data,
    id,
    updatedAt: new Date().toISOString(),
  };
  await docClient.send(
    new PutCommand({
      TableName: TableName.SUBURBAN_ADDRESSES,
      Item: merged,
    })
  );
  return merged;
}

export async function deleteSuburbanAddress(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.SUBURBAN_ADDRESSES,
      Key: { id },
    })
  );
}

// Популярные места (например, «Лихолесье»), которые администратор добавляет в
// настройках админ-панели. Они показываются клиенту в подсказках адресов в
// форме заказа (поля «Откуда»/«Куда» и промежуточные остановки): при наборе
// текста, совпадающего с началом названия, место появляется в подсказках.
export interface PopularPlace {
  id: string;
  name: string;
  /** Необязательный адрес/улица места (например, «Монтажная ул., 5»). */
  address?: string;
  /** Необязательная фиксированная цена поездки до/от этого места (₽).
   *  Если задана — заменяет стандартный тариф по городу при выборе места
   *  клиентом в форме заказа. */
  price?: number;
  createdAt: string;
  updatedAt: string;
}

export async function getAllPopularPlaces(): Promise<PopularPlace[]> {
  if (!(await isDatabaseAvailable())) return [];
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.POPULAR_PLACES,
    })
  );
  return ((result.Items as PopularPlace[]) ?? []).sort((a, b) =>
    (a.name ?? "").localeCompare(b.name ?? "", "ru")
  );
}

export async function getPopularPlaceById(
  id: string
): Promise<PopularPlace | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.POPULAR_PLACES,
      Key: { id },
    })
  );
  return (result.Item as PopularPlace) ?? null;
}

export type PopularPlaceWrite = Omit<
  PopularPlace,
  "id" | "createdAt" | "updatedAt" | "price" | "address"
> & {
  address?: string | null;
  price?: number | null;
};

export async function createPopularPlace(
  data: PopularPlaceWrite
): Promise<PopularPlace> {
  const now = new Date().toISOString();
  const place: Record<string, unknown> = {
    ...data,
    id: crypto.randomUUID(),
    createdAt: now,
    updatedAt: now,
  };
  // Явный null для необязательных полей означает отсутствие значения.
  if (place.price == null) {
    delete place.price;
  }
  if (place.address == null) {
    delete place.address;
  }
  await docClient.send(
    new PutCommand({
      TableName: TableName.POPULAR_PLACES,
      Item: place,
    })
  );
  return place as unknown as PopularPlace;
}

export async function updatePopularPlace(
  id: string,
  data: Partial<PopularPlaceWrite>
): Promise<PopularPlace> {
  const existing = await getPopularPlaceById(id);
  if (!existing) {
    throw new Error("POPULAR_PLACE_NOT_FOUND");
  }
  const merged: Record<string, unknown> = {
    ...existing,
    ...data,
    id,
    updatedAt: new Date().toISOString(),
  };
  // Явный null для необязательных полей означает удаление значения
  // (например, администратор очистил цену поездки).
  if (data.price === null) {
    delete merged.price;
  }
  if (data.address === null) {
    delete merged.address;
  }
  await docClient.send(
    new PutCommand({
      TableName: TableName.POPULAR_PLACES,
      Item: merged,
    })
  );
  return merged as unknown as PopularPlace;
}

export async function deletePopularPlace(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.POPULAR_PLACES,
      Key: { id },
    })
  );
}
