export const GEOLOCATION_REASK_INTERVAL_MS = 24 * 60 * 60 * 1000;

const ASKED_AT_KEY = "taxi-geolocation-asked-at";
const POSITION_KEY = "taxi-client-position";

export interface ClientPosition {
  lat: number;
  lng: number;
  accuracy: number;
  at: number;
}

export function isGeolocationSupported(): boolean {
  return typeof navigator !== "undefined" && "geolocation" in navigator;
}

export function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!isGeolocationSupported()) {
      reject(new Error("Геолокация не поддерживается"));
      return;
    }
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10_000,
      maximumAge: 0,
    });
  });
}

function lastAskedAt(): number {
  try {
    const raw = window.localStorage.getItem(ASKED_AT_KEY);
    const value = raw ? Number(raw) : 0;
    return Number.isFinite(value) ? value : 0;
  } catch {
    return 0;
  }
}

function markAsked(): void {
  try {
    window.localStorage.setItem(ASKED_AT_KEY, String(Date.now()));
  } catch {
    return;
  }
}

export function savePosition(position: GeolocationPosition): void {
  const data: ClientPosition = {
    lat: position.coords.latitude,
    lng: position.coords.longitude,
    accuracy: position.coords.accuracy,
    at: position.timestamp,
  };
  try {
    window.localStorage.setItem(POSITION_KEY, JSON.stringify(data));
  } catch {
    return;
  }
}

export function getSavedPosition(): ClientPosition | null {
  try {
    const raw = window.localStorage.getItem(POSITION_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<ClientPosition>;
    if (
      typeof data?.lat === "number" &&
      typeof data?.lng === "number" &&
      typeof data?.accuracy === "number" &&
      typeof data?.at === "number"
    ) {
      return data as ClientPosition;
    }
    return null;
  } catch {
    return null;
  }
}

export async function maybeRequestGeolocationPermission(): Promise<boolean> {
  if (!isGeolocationSupported()) return false;

  let state: PermissionState | null = null;
  try {
    if (navigator.permissions?.query) {
      const status = await navigator.permissions.query({
        name: "geolocation",
      });
      state = status.state;
    }
  } catch {
    state = null;
  }

  if (state === "granted" || state === "denied") return false;
  if (Date.now() - lastAskedAt() < GEOLOCATION_REASK_INTERVAL_MS) {
    return false;
  }
  markAsked();

  try {
    const position = await getCurrentPosition();
    savePosition(position);
    return true;
  } catch {
    return false;
  }
}
