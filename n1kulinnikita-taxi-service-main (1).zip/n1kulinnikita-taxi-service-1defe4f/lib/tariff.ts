// Единый тариф по городу.
// Цена зависит от времени суток (по местному времени клиента).
//  - Обычное дневное время (05:00–22:00) — 150 ₽
//  - Час пик утром (06:00–09:00) — 180 ₽
//  - Час пик вечером (16:00–18:00) — 180 ₽
//  - Ночью (22:00–05:00) — 200 ₽
// Пригородные и загородные маршруты — тариф уточняется у водителя.

export interface CityTariff {
  price: number;
  label: string;
  period: string;
  window: string;
}

export const DELIVERY_PRICE = 350;
export const TRUNK_PRICE = 50;

const BASE_DAY_PRICE = 150;
const PEAK_PRICE = 180;
const NIGHT_PRICE = 200;

export function getCityTariff(date: Date = new Date()): CityTariff {
  const minutes = date.getHours() * 60 + date.getMinutes();

  const isMorningPeak = minutes >= 6 * 60 && minutes < 9 * 60;
  const isEveningPeak = minutes >= 16 * 60 && minutes < 18 * 60;
  const isDaytime = minutes >= 5 * 60 && minutes < 22 * 60;

  if (isMorningPeak || isEveningPeak) {
    return {
      price: PEAK_PRICE,
      label: "Час пик",
      period: "в час пик",
      window: "06:00–09:00 и 16:00–18:00",
    };
  }
  if (isDaytime) {
    return {
      price: BASE_DAY_PRICE,
      label: "Дневной тариф",
      period: "днём",
      window: "05:00–22:00",
    };
  }
  return {
    price: NIGHT_PRICE,
    label: "Ночной тариф",
    period: "ночью",
    window: "22:00–05:00",
  };
}
