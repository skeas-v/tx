import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from "crypto";

const MAGIC = "TAXI-BACKUP";
const VERSION = "v1";
const CIPHER = "aes-256-gcm";
const DEV_KEY = "taxi-backup-dev-key-change-me";

function resolveKey(): Buffer {
  const secret = process.env.BACKUP_ENCRYPTION_KEY ?? DEV_KEY;
  return createHash("sha256").update(secret, "utf8").digest();
}

export function encryptJson(data: unknown): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv(CIPHER, resolveKey(), iv);
  const plaintext = Buffer.from(JSON.stringify(data), "utf8");
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [
    MAGIC,
    VERSION,
    iv.toString("base64"),
    tag.toString("base64"),
    encrypted.toString("base64"),
  ].join(".");
}

export function decryptBackup(payload: string): unknown {
  const parts = payload.split(".");
  if (parts.length !== 5 || parts[0] !== MAGIC || parts[1] !== VERSION) {
    throw new Error("BACKUP_INVALID_FORMAT");
  }
  const [, , ivB64, tagB64, dataB64] = parts;
  const decipher = createDecipheriv(
    CIPHER,
    resolveKey(),
    Buffer.from(ivB64, "base64")
  );
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataB64, "base64")),
    decipher.final(),
  ]);
  return JSON.parse(decrypted.toString("utf8"));
}
