import { promises as fs } from "fs";
import path from "path";
import { PutCommand } from "@aws-sdk/lib-dynamodb";
import { docClient, isDatabaseAvailable } from "./db";
import { encryptJson } from "./encryption";
import {
  mockAdmin,
  mockAppSettings,
  mockCallReviews,
  mockDrivers,
  mockFeedback,
  mockOrders,
  mockPopularPlaces,
  mockPushMessages,
  mockPushSubscriptions,
  mockSuburbanAddresses,
} from "./mock-data";
import {
  Admin,
  AppSettings,
  CallReview,
  Driver,
  Feedback,
  Order,
  PopularPlace,
  PushMessageDoc,
  PushSubscriptionDoc,
  SuburbanAddress,
  attachDriverInfo,
  getAllAdmins,
  getAllFeedback,
  getAllPopularPlaces,
  getAllSuburbanAddresses,
  getAppSettings,
  getAllCallReviews,
  getAllDrivers,
  getAllOrders,
  getAllPushMessages,
  getAllPushSubscriptions,
} from "./models";
import { TableName } from "./schema";

export const EXPORT_DIR = "/sec/bd";
export const BACKUP_VERSION = 5;

export interface SystemBackupPayload {
  version: number;
  app: string;
  exportedAt: string;
  orders: Order[];
  drivers: Driver[];
  settings: {
    admins: Admin[];
    app: AppSettings | null;
  };
  subscriptions: PushSubscriptionDoc[];
  pushMessages: PushMessageDoc[];
  reviews: CallReview[];
  feedback: Feedback[];
  suburbanAddresses: SuburbanAddress[];
  popularPlaces: PopularPlace[];
}

export async function collectSystemData(): Promise<SystemBackupPayload> {
  const exportedAt = new Date().toISOString();

  if (!(await isDatabaseAvailable())) {
    return {
      version: BACKUP_VERSION,
      app: "ride",
      exportedAt,
      orders: mockOrders,
      drivers: mockDrivers,
      settings: { admins: [mockAdmin], app: mockAppSettings },
      subscriptions: mockPushSubscriptions,
      pushMessages: mockPushMessages,
      reviews: mockCallReviews,
      feedback: mockFeedback,
      suburbanAddresses: mockSuburbanAddresses,
      popularPlaces: mockPopularPlaces,
    };
  }

  const [
    orders,
    drivers,
    admins,
    app,
    subscriptions,
    pushMessages,
    reviews,
    feedback,
    suburbanAddresses,
    popularPlaces,
  ] = await Promise.all([
    getAllOrders().then((items) => attachDriverInfo(items)),
    getAllDrivers(),
    getAllAdmins(),
    getAppSettings(),
    getAllPushSubscriptions(),
    getAllPushMessages(),
    getAllCallReviews(),
    getAllFeedback(),
    getAllSuburbanAddresses(),
    getAllPopularPlaces(),
  ]);

  return {
    version: BACKUP_VERSION,
    app: "ride",
    exportedAt,
    orders,
    drivers,
    settings: { admins, app },
    subscriptions,
    pushMessages,
    reviews,
    feedback,
    suburbanAddresses,
    popularPlaces,
  };
}

export interface BackupFileResult {
  filename: string;
  path: string;
  exportedAt: string;
  encrypted: string;
  counts: {
    orders: number;
    drivers: number;
    settings: number;
    subscriptions: number;
    pushMessages: number;
    reviews: number;
    feedback: number;
    suburbanAddresses: number;
    popularPlaces: number;
  };
}

export async function saveEncryptedBackup(): Promise<BackupFileResult> {
  const payload = await collectSystemData();
  const filename = `backup-${payload.exportedAt.replace(/[:.]/g, "-")}.enc`;
  const filePath = path.join(EXPORT_DIR, filename);
  const encrypted = encryptJson(payload);

  await fs.mkdir(EXPORT_DIR, { recursive: true });
  await fs.writeFile(filePath, encrypted, "utf8");

  return {
    filename,
    path: filePath,
    exportedAt: payload.exportedAt,
    encrypted: "aes-256-gcm",
    counts: {
      orders: payload.orders.length,
      drivers: payload.drivers.length,
      settings:
        payload.settings?.admins?.length ?? (payload.settings?.app ? 1 : 0),
      subscriptions: payload.subscriptions.length,
      pushMessages: payload.pushMessages.length,
      reviews: payload.reviews.length,
      feedback: payload.feedback.length,
      suburbanAddresses: payload.suburbanAddresses?.length ?? 0,
      popularPlaces: payload.popularPlaces?.length ?? 0,
    },
  };
}

/** Восстанавливает данные из файла бэкапа (перезаписывает по ключам). */
export async function restoreBackup(payload: SystemBackupPayload): Promise<{
  orders: number;
  drivers: number;
  subscriptions: number;
  pushMessages: number;
  reviews: number;
  feedback: number;
  suburbanAddresses: number;
  popularPlaces: number;
}> {
  if (!(await isDatabaseAvailable())) {
    throw new Error("DATABASE_UNAVAILABLE");
  }

  const put = (table: TableName, item: unknown) =>
    docClient.send(
      new PutCommand({
        TableName: table,
        Item: item as Record<string, unknown>,
      })
    );

  const orders = payload.orders ?? [];
  const drivers = payload.drivers ?? [];
  const subscriptions = payload.subscriptions ?? [];
  const pushMessages = payload.pushMessages ?? [];
  const reviews = payload.reviews ?? [];
  const feedback = payload.feedback ?? [];
  const suburbanAddresses = payload.suburbanAddresses ?? [];
  const popularPlaces = payload.popularPlaces ?? [];

  await Promise.all([
    ...orders.map((order) => put(TableName.ORDERS, order)),
    ...drivers.map((driver) => put(TableName.DRIVERS, driver)),
    ...subscriptions.map((sub) => put(TableName.PUSH_SUBSCRIPTIONS, sub)),
    ...pushMessages.map((msg) => put(TableName.PUSH_MESSAGES, msg)),
    ...reviews.map((review) => put(TableName.CALL_REVIEWS, review)),
    ...feedback.map((item) => put(TableName.FEEDBACK, item)),
    ...suburbanAddresses.map((item) => put(TableName.SUBURBAN_ADDRESSES, item)),
    ...popularPlaces.map((item) => put(TableName.POPULAR_PLACES, item)),
  ]);

  if (payload.settings?.admins?.length) {
    for (const admin of payload.settings.admins) {
      if (admin && admin.id && admin.login) {
        await put(TableName.ADMINS, admin);
      }
    }
  }
  if (payload.settings?.app) {
    const appSettings: AppSettings = {
      ...payload.settings.app,
      id: "app",
      updatedAt: new Date().toISOString(),
    };
    await put(TableName.SETTINGS, appSettings);
  }

  return {
    orders: orders.length,
    drivers: drivers.length,
    subscriptions: subscriptions.length,
    pushMessages: pushMessages.length,
    reviews: reviews.length,
    feedback: feedback.length,
    suburbanAddresses: suburbanAddresses.length,
    popularPlaces: popularPlaces.length,
  };
}
