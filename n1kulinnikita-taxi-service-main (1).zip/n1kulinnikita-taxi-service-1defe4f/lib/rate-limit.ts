import { NextRequest, NextResponse } from "next/server";

// Ограничение частоты запросов в памяти сервера. Хранится в глобальном
// объекте, чтобы переживать hot-reload в dev-режиме, и живёт в рамках
// одного запущенного экземпляра приложения.

type RateLimitKey = "orders" | "ordersCall" | "feedback" | "adminLogin";

type RateLimitConfig = { seconds: number; max: number };

const RATE_LIMIT_CHECKS: Record<RateLimitKey, RateLimitConfig[]> = {
  // Заказы с одного IP: не более 5 в минуту и 20 в час.
  orders: [
    { seconds: 60, max: 5 },
    { seconds: 60 * 60, max: 20 },
  ],
  // Вызов по телефону: 5 попыток в минуту и 20 в час.
  ordersCall: [
    { seconds: 60, max: 5 },
    { seconds: 60 * 60, max: 20 },
  ],
  // Обратная связь: не чаще 3 обращений в минуту и 20 в час.
  feedback: [
    { seconds: 60, max: 3 },
    { seconds: 60 * 60, max: 20 },
  ],
  // Вход в админ-панель: не более 10 попыток в минуту с одного IP (защита
  // от перебора паролей; блокировку по логину обеспечивает security-tracker).
  adminLogin: [{ seconds: 60, max: 10 }],
};

const MAX_RECORDED_ENTRIES = 60;

const globalForRateLimit = globalThis as unknown as {
  _rateLimitBuckets?: Map<string, { timestamps: number[] }>;
};

function getBuckets(): Map<string, { timestamps: number[] }> {
  if (!globalForRateLimit._rateLimitBuckets) {
    globalForRateLimit._rateLimitBuckets = new Map();
  }
  return globalForRateLimit._rateLimitBuckets;
}

function getIp(request: NextRequest): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  const realIp = request.headers.get("x-real-ip");
  if (realIp) return realIp;
  const cfConnectingIp = request.headers.get("cf-connecting-ip");
  if (cfConnectingIp) return cfConnectingIp;
  return "unknown";
}

export function clientIp(request: NextRequest): string {
  return getIp(request);
}

function sweep(bucketKey: string, seconds: number, now: number): number {
  const buckets = getBuckets();
  const entry = buckets.get(bucketKey);
  if (!entry) {
    return 0;
  }
  const cutoff = now - seconds * 1000;
  const kept: number[] = [];
  for (const ts of entry.timestamps) {
    if (ts > cutoff) kept.push(ts);
  }
  entry.timestamps = kept;
  return kept.length;
}

function bump(bucketKey: string): void {
  const buckets = getBuckets();
  const existing = buckets.get(bucketKey);
  if (existing) {
    existing.timestamps.push(Date.now());
    if (existing.timestamps.length > MAX_RECORDED_ENTRIES) {
      existing.timestamps = existing.timestamps.slice(-MAX_RECORDED_ENTRIES);
    }
  } else {
    buckets.set(bucketKey, { timestamps: [Date.now()] });
  }
}

export type CheckResult =
  | { allowed: true }
  | { allowed: false; retryAfterSeconds: number };

function check(request: NextRequest, key: RateLimitKey): CheckResult {
  const checks = RATE_LIMIT_CHECKS[key];
  const ip = getIp(request);
  const now = Date.now();
  const baseKey = `${key}:ip:${ip}`;

  for (const { seconds, max } of checks) {
    const bucketKey = `${baseKey}:${seconds}`;
    const hits = sweep(bucketKey, seconds, now);
    if (hits >= max) {
      return { allowed: false, retryAfterSeconds: seconds };
    }
  }

  for (const { seconds } of checks) {
    bump(`${baseKey}:${seconds}`);
  }
  return { allowed: true };
}

export function checkOrderRateLimit(request: NextRequest): CheckResult {
  return check(request, "orders");
}

export function checkOrdersCallRateLimit(request: NextRequest): CheckResult {
  return check(request, "ordersCall");
}

export function checkFeedbackRateLimit(request: NextRequest): CheckResult {
  return check(request, "feedback");
}

export function checkAdminLoginRateLimit(request: NextRequest): CheckResult {
  return check(request, "adminLogin");
}

export function tooManyRequestsResponse(
  kind: "orders" | "feedback" | "adminLogin",
  retryAfterSeconds: number
): NextResponse {
  const messages: Record<string, string> = {
    orders:
      "Слишком много заказов. Отправлено слишком много заявок, попробуйте позже.",
    feedback:
      "Слишком много сообщений. Отправлено слишком много обращений, попробуйте позже.",
    adminLogin:
      "Слишком много попыток входа. Подождите немного и попробуйте снова.",
  };
  const response = NextResponse.json(
    { error: messages[kind] },
    { status: 429 }
  );
  response.headers.set("Retry-After", String(retryAfterSeconds));
  return response;
}
