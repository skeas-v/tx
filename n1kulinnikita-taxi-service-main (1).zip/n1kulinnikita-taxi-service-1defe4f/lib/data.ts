// Статические данные-заглушки для главной страницы (задача task-001).
// Используются только для отображения прототипа и не связаны с БД.

export const tariffs = [
  {
    id: "econom",
    name: "Эконом",
    description: "Повседневные поездки по городу",
    pricePerKm: 32,
    capacity: "1–4",
    minutes: "5",
  },
  {
    id: "comfort",
    name: "Комфорт",
    description: "Универсальное решение для деловых поездок",
    pricePerKm: 48,
    capacity: "1–4",
    minutes: "7",
  },
  {
    id: "business",
    name: "Бизнес",
    description: "Автомобили премиум-класса и вежливые водители",
    pricePerKm: 75,
    capacity: "1–3",
    minutes: "10",
  },
  {
    id: "minivan",
    name: "Минивэн",
    description: "Вместительный автомобиль для компании и багажа",
    pricePerKm: 60,
    capacity: "1–7",
    minutes: "12",
  },
];

export const popularRoutes = [
  {
    id: "route-1",
    from: "Аэропорт Шереметьево",
    to: "Красная площадь",
    price: "от 890 ₽",
    time: "около 40 мин",
  },
  {
    id: "route-2",
    from: "Ж/д вокзал Павелецкий",
    to: "Москва Сити",
    price: "от 540 ₽",
    time: "около 25 мин",
  },
  {
    id: "route-3",
    from: "Аэропорт Домодедово",
    to: "Центр города",
    price: "от 1050 ₽",
    time: "около 50 мин",
  },
  {
    id: "route-4",
    from: "МГУ (Воробьёвы горы)",
    to: "ТЦ «Авиапарк»",
    price: "от 480 ₽",
    time: "около 30 мин",
  },
];

export const stats = [
  { label: "Активных водителей", value: "2 340" },
  { label: "Поездок в день", value: "18 500" },
  { label: "Среднее время подачи", value: "7 мин" },
  { label: "Рейтинг сервиса", value: "4.9" },
];
