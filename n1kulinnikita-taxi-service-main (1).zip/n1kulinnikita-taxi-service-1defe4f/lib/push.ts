import webpush from "web-push";
import {
  createPushMessage,
  deletePushSubscription,
  getAllPushSubscriptions,
  type PushSubscriptionDoc,
} from "./models";
import { resolveVapidKeys } from "./vapid";

export interface PushSendResult {
  total: number;
  sent: number;
  failed: number;
  removed: number;
  messageId?: string;
}

interface WebPushError extends Error {
  statusCode?: number;
}

/**
 * Отправляет push-уведомление всем подписанным устройствам.
 * Несуществующие/просроченные подписки (410/404) удаляются из БД.
 * После отправки фиксирует запись в истории отправленных уведомлений.
 */
export async function sendPushToAll(data: {
  title?: string;
  body: string;
}): Promise<PushSendResult> {
  const subscriptions = await getAllPushSubscriptions();
  const result: PushSendResult = {
    total: subscriptions.length,
    sent: 0,
    failed: 0,
    removed: 0,
  };

  if (subscriptions.length === 0) {
    return result;
  }

  const keys = await resolveVapidKeys();
  webpush.setVapidDetails(keys.subject, keys.publicKey, keys.privateKey);

  const payload = JSON.stringify({
    title: data.title?.trim() || "Уведомление",
    body: data.body.trim(),
  });

  const removedEndpoints: string[] = [];

  await Promise.all(
    subscriptions.map(async (subscription: PushSubscriptionDoc) => {
      try {
        await webpush.sendNotification(
          {
            endpoint: subscription.endpoint,
            keys: subscription.keys,
          },
          payload,
          { TTL: 60 * 60 * 24 }
        );
        result.sent += 1;
      } catch (error) {
        result.failed += 1;
        const statusCode = (error as WebPushError)?.statusCode;
        if (statusCode === 404 || statusCode === 410) {
          removedEndpoints.push(subscription.endpoint);
        }
      }
    })
  );

  if (removedEndpoints.length > 0) {
    result.removed = removedEndpoints.length;
    await Promise.all(
      removedEndpoints.map((endpoint) =>
        deletePushSubscription(endpoint).catch(() => undefined)
      )
    );
  }

  try {
    const message = await createPushMessage({
      title: data.title?.trim() || undefined,
      body: data.body.trim(),
      sentAt: new Date().toISOString(),
      recipients: result.total,
      sent: result.sent,
      failed: result.failed,
    });
    result.messageId = message.id;
  } catch (error) {
    console.warn("Не удалось сохранить историю push-уведомления:", error);
  }

  return result;
}
