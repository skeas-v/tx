// Мок-данные для статического режима (без БД)
// Используются когда USE_DATABASE=false или БД недоступна

import {
  Admin,
  AdminRole,
  AppSettings,
  CallReview,
  DEFAULT_PRIVACY_TEXT,
  DEFAULT_RULES_TEXT,
  Driver,
  Feedback,
  Order,
  PopularPlace,
  PushMessageDoc,
  PushSubscriptionDoc,
  Service,
  SuburbanAddress,
} from "./models";
import { hashPassword } from "./password";

export const mockAppSettings: AppSettings = {
  id: "app",
  siteName: "Твоё Новое",
  maintenanceMode: false,
  commissionPerOrder: 10,
  rulesText: DEFAULT_RULES_TEXT,
  privacyText: DEFAULT_PRIVACY_TEXT,
  updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
};

export const mockAdmin: Admin = {
  id: "admin",
  login: "admin",
  role: AdminRole.DEVELOPER,
  password: hashPassword("admin"),
  createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
};

export const mockDrivers: Driver[] = [
  {
    id: "+7 900 000-00-10",
    name: "Иван Петров",
    phone: "+7 900 000-00-10",
    vkId: "100001",
    carMake: "Toyota Camry",
    carNumber: "А123ВС77",
    carColor: "Белый",
    isOnLine: false,
    password: hashPassword("123456"),
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  },
  {
    id: "+7 900 000-00-11",
    name: "Сергей Козлов",
    phone: "+7 900 000-00-11",
    carMake: "Kia Rio",
    carNumber: "В456КЕ777",
    carColor: "Серый",
    isOnLine: true,
    password: hashPassword("123456"),
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  },
  {
    id: "+7 900 000-00-12",
    name: "Анна Соколова",
    phone: "+7 900 000-00-12",
    carMake: "Hyundai Solaris",
    carNumber: "К789МН50",
    carColor: "Красный",
    isOnLine: false,
    password: hashPassword("123456"),
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  },
];

export const mockOrders: Order[] = [
  {
    id: "00001",
    from: "ул. Ленина, д. 1",
    to: "ул. Строителей, д. 5",
    fromAddress: "Кировская область, Кирово-Чепецк, улица Ленина, 1",
    toAddress: "Кировская область, Кирово-Чепецк, улица Строителей, 5",
    fromEntrance: "2",
    toEntrance: "1",
    clientName: "Дмитрий",
    clientPhone: "+7 900 000-00-03",
    comment: "Позвоните за 5 минут, подъезд со двора",
    driverId: "+7 900 000-00-10",
    driverName: "Иван Петров",
    delivery: true,
    trunk: true,
    paymentMethod: "cash",
    cashChangeFrom: 500,
    status: "assigned",
    createdAt: new Date("2024-06-01T10:10:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T10:15:00Z").toISOString(),
  },
  {
    id: "00004",
    from: "ул. Молодой Гвардии, д. 3",
    to: "ул. Ленина, д. 1",
    fromAddress: "Кировская область, Кирово-Чепецк, улица Молодой Гвардии, 3",
    toAddress: "Кировская область, Кирово-Чепецк, улица Ленина, 1",
    fromEntrance: "2",
    toEntrance: "4",
    clientName: "Мария",
    clientPhone: "+7 900 000-00-04",
    driverId: "+7 900 000-00-11",
    driverName: "Сергей Козлов",
    paymentMethod: "card",
    status: "in_progress",
    createdAt: new Date("2024-06-01T10:20:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T10:30:00Z").toISOString(),
  },
  {
    id: "00005",
    from: "ул. Витьбина, д. 10",
    to: "пр. Мира, д. 15",
    fromAddress: "Кировская область, Кирово-Чепецк, улица Витьбина, 10",
    toAddress: "Кировская область, Кирово-Чепецк, проспект Мира, 15",
    toEntrance: "1",
    clientName: "Ольга",
    clientPhone: "+7 900 000-00-05",
    driverId: "+7 900 000-00-10",
    driverName: "Иван Петров",
    phoneCall: true,
    confirmResult: "picked_up",
    status: "completed",
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:45:00Z").toISOString(),
  },
  {
    id: "00006",
    from: "ул. Кирова, д. 17",
    to: "ул. Строителей, д. 5",
    fromAddress: "Кировская область, Кирово-Чепецк, улица Кирова, 17",
    toAddress: "Кировская область, Кирово-Чепецк, улица Строителей, 5",
    fromEntrance: "1",
    clientName: "Татьяна",
    clientPhone: "+7 900 000-00-06",
    driverId: "+7 900 000-00-11",
    driverName: "Сергей Козлов",
    phoneCall: true,
    confirmResult: null,
    status: "waiting",
    createdAt: new Date("2024-06-01T11:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T11:00:00Z").toISOString(),
  },
];

export const mockCallReviews: CallReview[] = [
  {
    id: "mock-review-1",
    orderId: "00005",
    driverId: "+7 900 000-00-10",
    driverName: "Иван Петров",
    clientName: "Ольга",
    clientPhone: "+7 900 000-00-05",
    review: "Водитель не ответил на звонок, пришлось искать другую машину.",
    createdAt: new Date("2024-06-01T08:20:00Z").toISOString(),
  },
];

export const mockPushSubscriptions: PushSubscriptionDoc[] = [
  {
    endpoint: "https://example.com/push/mock-endpoint-1",
    keys: {
      p256dh: "mock-p256dh-key-1",
      auth: "mock-auth-key-1",
    },
    userAgent: "Chrome / desktop",
    createdAt: new Date("2024-06-01T08:30:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:30:00Z").toISOString(),
  },
];

export const mockPushMessages: PushMessageDoc[] = [
  {
    id: "mock-push-1",
    title: "Машина назначена",
    body: "К Вам приедет Toyota Camry, А123ВС77.",
    sentAt: new Date("2024-06-01T08:40:00Z").toISOString(),
    recipients: 1,
    sent: 1,
    failed: 0,
  },
];

export const mockFeedback: Feedback[] = [
  {
    id: "mock-feedback-1",
    name: "Иван",
    contact: "+7 900 000-00-20",
    message: "Подскажите, работает ли ночной тариф в выходные?",
    createdAt: new Date("2024-06-01T09:00:00Z").toISOString(),
  },
  {
    id: "mock-feedback-2",
    name: "Мария",
    contact: "maria@example.com",
    message: "Просьба добавить возможность предзаказа на конкретное время.",
    createdAt: new Date("2024-06-02T12:30:00Z").toISOString(),
  },
];

export const mockSuburbanAddresses: SuburbanAddress[] = [
  {
    id: "mock-suburban-1",
    name: "5-ое садоводство",
    priceTo: 250,
    priceFrom: 350,
    peakEnabled: true,
    peakSurcharge: 30,
    nightEnabled: true,
    nightSurcharge: 50,
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  },
  {
    id: "mock-suburban-2",
    name: "ДСК «Полесье»",
    priceTo: 300,
    priceFrom: 400,
    peakEnabled: false,
    peakSurcharge: 0,
    nightEnabled: true,
    nightSurcharge: 60,
    createdAt: new Date("2024-06-01T09:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T09:00:00Z").toISOString(),
  },
];

export const mockPopularPlaces: PopularPlace[] = [
  {
    id: "mock-popular-place-1",
    name: "Лихолесье",
    address: "Монтажная ул., 5",
    price: 30,
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  },
  {
    id: "mock-popular-place-2",
    name: "ЦРБ",
    createdAt: new Date("2024-06-01T08:00:00Z").toISOString(),
    updatedAt: new Date("2024-06-01T08:00:00Z").toISOString(),
  },
];

export const mockServices: Service[] = [
  {
    id: "mock-service-1",
    name: "API Gateway",
    description: "Шлюз для микросервисной архитектуры",
    status: "active",
    url: "https://api.example.com",
    createdAt: new Date("2024-01-15").toISOString(),
    updatedAt: new Date("2024-01-15").toISOString(),
  },
  {
    id: "mock-service-2",
    name: "Auth Service",
    description: "Сервис аутентификации и авторизации",
    status: "active",
    url: "https://auth.example.com",
    createdAt: new Date("2024-02-01").toISOString(),
    updatedAt: new Date("2024-02-01").toISOString(),
  },
  {
    id: "mock-service-3",
    name: "ML Pipeline",
    description: "Пайплайн для обработки данных с AI",
    status: "deploying",
    url: undefined,
    createdAt: new Date("2024-03-10").toISOString(),
    updatedAt: new Date("2024-03-10").toISOString(),
  },
];
