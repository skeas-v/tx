export const NOTIFICATION_CHECK_INTERVAL_MS = 10 * 60 * 1000;
export const NOTIFICATION_REASK_INTERVAL_MS = 24 * 60 * 60 * 1000;

const ASKED_AT_KEY = "taxi-notification-asked-at";

export function isNotificationSupported(): boolean {
  return typeof window !== "undefined" && "Notification" in window;
}

export function getNotificationPermission(): NotificationPermission | null {
  if (!isNotificationSupported()) return null;
  return Notification.permission;
}

export function requestNotificationPermission(): Promise<NotificationPermission | null> {
  if (!isNotificationSupported()) return Promise.resolve(null);
  return Notification.requestPermission();
}

function lastAskedAt(): number {
  try {
    const raw = window.localStorage.getItem(ASKED_AT_KEY);
    const value = raw ? Number(raw) : 0;
    return Number.isFinite(value) ? value : 0;
  } catch {
    return 0;
  }
}

function markAsked(): void {
  try {
    window.localStorage.setItem(ASKED_AT_KEY, String(Date.now()));
  } catch {
    return;
  }
}

export function maybeRequestNotificationPermission(): Promise<boolean> {
  if (getNotificationPermission() !== "default") {
    return Promise.resolve(false);
  }
  if (Date.now() - lastAskedAt() < NOTIFICATION_REASK_INTERVAL_MS) {
    return Promise.resolve(false);
  }
  markAsked();
  return requestNotificationPermission().then((result) => result === "granted");
}

export function showBrowserNotification(
  title: string,
  options?: NotificationOptions
): boolean {
  if (getNotificationPermission() !== "granted") return false;
  try {
    new Notification(title, options);
    return true;
  } catch {
    return false;
  }
}
