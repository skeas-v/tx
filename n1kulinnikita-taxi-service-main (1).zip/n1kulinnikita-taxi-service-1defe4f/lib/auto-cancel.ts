import { isDatabaseAvailable } from "./db";
import { cancelExpiredWaitingOrders, formatOrderNumber } from "./models";
import { autoCancelOrderInVkGroup, sendTextToVkGroup } from "./vk-notify";

// Интервал проверки заказов, ожидающих водителя. Выбран заметно меньше
// таймаута автоотмены (15 минут), чтобы отмена происходила практически сразу
// после истечения 15 минут с момента создания заказа.
const AUTO_CANCEL_INTERVAL_MS = 60 * 1000;

// Минимальная пауза между уведомлениями в беседу ВКонтакте об одном и том же
// автоотменённом заказе: защита от дублей при одновременной работе нескольких
// экземпляров приложения (несколько контейнеров/процессов dev-сервера).
const AUTO_CANCEL_NOTIFY_GRACE_MS = 5 * 60 * 1000;

const globalForAutoCancel = globalThis as unknown as {
  autoCancelStarted?: boolean;
  autoCancelNotifyMap?: Map<string, number>;
};

function getNotifyMap(): Map<string, number> {
  if (!globalForAutoCancel.autoCancelNotifyMap) {
    globalForAutoCancel.autoCancelNotifyMap = new Map();
  }
  return globalForAutoCancel.autoCancelNotifyMap;
}

async function runAutoCancel(): Promise<void> {
  try {
    if (!(await isDatabaseAvailable())) {
      return;
    }
    const cancelled = await cancelExpiredWaitingOrders();
    for (const order of cancelled) {
      const now = Date.now();
      const notifyMap = getNotifyMap();
      const lastSent = notifyMap.get(order.id) ?? 0;
      if (now - lastSent < AUTO_CANCEL_NOTIFY_GRACE_MS) {
        continue;
      }
      notifyMap.set(order.id, now);

      // Редактируем сообщение с заказом в беседе: «Заказ отменён, водитель не
      // найден», кнопка «Взял» убирается.
      await autoCancelOrderInVkGroup(order).catch(() => {});

      // Дублирующее текстовое уведомление в беседу — как это уже делается при
      // отмене клиентом, когда водитель не был назначен.
      if (order.conversationMessageId) {
        await sendTextToVkGroup(
          `Заказ №${formatOrderNumber(order.id)} отменён автоматически: водитель не найден`
        ).catch(() => {});
      }
    }
  } catch (error) {
    console.error("Автоотмена заказов: ошибка прохода:", error);
  }
}

// Фоновый механизм автоотмены заказов. Запускается один раз при старте
// сервера (instrumentation.register): каждую минуту проверяет заказы в статусе
// waiting и отменяет те, которые никто не взял дольше 15 минут с момента
// создания. Таймер не блокирует завершение процесса.
export function startAutoCancelScheduler(): () => void {
  if (globalForAutoCancel.autoCancelStarted) {
    return () => {};
  }
  globalForAutoCancel.autoCancelStarted = true;

  // Первый проход выполняем сразу после старта, чтобы отменить уже
  // «просроченные» заказы, созданные до перезапуска приложения.
  void runAutoCancel();

  const timer = setInterval(() => {
    void runAutoCancel();
  }, AUTO_CANCEL_INTERVAL_MS);
  timer.unref?.();

  return () => {
    clearInterval(timer);
    globalForAutoCancel.autoCancelStarted = false;
  };
}
