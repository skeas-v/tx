// Хелперы для работы с адресами и подъездами.

export function looksLikeBuildingAddress(text: string): boolean {
  const t = text.toLowerCase().trim();
  if (/\b(дом|д\.)\s*[0-9]/.test(t)) {
    return true;
  }
  if (/[,\s][0-9]{1,4}\s*[а-яё]?\s*$/.test(t)) {
    return true;
  }
  return false;
}

export function addressWithEntrance(
  address: string,
  entrance?: string
): string {
  const e = (entrance ?? "").trim();
  if (!e) {
    return address;
  }
  return `${address} — подъезд ${e}`;
}
