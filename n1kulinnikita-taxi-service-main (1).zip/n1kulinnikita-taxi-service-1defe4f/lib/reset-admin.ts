import { timingSafeEqual } from "crypto";

// Секретная страница сброса пароля администратора/разработчика.
// Секретный ключ получает только запущенное приложение через
// process.env.ADMIN_RESET_SECRET; в коде/чате/логах значение не хранится и
// не выводится. Без заданного ключа страница и эндпоинт недоступны (404).

export function isResetAdminEnabled(): boolean {
  return Boolean(process.env.ADMIN_RESET_SECRET?.trim());
}

export function isResetAdminKeyValid(key: string | null | undefined): boolean {
  const secret = process.env.ADMIN_RESET_SECRET;
  if (!secret || !key) return false;
  const a = Buffer.from(secret);
  const b = Buffer.from(key);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}
