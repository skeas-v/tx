// Расчёт статистики для выгрузки в Excel (админ-панель).
// Период определяется по дате создания заказов (createdAt, ISO UTC).
// Для каждого периода считаются: количество заказов, сумма заказов,
// количество водителей (активных/всего), детализация по статусам заказов,
// а итоговый заработок (количество заявок × комиссия с заявки) вычисляется
// на клиенте и/или в API по переданной администратором комиссии.

import { DELIVERY_PRICE, TRUNK_PRICE, getCityTariff } from "./tariff";
import type { Driver, Order, OrderStatus } from "./models";

export type StatisticsPeriodType = "day" | "week" | "month" | "year";

export const STATISTICS_PERIOD_OPTIONS: Array<{
  value: StatisticsPeriodType;
  label: string;
}> = [
  { value: "day", label: "За день (24 часа)" },
  { value: "week", label: "За неделю (7 дней)" },
  { value: "month", label: "За месяц (30 дней)" },
  { value: "year", label: "За год (365 дней)" },
];

export interface StatisticsPeriod {
  period: StatisticsPeriodType;
  /** Начало периода, включительно (ISO UTC). */
  from: string;
  /** Конец периода, включительно (ISO UTC). */
  to: string;
  /** Читаемая подпись периода в интерфейсе. */
  label: string;
  /** Читаемый диапазон дат. */
  rangeLabel: string;
}

const MS_PER_DAY = 24 * 60 * 60 * 1000;

function formatRussianDate(date: Date): string {
  return date.toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// Определяет границы периода (в UTC) по типу: день/неделя/месяц/год —
// относительные окна «за последние N суток». Для произвольных дат от/до
// используется resolveCustomPeriod.
export function resolveStatisticsPeriod(
  type: StatisticsPeriodType,
  now: Date = new Date()
): StatisticsPeriod {
  const ms =
    type === "day"
      ? MS_PER_DAY
      : type === "week"
        ? 7 * MS_PER_DAY
        : type === "month"
          ? 30 * MS_PER_DAY
          : 365 * MS_PER_DAY;
  const from = new Date(now.getTime() - ms);
  const to = new Date(now.getTime());

  return {
    period: type,
    from: from.toISOString(),
    to: to.toISOString(),
    label:
      STATISTICS_PERIOD_OPTIONS.find((o) => o.value === type)?.label ?? type,
    rangeLabel: `${formatRussianDate(from)} — ${formatRussianDate(to)}`,
  };
}

// Период по произвольным датам «от»/«до» (YYYY-MM-DD, без времени).
// Начало — 00:00:00 UTC дня «от», конец — 23:59:59.999 UTC дня «до».
export function resolveCustomPeriod(
  fromDate: string,
  toDate: string
): StatisticsPeriod {
  const from = new Date(`${fromDate}T00:00:00.000Z`);
  const to = new Date(`${toDate}T23:59:59.999Z`);
  const hasRangeLabel = fromDate && toDate;
  return {
    period: "day",
    from: from.toISOString(),
    to: to.toISOString(),
    label: "За период",
    rangeLabel: hasRangeLabel
      ? `${formatRussianDate(from)} — ${formatRussianDate(to)}`
      : "",
  };
}

// Расчётная стоимость заказа по правилам приложения:
// доставка — фиксированные 350₽; иначе цена популярного места (если задана),
// либо зафиксированный пригородный тариф, либо городской тариф по времени
// создания заказа; к сумме добавляется «багажник» (+50₽).
export function estimateOrderAmount(order: Order): number {
  if (order.delivery) return DELIVERY_PRICE;

  let base: number;
  if (order.popularPlacePrice?.price != null) {
    base = order.popularPlacePrice.price;
  } else if (order.suburbanPrice?.price != null) {
    base = order.suburbanPrice.price;
  } else {
    base = getCityTariff(new Date(order.createdAt)).price;
  }
  return base + (order.trunk ? TRUNK_PRICE : 0);
}

export interface OrderStatusStat {
  status: OrderStatus;
  count: number;
  amount: number;
}

export interface PeriodStatistics {
  period: StatisticsPeriod;
  ordersCount: number;
  ordersAmount: number;
  driversTotal: number;
  driversActive: number;
  ordersByStatus: OrderStatusStat[];
}

export interface DailyDriverLineStat {
  /** Дата дня в формате YYYY-MM-DD (UTC). */
  date: string;
  /** Читаемая дата, например 26.10.2026. */
  dateLabel: string;
  /** Выходил ли хотя бы один водитель на линию в этот день. */
  driverOnLine: boolean;
  /** Количество заказов за этот день. */
  ordersCount: number;
  /** Количество водителей, вышедших на линию в этот день. */
  driversCount: number;
}

// История переключений статуса «на линии» в данных не хранится, поэтому факт
// выхода водителя на линию определяется по заказам за день: если в тот день
// хотя бы один заказ был назначен водителю (есть driverId/driverName) — водители
// выходили на линию. Строки строятся по каждому календарному дню (UTC),
// пересекающемуся с периодом.
export function computeDailyDriverLineStats(
  orders: Order[],
  period: StatisticsPeriod
): DailyDriverLineStat[] {
  const fromDay = new Date(period.from.slice(0, 10) + "T00:00:00.000Z");
  const toDay = new Date(period.to.slice(0, 10) + "T00:00:00.000Z");

  const rows: DailyDriverLineStat[] = [];
  const cursor = new Date(fromDay);
  while (cursor.getTime() <= toDay.getTime()) {
    const dayKey = cursor.toISOString().slice(0, 10);
    const next = new Date(cursor);
    next.setUTCDate(next.getUTCDate() + 1);
    const nextKey = next.toISOString();

    const dayOrders = orders.filter((order) => {
      const ts = order.createdAt;
      if (!ts) return false;
      return (
        ts >= period.from && ts <= period.to && ts >= dayKey && ts < nextKey
      );
    });

    const assignedDrivers = new Set<string>();
    for (const order of dayOrders) {
      const key = order.driverId ?? order.driverName;
      if (key) assignedDrivers.add(key);
    }

    const [year, month, day] = dayKey.split("-");
    rows.push({
      date: dayKey,
      dateLabel: `${day}.${month}.${year}`,
      driverOnLine: assignedDrivers.size > 0,
      ordersCount: dayOrders.length,
      driversCount: assignedDrivers.size,
    });

    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return rows;
}

const STATUS_ORDER: OrderStatus[] = [
  "waiting",
  "assigned",
  "in_progress",
  "completed",
  "cancelled",
];

// Собирает статистику за период. Заказы, попадающие в период, определяются по
// createdAt (ISO-строки сравниваются как UTC). Активные водители — `isOnLine`.
export function computeStatistics(
  orders: Order[],
  drivers: Driver[],
  period: StatisticsPeriod
): PeriodStatistics {
  const inPeriod = orders.filter((order) => {
    const ts = order.createdAt;
    if (!ts) return false;
    return ts >= period.from && ts <= period.to;
  });

  const byStatus = new Map<OrderStatus, OrderStatusStat>();
  for (const status of STATUS_ORDER) {
    byStatus.set(status, { status, count: 0, amount: 0 });
  }

  for (const order of inPeriod) {
    const stat = byStatus.get(order.status) ?? {
      status: order.status,
      count: 0,
      amount: 0,
    };
    stat.count += 1;
    stat.amount += estimateOrderAmount(order);
    byStatus.set(order.status, stat);
  }

  const ordersByStatus = STATUS_ORDER.map((s) => byStatus.get(s)!);

  return {
    period,
    ordersCount: inPeriod.length,
    ordersAmount: inPeriod.reduce(
      (sum, order) => sum + estimateOrderAmount(order),
      0
    ),
    driversTotal: drivers.length,
    driversActive: drivers.filter((d) => Boolean(d.isOnLine)).length,
    ordersByStatus,
  };
}
