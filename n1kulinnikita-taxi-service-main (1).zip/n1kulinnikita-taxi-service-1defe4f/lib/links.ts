export const VK_CHAT_URL =
  "https://vk.me/join/jj_GH7SMfGUJp1ZDcbgPkEFtY9FOaZFFKaM=";
