// Справочник улиц г. Кирово-Чепецка для автодополнения адресов.
// Составлен по реестру улиц города (https://ru.wikipedia.org/wiki/Список_улиц_Кирово-Чепецка).

export type StreetKind =
  | "улица"
  | "проспект"
  | "проезд"
  | "переулок"
  | "площадь";

export interface StreetSuggestion {
  /** Классификационный тип объекта. */
  kind: StreetKind;
  /** Название без классификатора, например «Кирова». */
  name: string;
  /** Полное отображение, например «пр. Кирова». */
  display: string;
}

const kindPrefix: Record<StreetKind, string> = {
  улица: "ул. ",
  проспект: "пр. ",
  проезд: "проезд ",
  переулок: "пер. ",
  площадь: "пл. ",
};

function street(kind: StreetKind, name: string): StreetSuggestion {
  return { kind, name, display: `${kindPrefix[kind]}${name}` };
}

// Основные улицы города (реальные адреса крупных улиц, проспектов и переулков).
export const CITY_STREETS: StreetSuggestion[] = [
street("улица", "ЦРБ"),
  street("улица", "30 лет Октября"),
  street("улица", "60 лет Октября"),
  street("улица", "Азина"),
  street("улица", "Александра Краева"),
  street("улица", "Алексея Некрасова"),
  street("проезд", "Базовый"),
  street("улица", "Большевиков"),
  street("улица", "Братьев Васнецовых"),
  street("улица", "Вокзальная"),
  street("улица", "Володарского"),
  street("улица", "Ганинская"),
  street("улица", "Горького"),
  street("улица", "Дачная"),
  street("проезд", "Дзержинского"),
  street("улица", "Железнодорожная"),
  street("улица", "Жданова"),
  street("улица", "Заводская"),
  street("улица", "Загородная"),
  street("проезд", "Западный"),
  street("улица", "Заречная"),
  street("улица", "Зверева"),
  street("улица", "Калинина"),
  street("улица", "Карла Маркса"),
  street("проспект", "Кирова"),
  street("улица", "Кирпичная"),
  street("улица", "Колхозная"),
  street("улица", "Комиссара Утробина"),
  street("улица", "Коммунистическая"),
  street("улица", "Комсомольская"),
  street("площадь", "Конституции"),
  street("улица", "Кооперативная"),
  street("переулок", "Котельный"),
  street("улица", "Красноармейская"),
  street("улица", "Ленина"),
  street("улица", "Ленинская"),
  street("проезд", "Лермонтова"),
  street("улица", "Лесная"),
  street("проезд", "Лесной"),
  street("улица", "Луговая"),
  street("улица", "Луначарского"),
  street("переулок", "Майский"),
  street("улица", "Маяковского"),
  street("улица", "Мелиораторов"),
  street("улица", "Милицейская"),
  street("проспект", "Мира"),
  street("улица", "Молодой гвардии"),
  street("улица", "Молодёжная"),
  street("улица", "Монтажная"),
  street("улица", "Набережная"),
  street("переулок", "Новостроевский"),
  street("улица", "Овражная"),
  street("площадь", "Октябрьская"),
  street("улица", "Октябрьская"),
  street("улица", "Островского"),
  street("улица", "Парковая"),
  street("проезд", "Перевощикова"),
  street("улица", "Первомайская"),
  street("переулок", "Первомайский"),
  street("улица", "Песчаная"),
  street("улица", "Победы"),
  street("переулок", "Пожарный"),
  street("улица", "Полевая"),
  street("улица", "Почтовая"),
  street("улица", "Производственная"),
  street("улица", "Пролетарская"),
  street("улица", "Просницкая"),
  street("улица", "Профсоюзная"),
  street("улица", "Пушкина"),
  street("переулок", "Рабочий"),
  street("улица", "Революции"),
  street("улица", "Речная"),
  street("переулок", "Родыгина"),
  street("проспект", "России"),
  street("улица", "Рудницкого"),
  street("переулок", "Садовый"),
  street("улица", "Сазонтова"),
  street("улица", "Свердлова"),
  street("улица", "Свободы"),
  street("улица", "Советская"),
  street("переулок", "Советский"),
  street("улица", "Сосновая"),
  street("улица", "Спортивная"),
  street("улица", "Степана Халтурина"),
  street("улица", "Строительная"),
  street("улица", "Терещенко"),
  street("улица", "Труда"),
  street("улица", "Участковая"),
  street("улица", "Фестивальная"),
  street("улица", "Фрезерная"),
  street("улица", "Чепецкая"),
  street("улица", "Школьная"),
  street("улица", "Энгельса"),
  street("улица", "Энергетиков"),
  street("улица", "Юбилейная"),
];

// Слова с классификаторами, которые клиент может набрать перед названием улицы.
const PREFIX_KEYWORDS = new Set([
  "ул",
  "улица",
  "ул.",
  "пр",
  "проспект",
  "пр-т",
  "проезд",
  "пр-д",
  "пер",
  "переулок",
  "б-р",
  "бульвар",
  "пл",
  "площадь",
]);

const HOUSE_KEYWORDS = new Set([
  "д",
  "дом",
  "корп",
  "корпус",
  "стр",
  "строение",
]);

/**
 * Из введённой строки выделяет префикс названия улицы, который ищем в справочнике.
 * Например: «ул. Ленина, д. 5» → «ленина», «Кир» → «кир».
 */
export function normalizeStreetQuery(value: string): string {
  const tokens = value
    .trim()
    .toLowerCase()
    .replace(/ё/g, "е")
    .split(/[\s,()]+/)
    .filter(Boolean);
  const result: string[] = [];
  for (const token of tokens) {
    const clean = token.replace(/[.,]+$/g, "");
    const isHouseKeyword = HOUSE_KEYWORDS.has(clean);
    const hasDigitNearby = tokens.some((t) => /[0-9]/.test(t));
    if (result.length === 0 && PREFIX_KEYWORDS.has(clean)) {
      continue;
    }
    if (/[0-9]/.test(token)) {
      continue;
    }
    if (result.length === 0 && isHouseKeyword && hasDigitNearby) {
      continue;
    }
    if (result.length > 0 && isHouseKeyword) {
      break;
    }
    result.push(clean);
  }
  return result.join("").replace(/ё/g, "е");
}

function hasCyrillic(value: string): boolean {
  return /[а-яА-ЯЁё]/.test(value);
}

/**
 * Возвращает длину (в символах названия, включая пробелы) совпавшего начала
 * улицы, чтобы подсветить введённый клиентом префикс.
 */
export function getStreetMatchLength(
  name: string,
  queryNoSpace: string
): number {
  const compactName = name.toLowerCase().replace(/ё/g, "е").replace(/\s+/g, "");
  if (!compactName.startsWith(queryNoSpace)) {
    return 0;
  }
  let remaining = queryNoSpace.length;
  let i = 0;
  while (remaining > 0 && i < name.length) {
    if (name[i] !== " ") {
      remaining--;
    }
    i++;
  }
  return i;
}

/**
 * Подбирает улицы по началу названия (подсветка «начала адреса»).
 * Если по префиксу совпадений нет — ищет по вхождению.
 */
export function suggestStreets(value: string, limit = 7): StreetSuggestion[] {
  const query = normalizeStreetQuery(value);
  if (!query || !hasCyrillic(value)) {
    return [];
  }

  const exact: StreetSuggestion[] = [];
  const partial: StreetSuggestion[] = [];

  for (const s of CITY_STREETS) {
    const normalized = normalizeStreetQuery(s.name);
    if (normalized.startsWith(query)) {
      exact.push(s);
    } else if (query.length > 1 && normalized.includes(query)) {
      partial.push(s);
    }
  }

  return (exact.length > 0 ? exact : partial).slice(0, limit);
}
