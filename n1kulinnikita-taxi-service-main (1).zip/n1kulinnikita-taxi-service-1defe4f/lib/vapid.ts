import webpush from "web-push";
import { isDatabaseAvailable } from "./db";
import { getAppSettings, updateAppSettings } from "./models";

const DEFAULT_SUBJECT = "mailto:admin@ride.local";

export interface VapidKeys {
  publicKey: string;
  privateKey: string;
  subject: string;
}

let cached: VapidKeys | null = null;

/**
 * Разрешает VAPID-ключи для web-push:
 * 1. Приоритет — переменные окружения VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY
 *    (subject — VAPID_SUBJECT или значение по умолчанию).
 * 2. Если переменные не заданы — читает ранее сгенерированные ключи из
 *    настроек приложения (БД).
 * 3. Если их нет — генерирует и сохраняет в настройках приложения.
 * Значения ключей никогда не выводятся в лог и не отдаются наружу
 * (наружу отдаётся только публичный ключ для подписки браузера).
 */
export async function resolveVapidKeys(): Promise<VapidKeys> {
  if (cached) return cached;

  const envPublic = process.env.VAPID_PUBLIC_KEY?.trim();
  const envPrivate = process.env.VAPID_PRIVATE_KEY?.trim();
  const subject = process.env.VAPID_SUBJECT?.trim() || DEFAULT_SUBJECT;

  if (envPublic && envPrivate) {
    cached = { publicKey: envPublic, privateKey: envPrivate, subject };
    return cached;
  }

  const dbAvailable = await isDatabaseAvailable();
  if (dbAvailable) {
    try {
      const settings = await getAppSettings();
      if (settings.vapidPublicKey && settings.vapidPrivateKey) {
        cached = {
          publicKey: settings.vapidPublicKey,
          privateKey: settings.vapidPrivateKey,
          subject: settings.vapidSubject?.trim() || subject,
        };
        return cached;
      }
    } catch {
      // игнорируем — ниже попробуем сгенерировать заново
    }
  }

  const generated = webpush.generateVAPIDKeys();
  const keys: VapidKeys = {
    publicKey: generated.publicKey,
    privateKey: generated.privateKey,
    subject,
  };
  cached = keys;

  if (dbAvailable) {
    try {
      await updateAppSettings({
        vapidPublicKey: keys.publicKey,
        vapidPrivateKey: keys.privateKey,
        vapidSubject: subject,
      });
    } catch (error) {
      console.warn("Не удалось сохранить VAPID-ключи в настройках:", error);
    }
  }

  return keys;
}

/** Показывает, заданы ли VAPID-ключи через переменные окружения. */
export function isVapidConfiguredFromEnv(): boolean {
  return Boolean(
    process.env.VAPID_PUBLIC_KEY?.trim() &&
    process.env.VAPID_PRIVATE_KEY?.trim()
  );
}
