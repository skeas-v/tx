import { NextRequest } from "next/server";
import { clientIp } from "@/lib/rate-limit";

// Счётчик неудачных попыток входа в админ-панель (в памяти сервера).
// После 5 неудачных попыток под одним логином ИЛИ с одного IP вход
// блокируется на 15 минут. Успешный вход сбрасывает счётчик по логину.

const MAX_FAILED_ATTEMPTS = 5;
const BLOCK_SECONDS = 15 * 60;

type Entry = { count: number; firstFailedAt: number; blockedUntil?: number };

const globalForSecurity = globalThis as unknown as {
  _loginFailureByLogin?: Map<string, Entry>;
  _loginFailureByIp?: Map<string, Entry>;
};

function loginByLogin(): Map<string, Entry> {
  if (!globalForSecurity._loginFailureByLogin) {
    globalForSecurity._loginFailureByLogin = new Map();
  }
  return globalForSecurity._loginFailureByLogin;
}

function loginByIp(): Map<string, Entry> {
  if (!globalForSecurity._loginFailureByIp) {
    globalForSecurity._loginFailureByIp = new Map();
  }
  return globalForSecurity._loginFailureByIp;
}

function isBlocked(entry: Entry | undefined, now: number): boolean {
  if (!entry) return false;
  if (entry.count < MAX_FAILED_ATTEMPTS) return false;
  // При достижении 5 неудачных попыток блокировка действует до конца
  // 15-минутного окна, отсчитываемого от первой попытки из накопившихся.
  if (entry.blockedUntil) return entry.blockedUntil > now;
  return now - entry.firstFailedAt < BLOCK_SECONDS * 1000;
}

function remainingSeconds(entry: Entry, now: number): number {
  if (entry.blockedUntil && entry.blockedUntil > now) {
    return Math.ceil((entry.blockedUntil - now) / 1000);
  }
  const recent = now - entry.firstFailedAt;
  return Math.max(1, BLOCK_SECONDS - Math.floor(recent / 1000));
}

export type LoginGateResult =
  | { allowed: true }
  | {
      allowed: false;
      retryAfterSeconds: number;
      reason: "login" | "ip";
    };

/**
 * Проверяет, можно ли сейчас попытаться войти: не заблокирован ли логин
 * или IP. Блокировка отменяется по истечении 15 минут с момента первой из
 * пяти неудачных попыток (или с момента самого факта блокировки — как
 * только срок окна истёк).
 */
export function checkLoginGate(
  request: NextRequest,
  login: string
): LoginGateResult {
  const now = Date.now();
  const normalizedLogin = login.trim().toLowerCase();

  const byLogin = loginByLogin().get(normalizedLogin);
  if (isBlocked(byLogin, now)) {
    return {
      allowed: false,
      retryAfterSeconds: byLogin
        ? remainingSeconds(byLogin, now)
        : BLOCK_SECONDS,
      reason: "login",
    };
  }

  const byIp = loginByIp().get(clientIp(request));
  if (isBlocked(byIp, now)) {
    return {
      allowed: false,
      retryAfterSeconds: byIp ? remainingSeconds(byIp, now) : BLOCK_SECONDS,
      reason: "ip",
    };
  }

  return { allowed: true };
}

/**
 * Регистрирует неудачную попытку входа: увеличивает счётчики для логина
 * и IP; при достижении 5 попыток за 15 минут вход блокируется.
 */
export function registerLoginFailure(
  request: NextRequest,
  login: string
): void {
  const now = Date.now();

  const byLogin = loginByLogin();
  const normalizedLogin = login.trim().toLowerCase();
  const loginEntry = byLogin.get(normalizedLogin);
  const loginWindowExpired =
    loginEntry && now - loginEntry.firstFailedAt >= BLOCK_SECONDS * 1000;
  if (loginEntry && loginEntry.blockedUntil && loginEntry.blockedUntil > now) {
    // Уже заблокирован — просто игнорируем новые попытки.
    return;
  }
  const freshLogin: Entry =
    !loginEntry || loginWindowExpired
      ? { count: 0, firstFailedAt: now }
      : loginEntry;
  const loginCount = freshLogin.count + 1;
  const nextLogin: Entry =
    loginCount >= MAX_FAILED_ATTEMPTS
      ? {
          count: loginCount,
          firstFailedAt: freshLogin.firstFailedAt,
          blockedUntil: now + BLOCK_SECONDS * 1000,
        }
      : { count: loginCount, firstFailedAt: freshLogin.firstFailedAt };
  byLogin.set(normalizedLogin, nextLogin);

  // Если после предыдущей серии блокировка ещё активна по IP — не засчитываем
  // новые попытки до её истечения.
  const byIp = loginByIp();
  const ip = clientIp(request);
  const ipEntry = byIp.get(ip);
  if (ipEntry && ipEntry.blockedUntil && ipEntry.blockedUntil > now) {
    return;
  }
  const ipWindowExpired =
    ipEntry && now - ipEntry.firstFailedAt >= BLOCK_SECONDS * 1000;
  const freshIp: Entry =
    !ipEntry || ipWindowExpired ? { count: 0, firstFailedAt: now } : ipEntry;
  const ipCount = freshIp.count + 1;
  const nextIp: Entry =
    ipCount >= MAX_FAILED_ATTEMPTS
      ? {
          count: ipCount,
          firstFailedAt: freshIp.firstFailedAt,
          blockedUntil: now + BLOCK_SECONDS * 1000,
        }
      : { count: ipCount, firstFailedAt: freshIp.firstFailedAt };
  byIp.set(ip, nextIp);
}

/**
 * Сбрасывает счётчики неудачных попыток после успешного входа.
 */
export function clearLoginFailures(request: NextRequest, login: string): void {
  loginByLogin().delete(login.trim().toLowerCase());
  loginByIp().delete(clientIp(request));
}

export function loginBlockMessage(retryAfterSeconds: number): string {
  const minutes = Math.max(1, Math.ceil(retryAfterSeconds / 60));
  return `Слишком много неудачных попыток входа. Вход временно заблокирован — попробуйте снова через ${minutes} мин.`;
}
