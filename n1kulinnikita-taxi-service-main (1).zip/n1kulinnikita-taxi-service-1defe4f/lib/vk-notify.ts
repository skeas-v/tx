import { randomInt } from "node:crypto";
import { OrderStatus, type Order } from "./models";
import { formatOrderNumber } from "./models";

const VK_MESSAGES_SEND_URL = "https://api.vk.com/method/messages.send";
const VK_MESSAGES_EDIT_URL = "https://api.vk.com/method/messages.edit";
const VK_MESSAGES_GET_HISTORY_URL =
  "https://api.vk.com/method/messages.getHistory";
const VK_SEND_EVENT_ANSWER_URL =
  "https://api.vk.com/method/messages.sendMessageEventAnswer";
const VK_GET_MEMBERS_URL = "https://api.vk.com/method/groups.getMembers";
const VK_API_VERSION = "5.199";
const VK_REQUEST_TIMEOUT_MS = 10_000;
const VK_RANDOM_ID_MAX = 2_147_483_647;
// Ошибка VK API 912: отправка клавиатуры требует включённой функции
// «Чат-бот» в настройках сообщества. Если она не включена, VK отклоняет
// сообщение с keyboard целиком. В таком случае уведомление о заказе
// отправляется без клавиатуры, чтобы оно всё равно дошло до беседы.
const VK_ERROR_CHAT_BOT_FEATURE = 912;

const VK_BUTTON_TAKE = "took";
const VK_BUTTON_DONE = "done";

export type VkOrderButton = typeof VK_BUTTON_TAKE | typeof VK_BUTTON_DONE;
export type VkOrderKeyboardState = VkOrderButton | "none";

function orderAddress(order: Order, kind: "from" | "to"): string {
  const address = order[`${kind}Address`]?.trim() || order[kind]?.trim();
  const entrance = order[`${kind}Entrance`]?.trim();
  if (!address) {
    return "не указан";
  }
  return entrance ? `${address}, подъезд ${entrance}` : address;
}

// Дополнительные пометки для сообщения о заказе в беседе: кто принял заказ
// (после нажатия «Взял») и что поездка выполнена (после нажатия «Увез»).
interface VkOrderMessageExtras {
  takenByDriver?: string;
  completed?: boolean;
}

export function buildOrderMessage(
  order: Order,
  extras?: VkOrderMessageExtras
): string {
  const name = order.clientName?.trim() || "не указано";
  const phone = order.clientPhone?.trim() || "не указано";
  const lines = [
    `Новый заказ №${formatOrderNumber(order.id)}`,
    `Откуда: ${orderAddress(order, "from")}`,
  ];
  for (const [index, stop] of (order.stops ?? []).entries()) {
    const address = stop.address?.trim() || "не указан";
    const entrance = stop.entrance?.trim();
    lines.push(
      `Остановка ${index + 1}: ${entrance ? `${address}, подъезд ${entrance}` : address}`
    );
  }
  lines.push(`Куда: ${orderAddress(order, "to")}`);
  lines.push(`Клиент: ${name}`);
  lines.push(`Телефон: ${phone}`);
  if (order.comment) {
    lines.push(`Комментарий водителю: ${order.comment}`);
  }
  if (order.childSeat) {
    lines.push("Детское кресло: да");
  }
  if (order.delivery) {
    lines.push("Доставка: да");
  }
  if (order.trunk) {
    lines.push("Багажник: да");
  }
  if (order.paymentMethod === "cash") {
    lines.push("Оплата: наличными");
    if (order.cashChangeFrom != null) {
      lines.push(`Сдача с: ${order.cashChangeFrom}₽`);
    }
  } else {
    lines.push("Оплата: перевод");
  }
  if (order.suburbanPrice) {
    const p = order.suburbanPrice;
    const directionLabel = p.direction === "from" ? "забрать" : "везти";
    lines.push(
      `Пригородный тариф: ${p.name} (${directionLabel}) — ${p.basePrice}₽`
    );
    if (p.surcharge > 0) {
      lines.push(`Добавка: +${p.surcharge}₽`);
    }
    lines.push(`Итог: ${p.price}₽`);
  }
  if (order.popularPlacePrice) {
    lines.push(
      `Популярное место: ${order.popularPlacePrice.name} — ${order.popularPlacePrice.price}₽`
    );
  }
  if (extras?.takenByDriver) {
    lines.push(`Заказ принял водитель: ${extras.takenByDriver}`);
  }
  if (extras?.completed) {
    lines.push("Поездка выполнена");
  }
  return lines.join("\n");
}

function makeCallbackButton(
  label: string,
  payload: string,
  color: string
): unknown {
  return {
    action: {
      type: "callback",
      label,
      payload,
    },
    color,
  };
}

// Класс клавиатуры с кнопкой «Взял» — добавляется к сообщению о заказе.
const VK_ORDER_TAKE_KEYBOARD = JSON.stringify({
  inline: true,
  one_time: false,
  buttons: [
    [
      makeCallbackButton(
        "Взял",
        JSON.stringify({ cmd: VK_BUTTON_TAKE }),
        "positive"
      ),
    ],
  ],
});

// Класс клавиатуры с кнопкой «Увез» — подставляется после того,
// как водитель взял заказ (кнопка меняется с «Взял» на «Увез»).
// Нажать «Увез» может только водитель, назначенный на заказ.
const VK_ORDER_DONE_KEYBOARD = JSON.stringify({
  inline: true,
  one_time: false,
  buttons: [
    [
      makeCallbackButton(
        "Увез",
        JSON.stringify({ cmd: VK_BUTTON_DONE }),
        "primary"
      ),
    ],
  ],
});

// Пустая клавиатура используется, чтобы убрать кнопки после завершения заказа.
export const VK_ORDER_EMPTY_KEYBOARD = JSON.stringify({
  inline: true,
  one_time: false,
  buttons: [],
});

export function getOrderKeyboard(
  order: Pick<Order, "status">,
  state?: VkOrderKeyboardState
): string {
  const effective =
    state ?? (order.status === OrderStatus.ASSIGNED ? "done" : "took");
  if (effective === "done") return VK_ORDER_DONE_KEYBOARD;
  if (effective === "took") return VK_ORDER_TAKE_KEYBOARD;
  return VK_ORDER_EMPTY_KEYBOARD;
}

interface VkSendResponse {
  error?: { error_code?: number; error_msg?: string };
  // messages.send возвращает message_id отправленного сообщения как число
  // (в старых версиях — объект с id). Оба варианта поддерживаются.
  response?:
    | number
    | {
        peer_id?: number;
        message_id?: number;
        conversation_message_id?: number;
      };
}

interface VkGetMembersResponse {
  error?: { error_code?: number; error_msg?: string };
  response?: {
    count?: number;
    items?: Array<number | { id?: number; role?: string }>;
  };
}

interface VkHistoryResponse {
  error?: { error_code?: number; error_msg?: string };
  response?: {
    items?: Array<{
      // messages.getHistory возвращает поле id (глобальный message_id)
      // и conversation_message_id (cmid) для каждого сообщения.
      id?: number;
      conversation_message_id?: number;
    }>;
  };
}

function normalizeGroupId(groupId: string): string {
  return groupId.trim().replace(/^-\s*/, "");
}

async function sendRawVkMessage(
  token: string,
  peerId: string,
  message: string
): Promise<boolean> {
  const params = new URLSearchParams({
    access_token: token,
    peer_id: peerId,
    message,
    random_id: String(randomInt(1, VK_RANDOM_ID_MAX + 1)),
    v: VK_API_VERSION,
  });

  try {
    const response = await fetch(VK_MESSAGES_SEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
      signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
    });

    if (!response.ok) {
      console.warn("VK help: request failed:", response.status);
      return false;
    }

    const json = (await response.json()) as VkSendResponse;

    if (json.error) {
      console.warn(
        "VK help: messages.send error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return false;
    }

    return true;
  } catch (error) {
    console.warn("VK help: skipped:", error);
    return false;
  }
}

async function getAdminsFromGroup(
  token: string,
  groupId: string
): Promise<string[]> {
  const params = new URLSearchParams({
    access_token: token,
    group_id: normalizeGroupId(groupId),
    filter: "managers",
    v: VK_API_VERSION,
  });

  try {
    const response = await fetch(`${VK_GET_MEMBERS_URL}?${params.toString()}`, {
      method: "GET",
      signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
    });

    if (!response.ok) {
      console.warn("VK help: getMembers request failed:", response.status);
      return [];
    }

    const json = (await response.json()) as VkGetMembersResponse;

    if (json.error) {
      console.warn(
        "VK help: groups.getMembers error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return [];
    }

    return (json.response?.items ?? [])
      .map((item) => {
        if (typeof item === "number") {
          return String(item);
        }
        const id = item?.id;
        const role = item?.role;
        if (id == null) return null;
        if (role && role !== "admin" && role !== "editor") return null;
        return String(id);
      })
      .filter((id): id is string => !!id && id.length > 0);
  } catch (error) {
    console.warn("VK help: getMembers skipped:", error);
    return [];
  }
}

export async function sendHelpToAdmins(driver: {
  name?: string;
  phone?: string;
}): Promise<boolean> {
  const token = process.env.VK_API_TOKEN;
  if (!token) return false;

  let adminIds: string[] = [];

  const rawAdminIds = process.env.VK_ADMIN_IDS;
  if (rawAdminIds?.trim()) {
    adminIds = rawAdminIds
      .split(",")
      .map((id) => id.trim())
      .filter((id) => id.length > 0);
  } else {
    const groupId = process.env.VK_GROUP_ID;
    if (groupId?.trim()) {
      adminIds = await getAdminsFromGroup(token, groupId);
    }
  }

  if (adminIds.length === 0) return false;

  const driverName = driver.name?.trim() || "водитель";
  const phone = driver.phone?.trim();
  const text = phone
    ? `Водитель ${driverName} (${phone}) просит помощи.`
    : `Водитель ${driverName} просит помощи.`;

  let sentAny = false;
  for (const adminId of adminIds) {
    const sent = await sendRawVkMessage(token, adminId, text);
    sentAny = sentAny || sent;
  }
  return sentAny;
}

export async function sendTextToVkGroup(text: string): Promise<boolean> {
  const token = process.env.VK_API_TOKEN;
  const groupId = process.env.VK_GROUP_ID;
  const peerId = process.env.VK_PEER_ID;
  if (!token || !groupId || !peerId) return false;
  return sendRawVkMessage(token, peerId, text);
}

// Уведомление в беседу ВКонтакте (ту самую, где водитель написал команду)
// о смене статуса водителя: «!НаЛинии» / «на линии» — «(имя), Вы на линии,
// приём заявок», «!Ушел» / «ушел» / «не на линии» — «(имя), вы ушли с линии».
// Сообщение отправляется от имени сообщества через VK API messages.send
// в peer_id, указанный вызывающим (peer_id события message_new). Возвращает
// false и не бросает исключений при отсутствии переменных окружения VK_* или
// ошибке VK API, чтобы приложение продолжало работать без сбоев.
export async function notifyDriverStatusChange(input: {
  peerId: string;
  driverName?: string;
  online: boolean;
}): Promise<boolean> {
  const token = process.env.VK_API_TOKEN;
  if (!token) return false;
  const driverName = input.driverName?.trim();
  const peerId = input.peerId.trim();
  if (!driverName || !peerId) return false;
  const text = input.online
    ? `${driverName}, Вы на линии, приём заявок`
    : `${driverName}, вы ушли с линии`;
  return sendRawVkMessage(token, peerId, text);
}

// Уведомление в беседу ВКонтакте о том, что водитель без премиум-аккаунта
// принял заказ, оформленный клиентом по телефону («Вызвать по телефону» /
// «Позвонить»). Формат сообщения: «Водитель: (имя водителя, гос. номер) принял
// заказ с сайта № заказа». Для премиум-водителей уведомление не отправляется —
// их заказы и так не публикуются в общей очереди/беседе. Возвращает false и
// не бросает исключений при отсутствии переменных окружения VK_* или ошибке
// VK API, чтобы приложение продолжало работать без сбоев.
export async function notifyDriverAcceptedCallOrder(input: {
  orderId: string;
  driverName?: string;
  driverCarNumber?: string;
}): Promise<boolean> {
  const driverName = input.driverName?.trim();
  if (!driverName) return false;
  const carNumber = input.driverCarNumber?.trim();
  const label = carNumber
    ? `${driverName}, ${carNumber}`
    : `${driverName}, гос. номер не указан`;
  const text = `Водитель: ${label} принял заказ с сайта №${formatOrderNumber(input.orderId)}`;
  return sendTextToVkGroup(text);
}

// VK API messages.send возвращает только глобальный message_id отправленного
// сообщения. Для команд водителя (reply/кнопки) нужен conversation_message_id
// (cmid), который получаем через messages.getHistory — ищем недавно
// отправленное сообщение по message_id. Сразу после отправки VK может ещё
// не отразить сообщение в истории, поэтому делаем несколько попыток.
async function resolveConversationMessageId(
  token: string,
  peerId: string,
  messageId: number
): Promise<number | null> {
  if (!Number.isFinite(messageId) || messageId <= 0) return null;

  const delayMs = [0, 300, 600, 1200];
  for (const delay of delayMs) {
    if (delay > 0) {
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
    const cmid = await tryResolveConversationMessageId(
      token,
      peerId,
      messageId
    );
    if (cmid != null) return cmid;
  }
  return null;
}

async function tryResolveConversationMessageId(
  token: string,
  peerId: string,
  messageId: number
): Promise<number | null> {
  try {
    const params = new URLSearchParams({
      access_token: token,
      peer_id: peerId,
      count: "20",
      v: VK_API_VERSION,
    });

    const response = await fetch(
      `${VK_MESSAGES_GET_HISTORY_URL}?${params.toString()}`,
      {
        method: "GET",
        signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
      }
    );

    if (!response.ok) {
      console.warn(
        "VK notification: getHistory request failed:",
        response.status
      );
      return null;
    }

    const json = (await response.json()) as VkHistoryResponse;

    if (json.error) {
      console.warn(
        "VK notification: messages.getHistory error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return null;
    }

    const cmid = (json.response?.items ?? []).find(
      (item) => item.id === messageId
    )?.conversation_message_id;

    return cmid != null && cmid > 0 ? cmid : null;
  } catch (error) {
    console.warn("VK notification: getHistory skipped:", error);
    return null;
  }
}

export async function sendOrderToVkGroup(
  order: Order
): Promise<{ sent: boolean; conversationMessageId: number | null }> {
  const token = process.env.VK_API_TOKEN;
  const groupId = process.env.VK_GROUP_ID;
  const peerId = process.env.VK_PEER_ID;

  if (!token || !groupId || !peerId) {
    return { sent: false, conversationMessageId: null };
  }

  const message = buildOrderMessage(order);

  // Пробуем отправить сообщение с интерактивной клавиатурой. Если VK отвечает
  // ошибкой «Chat bot feature» (912) — клавиатура не поддерживается сообществом,
  // отправляем сообщение без неё, чтобы заказ всё равно пришёл в беседу.
  const withKeyboard = await sendVkOrderMessage(
    token,
    groupId,
    peerId,
    message,
    true
  );
  if (withKeyboard.sent) {
    return withKeyboard;
  }

  if (withKeyboard.errorCode !== VK_ERROR_CHAT_BOT_FEATURE) {
    return { sent: false, conversationMessageId: null };
  }

  const withoutKeyboard = await sendVkOrderMessage(
    token,
    groupId,
    peerId,
    message,
    false
  );
  return {
    sent: withoutKeyboard.sent,
    conversationMessageId: withoutKeyboard.conversationMessageId,
  };
}

async function sendVkOrderMessage(
  token: string,
  groupId: string,
  peerId: string,
  message: string,
  withKeyboard: boolean
): Promise<{
  sent: boolean;
  conversationMessageId: number | null;
  errorCode?: number;
}> {
  try {
    const params = new URLSearchParams({
      access_token: token,
      group_id: groupId,
      peer_id: peerId,
      message,
      random_id: String(randomInt(1, VK_RANDOM_ID_MAX + 1)),
      v: VK_API_VERSION,
    });
    if (withKeyboard) {
      params.set("keyboard", getOrderKeyboard({ status: OrderStatus.WAITING }));
    }

    const response = await fetch(VK_MESSAGES_SEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
      signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
    });

    if (!response.ok) {
      console.warn("VK notification: request failed:", response.status);
      return { sent: false, conversationMessageId: null };
    }

    const json = (await response.json()) as VkSendResponse;

    if (json.error) {
      console.warn(
        "VK notification: API error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return {
        sent: false,
        conversationMessageId: null,
        errorCode: json.error.error_code,
      };
    }

    let messageId = 0;
    const payload = json.response;
    if (typeof payload === "number") {
      messageId = payload;
    } else if (payload && typeof payload === "object") {
      messageId = Number(
        payload.message_id ?? payload.conversation_message_id ?? 0
      );
    }
    if (!Number.isFinite(messageId) || messageId <= 0) {
      return { sent: true, conversationMessageId: null };
    }

    const conversationMessageId = await resolveConversationMessageId(
      token,
      peerId,
      messageId
    );
    return { sent: true, conversationMessageId };
  } catch (error) {
    console.warn("VK notification: skipped:", error);
    return { sent: false, conversationMessageId: null };
  }
}

interface VkEditResponse {
  error?: { error_code?: number; error_msg?: string };
  response?: number;
}

// Редактирует сообщение с заказом (messages.edit): можно заменить текст,
// клавиатуру и/или кнопки. Для работы VK API необходимы VK_API_TOKEN,
// VK_GROUP_ID и VK_PEER_ID; при их отсутствии или ошибке приложение
// продолжает работать без сбоев.
export async function editVkOrderMessage(
  conversationMessageId: number,
  updates: { message?: string; keyboard?: string }
): Promise<boolean> {
  if (updates.message === undefined && updates.keyboard === undefined) {
    return true;
  }

  const token = process.env.VK_API_TOKEN;
  const groupId = process.env.VK_GROUP_ID;
  const peerId = process.env.VK_PEER_ID;
  if (!token || !groupId || !peerId) return false;

  try {
    const params = new URLSearchParams({
      access_token: token,
      group_id: groupId,
      peer_id: peerId,
      cmid: String(conversationMessageId),
      v: VK_API_VERSION,
    });
    if (updates.message !== undefined) {
      params.set("message", updates.message);
    }
    if (updates.keyboard !== undefined) {
      params.set("keyboard", updates.keyboard);
    }

    const response = await fetch(VK_MESSAGES_EDIT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
      signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
    });

    if (!response.ok) {
      console.warn("VK edit: request failed:", response.status);
      return false;
    }

    const json = (await response.json()) as VkEditResponse;

    if (json.error) {
      console.warn(
        "VK edit: messages.edit error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return false;
    }

    return true;
  } catch (error) {
    console.warn("VK edit: skipped:", error);
    return false;
  }
}

// Отвечает на нажатие кнопки (message_event): убирает галочки «загрузки»
// на кнопке и может показать всплывающее сообщение водителю.
export async function answerVkEvent(
  event: {
    event_id?: string;
    user_id?: number | string;
    peer_id?: number | string;
  },
  eventData?: unknown
): Promise<boolean> {
  const token = process.env.VK_API_TOKEN;
  if (!token) return false;
  if (!event.event_id) return false;
  if (event.user_id === undefined || event.user_id === null) return false;
  if (event.peer_id === undefined || event.peer_id === null) return false;

  const params = new URLSearchParams({
    access_token: token,
    event_id: event.event_id,
    user_id: String(event.user_id),
    peer_id: String(event.peer_id),
    v: VK_API_VERSION,
  });
  if (eventData !== undefined) {
    params.set("event_data", JSON.stringify(eventData));
  }

  try {
    const response = await fetch(VK_SEND_EVENT_ANSWER_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
      signal: AbortSignal.timeout(VK_REQUEST_TIMEOUT_MS),
    });

    if (!response.ok) {
      console.warn("VK event answer: request failed:", response.status);
      return false;
    }

    const json = (await response.json()) as VkSendResponse;
    if (json.error) {
      console.warn(
        "VK event answer: sendMessageEventAnswer error:",
        json.error.error_code,
        json.error.error_msg ?? ""
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("VK event answer: skipped:", error);
    return false;
  }
}

// Отмена заказа клиентом: сообщение с заказом в беседе редактируется
// (messages.edit) — внизу дописывается «ОТМЕНЕНО КЛИЕНТОМ», интерактивные
// кнопки («Взял»/«Увез») убираются. Возвращает true, если сообщение
// успешно отредактировано.
export async function cancelOrderInVkGroup(
  order: Pick<Order, "id" | "conversationMessageId">
): Promise<boolean> {
  const cmid = order.conversationMessageId;
  if (cmid == null || !(Number(cmid) > 0)) {
    return false;
  }
  return editVkOrderMessage(Number(cmid), {
    message: "ОТМЕНЕНО КЛИЕНТОМ",
    keyboard: VK_ORDER_EMPTY_KEYBOARD,
  });
}

// Автоотмена заказа (никто не взял в течение 15 минут): сообщение с заказом
// в беседе редактируется (messages.edit) — текст заменяется на «Заказ
// отменён, водитель не найден», кнопка «Взял» убирается. Возвращает true,
// если сообщение успешно отредактировано.
export async function autoCancelOrderInVkGroup(
  order: Pick<Order, "id" | "conversationMessageId">
): Promise<boolean> {
  const cmid = order.conversationMessageId;
  if (cmid == null || !(Number(cmid) > 0)) {
    return false;
  }
  return editVkOrderMessage(Number(cmid), {
    message: "Заказ отменён, водитель не найден",
    keyboard: VK_ORDER_EMPTY_KEYBOARD,
  });
}
