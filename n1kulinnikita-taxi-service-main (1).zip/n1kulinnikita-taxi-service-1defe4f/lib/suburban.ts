// Ценообразование пригородных/загородных направлений.
// Администратор добавляет адрес в настройках админ-панели и задаёт для него:
//  - цену «везти» (priceTo) — поездка из города в это направление;
//  - цену «забрать» (priceFrom) — поездка из этого направления в город;
//  - опции «час-пик» и «ночь»: каждая может быть включена/выключена,
//    при включении к цене добавляется заданная сумма добавки.
// Когда клиент указывает адрес «откуда»/«куда», совпадающий с добавленным,
// применяется соответствующая цена с учётом включённых опций.
// Если адрес совпадает с какой-то точкой маршрута, управление ценообразованием
// принадлежит этому пригородному тарифу: городской тариф не применяется.

import type { SuburbanAddress } from "./models";

export const CITY_TARIFF = "city";

export interface TripPrice {
  kind: "city" | "suburban";
  basePrice: number;
  surcharge: number;
  price: number;
  label: string;
  window: string;
  surcharges: Array<{ label: string; amount: number }>;
  matchedName: string;
  direction: "to" | "from";
  fromAddress?: string;
  toAddress?: string;
}

function normalizeAddress(value: string): string {
  return value
    .toLowerCase()
    .replace(/[ёЁ]/g, "е")
    .replace(/\s+/g, " ")
    .replace(/^\s+|\s+$/g, "");
}

function normalizeName(value: string): string {
  return value
    .toLowerCase()
    .replace(/[ёЁ]/g, "е")
    .replace(/\s+/g, " ")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function addressMatches(
  address: string | undefined,
  candidate: SuburbanAddress
): boolean {
  const raw = (address ?? "").trim();
  if (!raw) return false;
  const addressNorm = normalizeAddress(raw);
  const nameNorm = normalizeName(candidate.name);
  if (!nameNorm) return false;

  if (addressNorm === nameNorm) return true;
  if (addressNorm.includes(nameNorm)) return true;
  if (nameNorm.split(" ").length >= 2) {
    const nameWithoutDigits = nameNorm.replace(/\d+/g, " ").trim();
    if (nameWithoutDigits) {
      return addressNorm.includes(nameWithoutDigits);
    }
  }
  return false;
}

export function applyPeakSurcharge(
  price: number,
  address: SuburbanAddress | undefined,
  date: Date = new Date()
): { applied: boolean; surcharge: number } {
  if (!address?.peakEnabled || address.peakSurcharge <= 0) {
    return { applied: false, surcharge: 0 };
  }
  const minutes = date.getHours() * 60 + date.getMinutes();
  const isMorningPeak = minutes >= 6 * 60 && minutes < 9 * 60;
  const isEveningPeak = minutes >= 16 * 60 && minutes < 18 * 60;
  if (!isMorningPeak && !isEveningPeak) {
    return { applied: false, surcharge: 0 };
  }
  return { applied: true, surcharge: address.peakSurcharge };
}

export function applyNightSurcharge(
  price: number,
  address: SuburbanAddress | undefined,
  date: Date = new Date()
): { applied: boolean; surcharge: number } {
  if (!address?.nightEnabled || address.nightSurcharge <= 0) {
    return { applied: false, surcharge: 0 };
  }
  const minutes = date.getHours() * 60 + date.getMinutes();
  const isNight = minutes >= 22 * 60 || minutes < 5 * 60;
  if (!isNight) {
    return { applied: false, surcharge: 0 };
  }
  return { applied: true, surcharge: address.nightSurcharge };
}

// Стоимость поездки с учётом пригородных адресов.
// Соответствие ищется по «откуда» и «куда»; если один из адресов совпадает с
// добавленным администратором направлением, применяется его тариф (везти —
// пункт назначения, забрать — пункт отправления). Если совпадают оба — для
// цены выбирается максимальная из доступных, чтобы не занизить стоимость.
export function resolveTripPrice(
  addresses: SuburbanAddress[],
  from: string | undefined,
  to: string | undefined,
  date: Date = new Date()
): TripPrice | null {
  const fromHit = addresses.find((a) => addressMatches(from, a));
  const toHit = addresses.find((a) => addressMatches(to, a));

  if (!fromHit && !toHit) {
    return null;
  }

  const candidateFrom = fromHit
    ? {
        basePrice: fromHit.priceFrom,
        address: fromHit,
        direction: "from" as const,
      }
    : null;
  const candidateTo = toHit
    ? {
        basePrice: toHit.priceTo,
        address: toHit,
        direction: "to" as const,
      }
    : null;

  const chosen =
    candidateFrom && candidateTo
      ? candidateFrom.basePrice >= candidateTo.basePrice
        ? candidateFrom
        : candidateTo
      : (candidateFrom ?? candidateTo);

  if (!chosen) {
    return null;
  }

  const peak = applyPeakSurcharge(chosen.basePrice, chosen.address, date);
  const night = applyNightSurcharge(chosen.basePrice, chosen.address, date);

  const surcharges = [
    ...(peak.applied ? [{ label: "Час пик", amount: peak.surcharge }] : []),
    ...(night.applied ? [{ label: "Ночь", amount: night.surcharge }] : []),
  ];
  const surcharge = surcharges.reduce((sum, s) => sum + s.amount, 0);
  const price = chosen.basePrice + surcharge;

  const label = `${chosen.address.name} · ${chosen.direction}`;
  const active = [
    peak.applied ? "в час пик" : null,
    night.applied ? "ночью" : null,
  ]
    .filter(Boolean)
    .join(" + ");

  return {
    kind: "suburban",
    basePrice: chosen.basePrice,
    surcharge,
    price,
    label,
    window: active ? `Добавка: ${active}` : "Пригородный тариф",
    surcharges,
    matchedName: chosen.address.name,
    direction: chosen.direction,
    fromAddress: fromHit?.name,
    toAddress: toHit?.name,
  };
}
