// Утилиты для работы с Яндекс-картами (JS API 2.1).
// Используются только в клиентских компонентах (сторона браузера).

export const CITY_CENTER: readonly [number, number] = [58.5555391, 50.0399737];
export const CITY_NAME = "Кирово-Чепецк";

export interface YandexMapInstance {
  destroy: () => void;
  setBounds: (bounds: unknown, options?: object) => void;
  setCenter: (center: number[], zoom?: number, options?: object) => void;
  getCenter: () => number[];
  getZoom: () => number;
  container: {
    fitToViewport: () => void;
  };
  events: {
    add: (type: string, handler: (event: unknown) => void) => unknown;
    remove: (type: string, handler: (event: unknown) => void) => unknown;
  };
  geoObjects: {
    add: (obj: YandexMarker) => unknown;
    remove: (obj: YandexMarker) => unknown;
    getBounds: () => YandexMarker[] | null;
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type YandexMarker = any;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type YandexMultiRoute = any;

export interface ResolvedAddress {
  address: string;
  lat: number;
  lng: number;
}

export interface FallbackRoute {
  // Координаты ломаной маршрута в формате [lat, lng] (порядок Яндекс.Карт).
  coordinates: number[][];
  distanceMeters: number;
  durationSeconds: number;
}

const OSRM_ROUTE_URL = "https://router.project-osrm.org/route/v1/driving";

interface OsrmRouteResponse {
  code?: string;
  routes?: Array<{
    distance?: number;
    duration?: number;
    geometry?: { coordinates?: number[][] };
  }>;
}

/**
 * Строит маршрут через публичный роутер OSRM (OpenStreetMap) — запасной
 * вариант, когда маршрутизация Яндекс.Карт (ymaps.multiRouter) недоступна
 * (например, без API-ключа). Возвращает координаты ломаной маршрута,
 * расстояние и время в пути.
 */
export async function buildFallbackRoute(
  points: { lat: number; lng: number }[]
): Promise<FallbackRoute | null> {
  const valid = points.filter(
    (p) => Number.isFinite(p.lat) && Number.isFinite(p.lng)
  );
  if (valid.length < 2) return null;
  const coords = valid.map((p) => `${p.lng},${p.lat}`).join(";");
  try {
    const url = `${OSRM_ROUTE_URL}/${coords}?overview=full&geometries=geojson`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return null;
    const data = (await res.json()) as OsrmRouteResponse;
    if (data.code !== "Ok") return null;
    const route = data.routes?.[0];
    if (!route) return null;
    // OSRM в режиме geojson возвращает координаты как [lng, lat], а
    // Яндекс.Карты (Polyline) ожидают [lat, lng] — меняем местами.
    const coordinates = (route.geometry?.coordinates ?? []).map(
      ([lng, lat]) => [lat, lng] as number[]
    );
    return {
      coordinates,
      distanceMeters: route.distance ?? 0,
      durationSeconds: route.duration ?? 0,
    };
  } catch {
    return null;
  }
}

export function formatOsrmDuration(seconds: number): string {
  const minutes = Math.round(seconds / 60);
  if (minutes < 1) return "1 мин";
  return `~${minutes} мин`;
}

interface YandexGeoObject {
  geometry?: { getCoordinates?: () => number[] };
  getAddressLine?: () => string;
  properties?: { get: (path: string) => unknown };
}

interface YandexGeocodeResult {
  geoObjects?: { get: (index: number) => YandexGeoObject | null };
}

export interface YandexMapsApi {
  ready: (cb?: () => void) => unknown;
  Map: new (
    element: HTMLElement,
    state: object,
    options?: object
  ) => YandexMapInstance;
  Placemark: new (
    coords: number[],
    properties?: object,
    options?: object
  ) => YandexMarker;
  Polyline: new (
    coords: number[][],
    properties?: object,
    options?: object
  ) => YandexMarker;
  Circle: new (
    geometry: unknown,
    properties?: object,
    options?: object
  ) => YandexMarker;
  multiRouter: {
    MultiRoute: new (
      referencePoints: object,
      options?: object
    ) => YandexMultiRoute;
  };
  geocode: (
    request: string | number[],
    options?: object
  ) => Promise<YandexGeocodeResult>;
}

declare global {
  interface Window {
    ymaps?: YandexMapsApi;
  }
}

const YMAPS_SRC = "https://api-maps.yandex.ru/2.1/?lang=ru_RU";

let scriptPromise: Promise<void> | null = null;
let mapsPromise: Promise<YandexMapsApi> | null = null;

export function loadYandexMaps(): Promise<YandexMapsApi> {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("Яндекс-карты доступны только в браузере"));
  }

  if (mapsPromise) {
    return mapsPromise;
  }

  if (!scriptPromise) {
    scriptPromise = new Promise<void>((resolve, reject) => {
      const existing = document.querySelector<HTMLScriptElement>(
        `script[src="${YMAPS_SRC}"]`
      );
      if (existing) {
        if (window.ymaps) {
          resolve();
        } else {
          existing.onload = () => resolve();
          existing.onerror = () =>
            reject(new Error("Не удалось загрузить Яндекс-карты"));
        }
        return;
      }
      const script = document.createElement("script");
      script.src = YMAPS_SRC;
      script.async = true;
      script.crossOrigin = "anonymous";
      script.onload = () => resolve();
      script.onerror = () =>
        reject(new Error("Не удалось загрузить Яндекс-карты"));
      document.head.appendChild(script);
    });
  }

  mapsPromise = scriptPromise.then(
    () =>
      new Promise<YandexMapsApi>((resolve) => {
        const waitForApi = () => {
          if (window.ymaps) {
            Promise.resolve(window.ymaps.ready()).then(() =>
              resolve(window.ymaps as YandexMapsApi)
            );
          } else {
            setTimeout(waitForApi, 150);
          }
        };
        waitForApi();
      })
  );

  return mapsPromise;
}

function normalizeQuery(query: string): string {
  const q = query.trim();
  if (/кирово-чепецк/gi.test(q)) {
    return q;
  }
  return `${q}, ${CITY_NAME}`;
}

// ---------------------------------------------------------------------------
// Fallback-геокодинг через Nominatim (OpenStreetMap).
//
// Геокодинг Яндекс.Карт (ymaps.geocode) работает только при валидном
// API-ключе (https://api-maps.yandex.ru/...?apikey=...). Без ключа JS API
// отдаёт "Invalid API key" (apikeyValid: false), а запросы к сервису
// geocoding возвращают 401/403, поэтому ymaps.geocode не может определить
// адрес. Чтобы клики по карте всегда ставили маркер и заполняли поле, при
// сбое Яндекс-геокодинга используем публичный геокодер Nominatim (OSM),
// который не требует ключа и разрешает кросс-доменные запросы (CORS: *).
// ---------------------------------------------------------------------------

const NOMINATIM_REVERSE_URL =
  "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=ru";
const NOMINATIM_SEARCH_URL =
  "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&accept-language=ru&countrycodes=ru&limit=1";

interface NominatimAddress {
  house_number?: string;
  road?: string;
  city?: string;
  town?: string;
  village?: string;
  hamlet?: string;
  suburb?: string;
  county?: string;
  state?: string;
  country?: string;
}

interface NominatimPlace {
  lat?: string;
  lon?: string;
  display_name?: string;
  name?: string;
  address?: NominatimAddress;
}

function formatNominatimAddress(place: NominatimPlace): string | null {
  const a = place.address;
  if (a?.road) {
    const road = a.house_number ? `${a.road}, ${a.house_number}` : a.road;
    const locality = a.city ?? a.town ?? a.village ?? a.hamlet;
    if (locality && !/кирово-чепецк/i.test(road)) {
      return `${road}, ${locality}`;
    }
    return road;
  }
  const display = place.display_name?.trim();
  if (!display) return null;
  return (
    display
      .split(",")
      .slice(0, 2)
      .map((p) => p.trim())
      .join(", ") || null
  );
}

// Простой кэш ответов Nominatim, чтобы не превышать лимит запросов
// (≈1 запрос/сек) и быстро переиспользовать адреса при повторных кликах.
const NOMINATIM_CACHE_TTL_MS = 5 * 60 * 1000;
const nominatimCache = new Map<
  string,
  { at: number; value: ResolvedAddress }
>();

function nominatimCacheGet(key: string): ResolvedAddress | null {
  const entry = nominatimCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.at > NOMINATIM_CACHE_TTL_MS) {
    nominatimCache.delete(key);
    return null;
  }
  return entry.value;
}

function nominatimCacheSet(key: string, value: ResolvedAddress): void {
  if (nominatimCache.size > 500) {
    nominatimCache.clear();
  }
  nominatimCache.set(key, { at: Date.now(), value });
}

async function nominatimReverse(
  lat: number,
  lng: number
): Promise<ResolvedAddress | null> {
  const key = `rev:${lat.toFixed(5)}:${lng.toFixed(5)}`;
  const cached = nominatimCacheGet(key);
  if (cached) return cached;

  try {
    const url = `${NOMINATIM_REVERSE_URL}&lat=${lat}&lon=${lng}`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return null;
    const place = (await res.json()) as NominatimPlace;
    const address = formatNominatimAddress(place);
    if (!address) return null;
    const result = { address, lat, lng };
    nominatimCacheSet(key, result);
    return result;
  } catch {
    return null;
  }
}

async function nominatimSearch(
  rawQuery: string
): Promise<ResolvedAddress | null> {
  const query = rawQuery.trim();
  if (!query) return null;
  const key = `search:${query.toLowerCase()}`;
  const cached = nominatimCacheGet(key);
  if (cached) return cached;

  try {
    const url = `${NOMINATIM_SEARCH_URL}&q=${encodeURIComponent(query)}`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return null;
    const places = (await res.json()) as NominatimPlace[];
    const first = places[0];
    if (!first) return null;
    const lat = Number(first.lat);
    const lng = Number(first.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    const address =
      formatNominatimAddress(first) ?? first.display_name ?? query;
    const result = { address, lat, lng };
    nominatimCacheSet(key, result);
    return result;
  } catch {
    return null;
  }
}

export async function geocodeAddress(
  ymaps: YandexMapsApi,
  rawQuery: string
): Promise<ResolvedAddress | null> {
  const query = rawQuery.trim();
  if (!query) {
    return null;
  }

  try {
    const res = await ymaps.geocode(normalizeQuery(query), { results: 1 });
    const geo = res.geoObjects?.get(0);
    if (!geo) {
      return nominatimSearch(query);
    }

    const coords = geo.geometry?.getCoordinates?.();
    if (!coords || coords.length < 2) {
      return nominatimSearch(query);
    }

    const address =
      geo.getAddressLine?.() ??
      (geo.properties?.get("metaDataProperty.GeocoderMetaData.text") as
        string | undefined) ??
      query;

    return {
      address,
      lat: coords[0],
      lng: coords[1],
    };
  } catch {
    // Геокодинг Яндекса недоступен (например, нет API-ключа) — используем
    // публичный геокодер Nominatim (OSM) как запасной.
    return nominatimSearch(query);
  }
}

/**
 * Определяет адрес по координатам клика на карте (обратный геокодинг).
 * Сначала ищем дом, при неудаче — улицу.
 */
export async function reverseGeocodeAddress(
  ymaps: YandexMapsApi,
  lat: number,
  lng: number
): Promise<ResolvedAddress | null> {
  try {
    const res = await ymaps.geocode([lat, lng], { kind: "house", results: 1 });
    let geo = res.geoObjects?.get(0);
    if (!geo) {
      const streetRes = await ymaps.geocode([lat, lng], {
        kind: "street",
        results: 1,
      });
      geo = streetRes.geoObjects?.get(0);
    }
    if (!geo) {
      return nominatimReverse(lat, lng);
    }

    const coords = geo.geometry?.getCoordinates?.();
    const address =
      geo.getAddressLine?.() ??
      (geo.properties?.get("metaDataProperty.GeocoderMetaData.text") as
        string | undefined);
    if (!address || !coords || coords.length < 2) {
      return nominatimReverse(lat, lng);
    }

    return {
      address,
      lat: coords[0],
      lng: coords[1],
    };
  } catch (err) {
    // Обратный геокодинг Яндекса недоступен (например, нет API-ключа) —
    // используем публичный геокодер Nominatim (OSM) как запасной.
    console.error("Ошибка обратного геокодинга (Yandex), использую OSM:", err);
    return nominatimReverse(lat, lng);
  }
}
